{
  inputs.nixpkgs.url = "github:NixOS/nixpkgs/nixos-26.05";
  outputs = { self, nixpkgs }:
    let
      system = "x86_64-linux";
      pkgs = import nixpkgs { inherit system; };
    in
    {
      devShell.${system} = pkgs.stdenv.mkDerivation rec {
        name = "lean-kernel-arena";
        buildInputs = with pkgs; [
          (python3.withPackages (p : with p; [ jinja2 pyyaml jsonschema markdown ]))
          elan
          rustc
          cargo
          llvmPackages_21.libllvm
          perf
          libffi
          libffi.dev
          pkg-config
          jq
          just
          pypy
          monolith
          nodejs
          ocaml
          opam
          gmp
          zig
          ghc
          texlive.combined.scheme-basic
        ];
      };
    };
}
