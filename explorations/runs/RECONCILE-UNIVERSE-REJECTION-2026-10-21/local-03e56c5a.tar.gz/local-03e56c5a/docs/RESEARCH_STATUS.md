# Research Status

Last updated: 2026-10-21

## How Status Is Tracked

This document is the canonical human-readable research tracker:

- `Attempted` is the append-only record of completed experiments and durable
  engineering work.
- `Research Frontier` selects the authorized theme. Only its `Active` subsection
  defines what should be investigated next. The linked
   [canonical work queue](../config/research-queue.json) ranks scoped items
  beneath that theme and retains explicitly deferred alternatives.
- `Waiting` records work blocked on upstream adjudication without allowing it to
  displace executable local work.
- `Future Directions` preserves promising ideas that have not yet outranked the
  active queue.
- `Unresolved Problems` records limitations and open claims, not task priority.

`docs/PUBLIC_STATUS.md` remains a generated assurance snapshot rather than a
planning document. GitHub Issues coordinate bounded, claimable work beneath the
Active frontier and track upstream conversations; an Issue does not activate a
research direction or establish project truth. This file retains the project's
own priorities and completion conditions.

Project-originated pull requests and prepared pull-request candidates are
indexed in the canonical
[external contribution ledger](../results/research/external-contributions.json)
and its generated [human view](EXTERNAL_CONTRIBUTIONS.md). Upstream states there
are dated observations rather than live guarantees. Item-specific evidence and
submission records remain authoritative for their detailed historical claims.

Use [Research workflow](RESEARCH_WORKFLOW.md) to rank by expected ecosystem
value, information gained, transfer, feasibility/cost, and urgency. Complete a
scoped item before reevaluating; record every attempt and observed cost without
using counts as permission or termination limits. Every stopping-point review leaves a selected executable next item or
an explicit blocker requiring a decision. Literature/reuse assessments are
first-class queue items before new methods and at periodic review boundaries.
Validate queue/status agreement with `scripts/validate-research-queue`.

Research activity is not progress merely because it produces another document,
taxonomy, or abstraction. Every Active frontier item must have a falsifiable
completion condition and terminate in at least one of:

- executable evidence;
- a characterized boundary;
- a regression or corpus contribution;
- an upstream action recommendation;
- a demonstrated negative result; or
- an unresolved result caused by a genuine authority, invalidated-input or
  unavailable-capability boundary after feasible repairs.

Keep the number of top-level Active research themes small. The normal target is
one or two coherent frontier themes, with parallel work occurring through
bounded GitHub Issues beneath them rather than by activating many unrelated
research directions.

## Attempted

- `E0-SYMBOLIC-UNIVERSE-REJECTION-1` closes `NO_SIGNAL`: Lean and Nanoda each
  accepted three byte-identical valid controls and rejected the three invalid
  universe declarations, twelve expected outcomes total. Nanoda's three
  source-attributed assertion rejections remain explicit; no unexpected crash
  or unsupported input occurred. Retain the small boundary corpus; no defect,
  external action or automatic confirmation follows. The source-only corpus
  reuse assessment is READY and unstarted. See the
  [result](../explorations/runs/EXPLORE-SYMBOLIC-UNIVERSE-REJECTION-1/summary.md).

- `E0-SYMBOLIC-UNIVERSE-SCREEN-1` closes `NO_SIGNAL`: Lean and Nanoda accepted
  all six valid symbolic-universe cases, twelve checks total. Actual parsed
  declarations retained named parameters, symbolic max and dependent Pi/imax.
  This adds a small local corpus beyond numeric-level coverage; it is no
  correctness or invalid-input detection claim. One setup failure was repaired
  offline and retained. No upstream action or automatic confirmation follows.
  The separate three-boundary rejection screen is READY and unstarted. See the
  [result](../explorations/runs/EXPLORE-SYMBOLIC-UNIVERSE-1/summary.md).

- `TREE2-UTILITY-DISPOSITION-1`: no existing published lemma was shown to
  discharge a remaining upstream completeness premise. The preserved upstream
  branch already has general occurrence, substitution and restoration proofs.
  Independent source review agrees. Stop Tree2 expansion and retain the checked
  case study; no proof/evidence outcome is rewritten. See the
  [negative utility assessment](../results/research/tree2-utility-disposition-1/report.md).


The following three Tree2 entries describe historical checkpoints. Their
usefulness recommendations and ACTIVE/next-step wording are superseded by the
negative utility disposition above; their proof and evidence outcomes remain
unchanged.

- `EXPLORE-TREE2-DOMAIN-GRAMMAR-1`: Lean checked a structural acceptance bridge
  for every finite parameter/self/arrow domain and every List depth. Actual
  acceptance supplies occurrence freedom; independent substitution and typing
  proofs construct native positivity at the computed Core bound. Fresh six-module
  replay and independent noncircularity review pass with standard three axioms.
  This is enough for a focused human maintainer target-fit inquiry about parked
  completeness; no message or posting-ready draft was created. No further
  grammar expansion or fold trial starts here. See the [report](../explorations/runs/EXPLORE-TREE2-DOMAIN-GRAMMAR-1/report.md).

- `EXPLORE-TREE2-ARROW-TOWER-1`: Lean checked a nonvacuous restricted completeness
  family for every List depth, including zero. Actual official acceptance excludes
  the negative function domain and yields exact lowering, constructed native
  derivations and native success. Fresh seven-module replay and independent
  review pass with only standard three axioms. This is useful modest progress,
  not arbitrary proof reconstruction or production correctness. Next within the
  same ACTIVE campaign: assess a small symbolic domain grammar and its exact
  preservation obligations; no folds auto-start. See the [report](../explorations/runs/EXPLORE-TREE2-ARROW-TOWER-1/report.md).

- `EXPLORE-TREE2-SYMBOLIC-ASSESSMENT-1`: Lean checked reusable successful-fuel
  uniqueness for the official elimination algorithm and exact-output acceptance
  extraction. This is useful modest progress beyond fuel-case enumeration, with
  fresh replay and independent review. Arbitrary-depth function completeness is
  unproved; next is the exact parametric function source and root-row invariant.
  The same Tree2 campaign remains ACTIVE. See the [report](../explorations/runs/EXPLORE-TREE2-SYMBOLIC-ASSESSMENT-1/report.md).

- `E0-LEAN-ACTION-BUNDLED-WHOLE-RETRY-1` closes `NO_SIGNAL` for the exact
  whole-module input retained by `E0-LEAN-ACTION-BUNDLED-REAL-1`.
  **What did we find?** The retry accepted 59,349 declarations in 28.691 seconds,
  with no type-checking error. Its missing pretty-printer destination produced
  the expected diagnostic. The original five declaration-selected controls
  behaved as expected, but its whole-module call timed out and remains
  historically `INCONCLUSIVE`. Both histories, including the failed retry
  launcher, are preserved. **Is it interesting?** Yes, modestly: the exact
  previously missing verdict is now available; it establishes no checker
  correctness, general conformance, workflow execution or host-security claim.
  **Does it require more work?** No further run follows from this result. The
  separate alias preparation remains DEFERRED and unstarted. See the
  [original screen](../explorations/runs/EXPLORE-LEAN-ACTION-BUNDLED-REAL-1/summary.md)
  and [whole-module retry](../explorations/runs/EXPLORE-LEAN-ACTION-BUNDLED-WHOLE-RETRY-1/summary.md).

- `TREE2-CONFIRMED-INTEGRATION-1` completes the restricted constructor
  representation correspondence and its historical repository closure.
  **What did we find?** Lean checked the fixed List-tower representation package,
  including Tree2, and a fresh replay compiled all 108 modules. The proof source
  and validation archives survived publication unchanged. The successful
  strict closure binds frozen `bcb3fe4` inputs; this later history restoration
  makes no fresh current-tree closure claim. **Is it interesting?** Yes: it
  connects independently specified simplified-model representations rather than
  supplying another acceptance example. It does not prove a datatype/fold
  correspondence, returned-observation identity or production-kernel correctness.
  **Does it require more work?** No further science starts in this reconciliation.
  See the [research archive](../results/research/tree2-confirmed-integration-1/)
  and [historical closure archive](../results/workflow-validation/tree2-confirmed-integration-1/).

- `E0-SEMANTIC-ASSURANCE-SCREENING-1` completes six E0 NO_SIGNAL screens.
  **What did we find?** Forty final checker cells contain 34 accepts and six
  expected ill-typed rejections; both retained real proof slices transfer, and
  the recursor candidates demand delta/iota at depths 1 and 4. Sharing pairs
  agree but duplicate expressions are merged on import. The identity sentinel
  detects both valid substitutions. Lean4Lean emits formatting panics while
  rejecting all three bad targets. **Is it interesting?** Yes, modestly: reusable
  demanded-reduction, proof-transfer and intended-target controls, plus a concrete
  diagnostic limitation. No correctness or general completeness claim follows.
  **Does it require more work?** No semantic confirmation follows. Select
  `E0-LEAN4LEAN-DIAGNOSTIC-PANIC-TRIAGE-1` READY and unstarted for the separate
  source-only diagnostic question. Forty-eight actual launches, three preserved
  sandbox prelaunch failures and one fixture repair remain retained. See the
  [campaign summary](../explorations/runs/EXPLORE-SEMANTIC-ASSURANCE-CAMPAIGN-1/summary.md).

- `SNAPSHOT-REUSE-CLOSURE-RELIABILITY-1` completes subject to its prebound
  final ordered repository receipt. **What did we find?** The costly
  suite now runs from a detached exact-commit snapshot, and publication is
  refused unless every declared publication input still matches that snapshot.
  Stage-specific content bindings reuse the suite after a publication-only
  document change and invalidate it after an actual test dependency change.
  Thirty-one focused controls pass. Four failed ordered closure attempts
  remain preserved: the first rejected an unsafe linked source ancestor, the
  second exposed snapshot-local receipt, Arena checkout, and closure-state
  integration requirements, the third rejected edits to frozen historical
  tests before discovery, and the fourth passed all three test partitions
  before rejecting generated refresh outputs that had been misclassified as
  validation inputs. No scientific experiment ran. **Is it
  interesting?** Yes, because arbitrary live edit-and-restore activity can no
  longer contaminate the validated suite, while unrelated commits no longer
  invalidate a stage solely through global `HEAD`. **Does it require more
  work?** No further repair follows if the prebound attempt 0005 full
  current/historical closure passes. The separate
  `RESOURCE-SHORT-PROCESS-MEMORY-AUDIT-1` is selected READY and unstarted for
  its fixed read-only audit of eighteen retained receipts.

- `E0-LAZYLEAN-SEMANTIC-EXTENSION-1` closes `NO_SIGNAL` after its fixed
  eight-cell delta/iota screen. **What did we find?** Substitution and KAM-mode-3
  accepted both candidates and both controls in both families, eight accepts
  total. The KAM candidates recorded one targeted delta and one targeted iota
  transition while their controls recorded zero; no profile difference was
  observed. The first sandbox monitor preflight and an initial host-retry
  wrapper check failed before child launch and remain preserved. **Is it
  interesting?** Yes, modestly, because it extends executable demand-qualified
  exploration beyond the six retained beta/zeta cases. The two profiles share
  one implementation, and this E0 sample supplies no conformance, correctness or
  general no-difference claim. **Does it require more work?** No confirmation
  follows from this result. Retain the fixtures and raw evidence. Select
  `SNAPSHOT-REUSE-CLOSURE-RELIABILITY-1` READY and unstarted to repair the
  separate exact-input and stage-dependency closure risks before any future E1
  confirmation.

- `E0-NANODA-SEMANTIC-DIVERSITY-SCREEN-1` closes `INCONCLUSIVE` after its one
  fixed read-only inventory attempt. **What did we find?** The selector could
  not produce the required six candidates. Its retained diagnostic classified
  all 502 syntactic sites: 167 matched generated mutation specs, three matched
  manual controls, 124 were in non-semantic files and 208 were outside the
  retained modeled semantic functions, leaving zero eligible sites. No mutation
  was written or registered, and no mutant build or checker run occurred. This
  did not test semantic behavior and does not show that fresh Nanoda targets are
  absent in general. **Is it interesting?** Yes, because it cheaply shows that
  the current pinned-source `semantic-diversity-v1` path is exhausted and should
  not be promoted directly to confirmation. **Does it require more work?** No
  confirmation follows from this result. Retain the exact E0 ledger and raw
  exhaustion counts. Select `RESOURCE-SHORT-PROCESS-MEMORY-AUDIT-1` READY and
  unstarted to resolve the separate accounting interpretation gap in eighteen
  existing receipts.

- `WORKFLOW-CLOSURE-RELIABILITY-1` completes its shared controller repair upon
  the required ordered closure receipt. **What did we find?** Twenty
  closure-control tests and four aggregate-usage tests pass: one repository
  owner is enforced, interrupted stages are retained and safely resumed, exact
  dependency changes invalidate downstream reuse, unexplained cached-output
  changes fail closed, and control receipts stay outside scientific evidence.
  Seventeen resource replay/isolation and exploration-ledger compatibility tests
  and 23 stateful historical-transition/replay tests also pass. No scientific experiment ran. The response-level baseline contains
  82 unique records through 11:37:43 UTC: 9,175,446 input tokens (8,904,064
  cached; 271,382 derived uncached), zero cache-write input, 51,800 output and
  16,829 reasoning-output tokens. Final closure/delivery and later responses are
  missing by construction; no dollar cost or saving is inferred. **Is it
  interesting?** Yes, as a reusable repair for the observed state-edit race and
  control/scientific receipt collision. **Does it require more work?** No repair
  follows from the passing controls. Select `E0-NANODA-SEMANTIC-DIVERSITY-SCREEN-1`
  READY and unstarted for one read-only source-inventory trial. The historical
  short-process memory audit remains deferred. See the
  [report](../results/research/workflow-closure-reliability-1/report.md).

- `EXPLORATORY-EXPERIMENT-PROTOCOL-1` implements the owner-directed E0 lane,
  subject to final shared-workflow validation and refresh. **What did we find?**
  Fifteen focused tests pass for cheap negative closure, incomplete measurements,
  append-only evidence, separate confirmation proposals and lightweight CI.
  No scientific experiment or measured efficiency result follows. **Is it
  interesting?** Yes, it makes hypothesis screening a distinct operational path.
  **Does it require more work?** Retain the lane after final checks; select
  `WORKFLOW-CLOSURE-RELIABILITY-1` READY and unstarted to repair the separate
  confirmed coordination/replay defects and measure token cost. The memory audit
  is deferred. See [the adoption report](../results/research/exploratory-experiment-protocol-1/report.md).

- `RESOURCE-ENVELOPE-PILOT-1` has a reviewed scientific result with SUCCESS;
  final repository completion requires the file-backed full-suite and ordered
  closure receipts. Closure attempt 0001 failed during a temporary state-edit
  race and remains preserved. **What did we find?** Both observers accepted all twelve independently
  audited inputs (24 scientific checks), and all twelve empty-input baselines
  were ACCEPTED. No configured resource limit or process-control fault affected
  the fixed scientific matrix. The eighteen Nanoda runs have zero sampled RSS
  points, so their sampled process-group peaks are unknown; the supervisor's
  configured 10 ms target cadence does not establish the achieved cadence or
  explain the missing samples. The separate `wait4` child-accounting high-water
  values are scoped operating-system accounting data, not group peaks. This
  finite result supplies no general correctness, speed, or memory-bound claim.
  **Is it interesting?** Yes, as a reusable finite resource package that
  exposes a short-process measurement gap. Earlier recursion and sandbox
  monitoring failures remain preserved in its attempt index. **Does it require
  more work?** Retain the corpus, receipts, portable replay, and report locally;
  no upstream action follows. Select `RESOURCE-SHORT-PROCESS-MEMORY-AUDIT-1`
  READY and unstarted to audit those exact eighteen receipts and define a future
  metadata/reporting rule. Final repository completion still requires a
  successful file-backed full-suite and closure-controls receipt; the first
  closure attempt 0001 failed during a temporary state-edit race; attempt 0002
  preserved a status-preflight wording error after passing host RSS preflight;
  attempt 0003 passed its preflight gates but exposed a receipt-replay coverage
  gap in the full suite after closure-control receipts were added. All three
  remain indexed engineering records and none changes the scientific result.
  See the
  [report](../results/research/resource-envelope-pilot-1/report.md).

- `BINDER-MODEL-PILOT-1` completes its fixed finite syntactic comparison.
  **What did we find?** Two selected APIs matched the independent
  named-variable model on all 10,000 rows and 30,000 stage outputs; the corpus
  has 5,091 distinct structural inputs and 2,000 capture-collision cases. It
  did not test typed Lean programs/proofs, other APIs, whole-kernel correctness
  or performance. **Is it interesting?** Yes, as a reusable local regression
  corpus with independently checked expectations; this finite agreement is not
  a correctness proof. **Does it require more work?** Retain the model, auditor,
  vectors and portable replay; no external action follows. The separate
  `RESOURCE-ENVELOPE-PILOT-1` question is selected READY and unstarted for
  source, validity and measurement preparation only. See the
  [report](../results/research/binder-model-pilot-1/report.md).

- `REAL-PROOF-SLICES-PILOT-1` completes its fixed 2026-09-28 scientific
  question with SUCCESS, subject to its required final repository
  validation/refresh receipt. Twelve exact declarations from three retained
  exports received independently audited dependency-closure dispositions.
  Nine slices met the committed size ceilings, and official Lean 4.33.0 and
  Nanoda `6ae1f0c` accepted all 18 supervised cells. The other three fixed
  `std` cases remain OVERSIZE without semantic observations. A prose-only
  audit binding defect was preserved and repaired as R2; two sandbox RSS
  preflight failures and the successful actual-host retry are preserved.
  Retain the slicer, auditor and nine accepted slices locally. Agreement is
  scoped to the exact profiles, observed libraries are not fresh holdouts,
  and no external action follows. `BINDER-MODEL-PILOT-1` is selected READY
  and unstarted for staged source, API and model preparation. See the
  [report](../results/research/real-proof-slices-pilot-1/report.md).

- The 2026-09-28 CI evidence-replay portability repair inventories all 13
  recorded process families (303 JSON files, 337 receipts and 642 raw streams)
  on every checkout, requires registered replay tests and alternate-checkout
  regressions for new families, and checks raw custody without resolving the
  original macOS paths. GitHub CI requires a foreign checkout before the full
  unit suite. The two older Kiota packages now have read-only portable receipt
  replay; the type-repair history explicitly retains one pre-launch failure and
  22 launched attempts whose original manifest hashes no longer match current
  files, while nine launched attempts remain exact-manifest-bound. The full
  repository test runner passed. This is engineering maintenance, not a new
  scientific result or a frontier change. `REAL-PROOF-SLICES-PILOT-1` remains
  selected READY and unstarted. See [CI evidence replay portability](CI_EVIDENCE_REPLAY.md).

- `STATEFUL-VALIDATION-PILOT-1` completes on 2026-09-27 with SUCCESS subject
  to its required final repository validation/refresh receipt. All six public
  kernel environment-history relations preserved, with twelve fresh-process
  histories and 25 exact requests matching every expected outcome and full
  environment projection. Two generic compile failures and a generation
  manifest-custody defect remain preserved; reviewed R4 revalidated and adopted
  the exact existing fixture bytes without replacing scientific inputs. Retain
  the local regression package. This is one API/implementation and supplies no
  persistent-cache, general rollback or soundness claim; no external action
  follows. `REAL-PROOF-SLICES-PILOT-1` is selected READY and unstarted for staged
  source/reuse and dependency-closure preparation. See the
  [report](../results/research/stateful-validation-pilot-1/report.md).

- `LAZY-REDUCTION-CONFORMANCE-PILOT-1` completes on 2026-09-27 with SUCCESS
  subject to its final repository validation/refresh receipt. Both pinned
  lazylean reduction profiles accepted all six independently audited conversion
  cases, twelve cells total, with every required KAM beta/zeta demand observed.
  All four retained capability cells matched. The local portable build preserves
  its first linker failure and corrected C++ driver identity; source/scientific
  inputs did not change. Retain the exact adapter and demand-qualified regression
  package. Agreement within one implementation supplies no independent semantic
  authority, soundness or performance claim; no external action follows.
  `STATEFUL-VALIDATION-PILOT-1` is selected READY and unstarted for supported
  public API/session/recovery preparation. See the
  [report](../results/research/lazy-reduction-conformance-pilot-1/report.md).

- `WORKFLOW-CLOSURE-AUTOMATION-1` closes on 2026-09-27 with SUCCESS upon its required final validation receipt. The scoped successor adds an actual-host RSS preflight, declared exact committed-byte inventory and a one-command full-suite, validation-record, dependency-ordered refresh and freshness path. Fifteen focused closure-control regressions pass. Its first full-suite attempt found a stale Active READY-count line; the [R2 repair](../results/research/workflow-closure-automation-1/repair-r2.json) preserves that failed attempt and runs the existing count regression before future full suites. A source-only comparison bound one lazylean revision and its 24-file source inventory, with no build or scientific launch; it selected `LAZY-REDUCTION-CONFORMANCE-PILOT-1` READY for preparation while retaining STATEFUL READY as an alternative. [Candidate and final gate](../results/research/workflow-closure-automation-1/closure-candidate.json); [source comparison](../results/research/workflow-closure-automation-1/observer-comparison/report.md). No external action occurred.

- Completed `TRUST-ASSUMPTION-PIPELINE-PILOT-1` on 2026-09-23 with SUCCESS.
  Official Lean 4.33.0's local body traversal and imported `.olean` axiom
  metadata preserved all six fixtures' exact source-derived transitive sets,
  twelve cells total. The report consumer permitted the sufficient explicit
  allow-set and denied the empty set on both paths. One local name-rendering
  incident is preserved and repaired through globally scoped printing options
  under R2, without changing scientific inputs or relabeling R1. This is
  reporting/policy evidence within one Lean implementation, not soundness,
  independent-checker consensus, lean4export behavior or kernel policy
  enforcement. Retain the local regression package; no external action follows.
  `STATEFUL-VALIDATION-PILOT-1` is selected READY and unstarted for supported
  public API/source-contract preparation. See the
  [report](../results/research/trust-assumption-pipeline-pilot-1/report.md).

- Completed `KIOTA-RECURSOR-PR-REFINEMENT-1` on 2026-09-22 with SUCCESS.
  The successor replaces full-environment copies with a block-local undo journal,
  preserves ignored/recomputed K metadata, extracts documented reconstruction,
  and adds eight comparison/rollback regressions. Fifteen focused tests, the six
  original preservation cells and all 168 Kiota tests pass. The revised local PR
  description leads with the concrete fifth-domain error and downstream impact;
  the original package remains unchanged. No external submission occurred.

- Completed `KIOTA-RECURSOR-TYPE-REPAIR-1` on 2026-09-22 with SUCCESS. The
  source patch reconstructs complete ordinary, mutual and nested recursor types,
  withholds current-block serialized recursors during checking, compares supplied
  signatures fail-closed and installs only reconstructed types. The exact
  negative/control and four valid acceptance cells matched their expectations,
  seven focused tests passed and the complete 160-test suite passed. The local
  PR draft is indexed but unsubmitted; current-tip refresh and exact human
  authorization remain required for any external action.

- Completed `KIOTA-RECURSOR-TYPE-DESIGN-1` on 2026-09-22 with
  `VALIDATED_COMPLETE_KIOTA_DESIGN`. Exact pinned Kiota source provides the
  required expression, universe, inference and conversion APIs, while an
  already archived provenance-bound Lean 4.33.0 kernel source supplies the
  complete ordinary, mutual and nested construction algorithm. The local rule
  is positional universe alpha normalization, fail-closed Kiota definitional
  equality and unconditional replacement with the reconstructed type. Four
  exact accepted fixtures and the inherited reject-candidate/accept-control pair
  are frozen. No checker launch, build, production edit, generated scientific
  byte, network, catalog or external action occurred. The separately gated
  `KIOTA-RECURSOR-TYPE-REPAIR-1` subsequently completed with a validated local
  source patch, regression evidence and unsubmitted PR draft.

- Completed `RECURSOR-TYPE-TRUST-BOUNDARY-1` on 2026-09-22 with
  `VALIDATED_REGRESSION_TARGET_WITH_SOURCE_BOUNDARY`. Exact Kiota `9fa2c297`
  source inspection shows the serialized recursor type is stored and later used
  for downstream typing without complete reconstruction. Exact official Lean
  4.33.0 replay source shows dependency-first regeneration followed by postponed
  complete-record comparison, explaining both the bare invalid-recursor and
  extended fifth-domain diagnostics. The preserved one-scalar pair is now a
  mechanically validated reject-candidate/accept-control regression target.
  No checker launch, production edit, catalog change or external action occurred.
  The later design item supplied the previously missing complete construction
  and comparison/replacement relation; its separate production-repair item then
  completed with a validated source patch and unsubmitted local PR draft.

- Completed `VALID-DEPENDENT-TERM-PILOT-1` on 2026-09-21 with SUCCESS. The
  derivation-directed generator produced the exact fifty-case corpus with ten
  cases each for Pi, lambda, application, let and mixed terms. An independent
  negative-capable auditor passed every case, and the checked-object bridge
  bound each one-declaration export before observation. Official Lean 4.33.0
  and Nanoda `6ae1f0c` accepted all 100 frozen matrix cells with no observed
  conformance difference. Two preparation defects were preserved and repaired
  without replacing a scientific case. Retain the generator, auditor, corpus,
  receipts and guarded runner as a local positive-conformance asset; no
  external action follows from an all-accept result. `ACCEPTANCE-IMPACT-PILOT-1`
  is selected READY and unstarted for exact current reproduction, with
  downstream construction gated on the premise reproducing.

- Completed `PIPELINE-COMPLETENESS-PILOT-2` on 2026-09-21 with SUCCESS under
  the corrected persistent-execution policy. The pinned Lean 4.29.1 producer
  generated the exact twelve-theorem module; an independent parser bound its
  ordered declarations, `True` statements and complete value-dependency chain.
  Official Lean and Lean4Lean accepted the exact baseline. Both also accepted
  the target-omission and compatible-substitution artifacts, while both rejected
  the truncated record. The sentinel independently returned the preregistered
  failure in all six fault cells, demonstrating that checker exit success alone
  does not prove the supplied artifact was the requested object. Three routine
  supervisor/controller incidents were preserved, repaired and retried without
  changing the scientific matrix or closing the item. Retain the executable
  receipt package locally; no checker-soundness claim or external action follows.
  `VALID-DEPENDENT-TERM-PILOT-1` is selected READY and unstarted for its
  source/reuse and independent typing-rule phase.

- Completed `PIPELINE-COMPLETENESS-PILOT-1` on 2026-09-20 with
  `BOUNDED_UNRESOLVED`. The independent twelve-theorem expectation, strict
  export parser, intended-object sentinel, dependency checks, three faults and
  fixed eight-cell matrix were implemented and passed focused tests. Its sole
  supervised producer reservation then failed before compilation because the
  controller supplied Lake an invalid hand-authored manifest. The exact exit,
  stderr, 48 positive RSS samples and complete cleanup are preserved; no export
  or checker cell exists, so no scientific or checker claim follows. A minimal
  repair removes controller-owned manifest state and adds a regression, but was
  not relaunched because the former policy incorrectly treated its 1/1 cap as
  terminal. A post-terminal local Lake help diagnostic
  attempted and failed a latest-release query, returned no network data and is
  retained as a protocol deviation. `PIPELINE-COMPLETENESS-PILOT-2` is selected
  READY as the live continuation of the unanswered question. Its configuration
  preflight, build and checker work now follow persistent repair-and-retry policy.

- Completed `SURVIVOR-THREAD-ONE-CHILD-PANIC-REGRESSION-1` on 2026-09-20 with
  `BOUNDED_UNRESOLVED`. Its R1 controller import error occurred before any
  supervised process and is preserved separately. The R2 baseline Cargo build
  did run offline with complete RSS/cleanup receipts, but pinned `src/main.rs`
  requires a `README.md` omitted from the frozen 22-file source inventory.
  Neither exact source byte is locally pinned nor may it be fetched or
  substituted within this item, so no observer, control or candidate cell ran.
  This is a source-materialization boundary, not an acceptance, semantic or
  current-upstream result. `SOURCE-LOCK-COMPLETENESS-AUDIT-1` completed SUCCESS
  for a static 22-file ledger: `src/main.rs` directly includes `README.md`,
  which is neither locked nor pinned. Its two controller incidents are
  preserved engineering evidence; no build, checker or network operation
  occurred. `SOURCE-PROVENANCE-INTAKE-1` then completed SUCCESS by binding the
  exact 6517-byte README from the pinned revision without editing frozen history.
  `CHILD-PANIC-CONFIRMATION-1` then completed SUCCESS: both controls accepted,
  while the baseline candidate failed on the main thread and the one-worker
  mutant failed in `thread_0` followed by the parent join panic. This is a
  diagnostic regression only; both observers reject the candidate, so there is
  no acceptance or soundness difference and no upstream action is recommended.

- Completed `SURVIVOR-THREAD-ONE-DETERMINISM-1` on 2026-09-20 with SUCCESS
  for a source-supported, unexecuted one-thread child-panic diagnostic protocol.
  At public `num_threads=1`, the pinned original checks the existing invalid
  601-byte export serially while the relational-boundary mutant runs it in one
  scoped worker; the source fixes the parent join diagnostic for that worker
  panic. This supports a separate four-cell operational regression candidate
  using existing control/candidate bytes. It does not establish a semantic
  acceptance difference, current upstream defect or external action. The
  [assessment](../results/research/survivor-thread-one-determinism-1/determinism-assessment.json)
  ran no process. `SURVIVOR-THREAD-ONE-CHILD-PANIC-REGRESSION-1` is selected
  as a historical bounded follow-through: its R1 controller import error
  preceded every process invocation, and its R2 baseline build later established
  only the omitted-README source-materialization boundary.

- Completed `METAMORPHIC-REPRESENTATION-PILOT-2` on 2026-09-20 with SUCCESS.
  The separate continuation preserved pilot 1 unchanged, diagnosed its hidden
  sandbox-denied `/bin/ps` monitor path, added observable start-gated macOS RSS
  supervision, generated four exact variants and independently preserved all
  four. Two reverse-ready variants met the frozen nonidentity delta; two
  round-robin variants remained ineligible as predicted. The final twelve-cell
  matrix has eight executed ACCEPT observations and four ineligible dispositions:
  all four exact within-checker original/variant relations held on official Lean
  4.33.0 and Nanoda `6ae1f0c`. One eight-attempt run remains preserved as an
  infrastructure failure; the exact eight-cell confirmation had positive RSS
  observations, exact raw paths and complete cleanup. This is scoped evidence
  of no observed representation sensitivity, not global invariance. Retain the
  package as a local conformance asset; no external action now. See the
  [report](../results/research/metamorphic-representation-pilot-2/report.md).
  `SURVIVOR-THREAD-ONE-DETERMINISM-1` later completed SUCCESS as a separate
  source-only assessment.

- Completed `METAMORPHIC-REPRESENTATION-PILOT-1` on 2026-09-20 with
  BOUNDED_UNRESOLVED at its exact 8/8 tooling-attempt cap. The source/reuse and
  scientific-design gates froze two originals, two transformations, two exact
  profiles and a twelve-cell maximum matrix, but process supervision never
  passed its complete fourteen-case gate. The final combined attempt stopped
  before generation: zero variants, zero checker launches and zero external
  writes. No representation-sensitivity or invariance conclusion follows, and
  no external action is recommended. The pilot-only unvalidated executable
  tooling was retired from the live tree while its final bytes remain bound at
  commit `4e4128c034cfe930c032b40881d0ec6fd6e97247`; see the
  [report](../results/research/metamorphic-representation-pilot-1/report.md).
  `SURVIVOR-THREAD-ONE-DETERMINISM-1` is selected READY and unstarted under its
  unchanged source-only plan.

- On 2026-09-20, the owner-requested [frontier selection](../results/research/frontier-selection-2026-09-20/report.md)
  adopted `F-DISCOVERY-AND-CONFORMANCE` after both Kiota items completed.
  Ten concrete discovery candidates now occupy the ranked horizon.
  `METAMORPHIC-REPRESENTATION-PILOT-1` is selected READY and unstarted for one
  staged 360-active-minute source/reuse, implementation and gated execution pilot.
  The other nine remain PLANNED with independent promotion gates; the original
  one-thread assessment remains READY reserve. No pilot, new scientific byte,
  external research write, historical result or assurance milestone starts or
  changes in this queue update.

- Completed `KIOTA-CTOR-INDEX-TEST-1` on 2026-09-19 with SUCCESS for one
  [test-only preventive regression](../results/research/kiota-ctor-index-test-1/report.md)
  at freshly bound Kiota `9fa2c297`. The focused pair passed 2/2 and the full
  current suite passed 83 unit plus 72 integration tests, 155 total, with zero
  failures or ignores. The exact unchanged control accepts; the one-scalar
  candidate rejects with the exact owner-list/index message. Five of six
  source/setup/duplicate requests and two build/test reservations were charged;
  no production change, checker, proof, mutation, new export or external write.
  The [indexed PR draft](../results/action-recommendations/drafts/kiota-constructor-index-regression-pr.md)
  remains local and human-gated. No current defect or universal metadata rule is
  claimed. `SURVIVOR-THREAD-ONE-DETERMINISM-1` is selected READY and unstarted.

- Completed `KIOTA-CTOR-INDEX-COVERAGE-1` on 2026-09-19 with SUCCESS for one
  [source-bound existing-byte regression design](../results/research/kiota-ctor-index-coverage-1/report.md)
  at retained Kiota `9fa2c297`. The complete 70-fixture inventory has 69 unique
  wired fixtures across 70 tests. `orphan-ctor` reaches the missing-owner branch;
  no wired fixture reaches the distinct declared-owner wrong/out-of-range cidx
  branch. The exact one-scalar pair predicts control ACCEPT and candidate exact
  owner-list/index REJECT, but no Kiota process ran. Seven local requests, zero
  network/build/test/checker/proof/mutation/new-export/external-write launches.
  No current defect or universal metadata rule is claimed. The separately gated
  `KIOTA-CTOR-INDEX-TEST-1` is selected READY and unstarted.

- Project-wide strategy review on 2026-09-19 UTC confirmed four merged Arena
  contributions after freshly observing #206 merged. Nanoda #32/#33 remain open;
  their combined discussion endpoints returned no entries, without a capacity
  inference. The [review](../results/research/project-strategy-review-2026-09-19/report.md)
  selects `KIOTA-CTOR-INDEX-COVERAGE-1` READY and unstarted for one bounded
  existing-byte coverage audit. The one-thread assessment remains READY under
  its unchanged scope and budget. Corrected live survivor-denominator and Kiota
  waiting descriptions against existing evidence; no historical result, gate,
  authority, scientific execution or external research write changed.

- Completed `NANODA-STRING-RECONSTRUCTION-TEST-1` on 2026-09-18 with SUCCESS:
  two focused and all 40 library tests passed at exact Nanoda `4c544ed`; eight
  existing doc examples remain ignored. The test-only patch checks eight flag/name
  states and empty/Unicode constructor shapes with an empty declaration map.
  Two requests and two build/test reservations used 12.084409499017056 process
  seconds with successful cleanup. The
  [report](../results/research/nanoda-string-reconstruction-test-1/report.md) and
  [indexed local PR draft](../results/action-recommendations/drafts/nanoda-string-reconstruction-tests-pr.md)
  retain internal syntax scope and capacity/submission holds. No current defect,
  public semantic result or new export is claimed. The existing
  `SURVIVOR-THREAD-ONE-DETERMINISM-1` is selected READY and unstarted under its
  original source-only scope and budget after project-wide comparison.

- Completed `NANODA-NATIVE-CONFIG-BOUNDARY-1` on 2026-09-17 with SUCCESS for
  one [source-supported String reconstruction design](../results/research/nanoda-native-config-boundary-1/report.md).
  Eight source-predicted flag/name rows distinguish raw literals, syntactic typing
  and optional reconstruction; cached names do not establish valid declarations.
  The proposed empty/Unicode structural assertions add coverage beyond PR #33 and
  held local patches. Two source/setup requests, zero Nanoda scientific launches,
  new exports or external writes. `NANODA-STRING-RECONSTRUCTION-TEST-1` is READY
  and unstarted; no current bug or public semantic acceptance claim.

- Completed `NANODA-NESTED-TEST-1` on 2026-09-14 with SUCCESS for one
  [test-only preventive patch](../results/research/nanoda-nested-test-1/report.md).
  Six focused and all 44 Nanoda library tests passed; eight existing doc examples
  remain ignored. Exact PUnit guards and the unchanged control are independently
  reviewed. Two source requests, two build/test reservations and no production
  change, proof, mutation, new export or external research write. The indexed PR
  draft is held locally for capacity and fresh preflight before exact submission
  approval. `NANODA-NATIVE-CONFIG-BOUNDARY-1` is selected READY and unstarted.

- Completed `NANODA-NESTED-REGRESSION-1` on 2026-09-14 with SUCCESS for one
  [source-supported regression design](../results/research/nanoda-nested-regression-1/report.md).
  Current Nanoda `4c544ed` has 38 statically active tests; no direct reserved-name
  rejection/traversal assertions were found. Thirteen paired traversal positions,
  exact name controls and two declaration-guard cells reuse the complete PUnit
  fixture portion with a positive control. Exact panic attribution excludes later
  type errors; the mutual-peer guard remains a named isolation gap. Two read-only
  requests, zero Nanoda scientific launches/new exports/external writes. No current
  bug or universal obligation is established. `NANODA-NESTED-TEST-1` is selected
  READY and unstarted for one bounded test-only implementation.

- On 2026-09-14, after exact owner authorization and fresh source/duplicate
  preflight, submitted the two-file let characterization as
  [Arena #206](https://github.com/leanprover/lean-kernel-arena/pull/206).
  Readback verifies the approved title/body and exact package bytes on unchanged
  Arena `fd74e8b`. The [submission record](../results/research/arena-let-policy-followup-1/external-submission-record.json)
  preserves receipts and the connector permission failure resolved through existing
  GitHub CLI credentials, with no browser use. Research closure remains unchanged;
  `NANODA-NESTED-REGRESSION-1` stays READY and unstarted.

- Completed `ARENA-LET-POLICY-FOLLOWUP-1` on 2026-09-14 with SUCCESS for one
  [candidate-only either package](../results/research/arena-let-policy-followup-1/report.md).
  Current Arena `fd74e8b` static build-test passed, preserving the exact 601-byte
  export. The indexed local PR draft is ready for review after fresh preflight;
  no external submission occurred. Four read-only requests, one static build,
  zero checker/proof/new export/mutation launches or authority changes.
  `NANODA-NESTED-REGRESSION-1` is READY and unstarted.

- Incorporated the lean4export #48 reply on 2026-09-13 through a
  [recommendation successor](../results/research/arena-let-feedback-2026-09-13/decision.md).
  The exact-question response supplies affirmative practical support to reconsider
  an Arena `either` characterization. Historical closures and unresolved universal
  authority remain unchanged. `ARENA-LET-POLICY-FOLLOWUP-1` is selected READY
  and unstarted; the original no-positive-support premise is no longer a blanket
  blocker. No research execution or external write occurred.

- Completed `SEMANTIC-IMPORT-CONTRACT-1` on 2026-09-13 with SUCCESS for one
  source-qualified four-field clarification packet; universal authority remains
  UNRESOLVED. Current Kiota documents k recomputation and checks constructor
  indices, while retained recursor types and numIndices have separate validation
  and consumption paths. Exact historical pairs/identities and the Kiota
  incompatible numIndices control remain qualified. The
  [packet](../results/research/semantic-import-contract-1/report.md) prepares one
  local grouped documentation question coordinated with lean4export #48; eight
  charged requests, zero scientific launches or external writes, and no catalog
  or authority changes. `NANODA-NESTED-REGRESSION-1` is READY and unstarted.

- Completed `ARENA-INDUCTIVE-ISOLATION-1` on 2026-09-13 with NEGATIVE for an
  eligible existing-byte contribution. Four frozen current tutorial cases retain
  competing dummy-recursor rejection causes; their historical exported candidates
  share those defects. Generic accepting controls do not isolate the intended
  checks, and related complete proof-parameter/positivity fixtures already exist
  upstream. The [assessment](../results/research/arena-inductive-isolation-1/report.md)
  distinguishes current source from historical diagnostics and preserves all
  prior outcomes. Three charged requests; zero scientific launches, new exports
  or external writes. No current checker defect or universal policy is inferred.
  `SEMANTIC-IMPORT-CONTRACT-1` is selected READY and unstarted.

- Completed `NANODA-DEFEQ-CACHE-1` on 2026-09-13 with
  `BOUNDED_UNRESOLVED`. Current Nanoda `4c544ed` and all 38 statically active
  unit tests are bound. Native reduction still rejects open expressions in eager
  mode; the review excludes several invalid cache-witness designs but establishes
  neither a differing-outcome sequence nor global mode equivalence. The
  [assessment](../results/research/nanoda-defeq-cache-1/report.md) records Boolean
  shortcut/closed-open boundaries and positive-cache confounds. Two conservatively
  charged source requests include one invalid-argument call; no scientific launch,
  new export or external research write occurred. No speculative PR is prepared.
  `ARENA-INDUCTIVE-ISOLATION-1` is selected READY and unstarted.

- Completed `NANODA-NAT-DISPATCH-REGRESSION-1` on 2026-09-13 with SUCCESS:
  a test-only patch adds two tests covering six Nat dispatcher operations and
  disabled mode. Both focused tests and all 40 Nanoda library tests passed;
  eight existing doc examples remain ignored. Three source/setup requests and
  two build/test reservations were charged, with no scientific failures,
  new exports, proofs, mutations or external research writes. The
  [result](../results/research/nanoda-nat-dispatch-regression-1/result.json) and
  [indexed local PR draft](../results/action-recommendations/drafts/nanoda-nat-dispatch-regression-pr.md)
  preserve preventive internal-API scope and known Nat.land reuse. The draft is
  held for maintainer-capacity review, refreshed source/duplicates, retesting and
  exact submission approval. `NANODA-DEFEQ-CACHE-1` is selected READY/unstarted.

- Completed `HSBM-PILOT-1` on 2026-09-13 with `NEGATIVE` for its fixed
  two-fresh-commit feasibility threshold. The frozen 36-commit reachable
  non-merge population contains 32 eligible commits; four signal selections
  and two seeded controls were fixed with their descendant sets before review.
  Existing version/projection/imax tests, a current Arena recursor-rule duplicate,
  stale pretty-print inputs and unchanged conversion behavior remove apparent
  opportunities. One Nat dispatcher preventive-test recommendation has explicit
  prior `Nat.land` overlap and is excluded conservatively from fresh yield.
  The [ledger](../results/research/hsbm-pilot-1/ledger.json),
  [result](../results/research/hsbm-pilot-1/result.json) and retained Git bundle
  preserve source-only findings and reproducible selection. Seven charged setup
  requests include the failed DNS attempt; no build, checker, proof, mutation,
  new export or external research write occurred. `NANODA-NAT-DISPATCH-REGRESSION-1`
  is selected READY and unstarted after project-wide comparison.

- On 2026-09-13, after exact owner authorization, submitted the revised
  `SEMANTIC-LET-CONTRACT-1` documentation question as
  [lean4export #48](https://github.com/leanprover/lean4export/issues/48).
  Read-only duplicate and current-format checks preceded submission; a fresh
  readback verified the approved title and body. The
  [submission record](../results/research/semantic-let-contract-1/external-submission-record.json)
  preserves the request and receipts separately from the unchanged research
  closure. The policy remains BOUNDED_UNRESOLVED. `HSBM-PILOT-1` remains READY
  and unstarted; no scientific launch or frontier change occurred.

- Completed `SEMANTIC-LET-CONTRACT-1` on 2026-09-13 with `SUCCESS` for one
  source-qualified clarification packet and an unsubmitted `leanprover/lean4export`
  documentation question. Pinned official checking/inference/reduction interfaces
  and Lean4Lean's value-typing translation premise clarify why erasure alone does
  not settle arbitrary raw-input acceptance. The existing 601-byte pair uses its
  bound variable and changes both the value and enclosing declaration type.
  Seven source requests (including one failed open), retained formal sources and
  independent reviews support the [packet](../results/research/semantic-let-contract-1/clarification-packet.md)
  and [result](../results/research/semantic-let-contract-1/result.json).
  The policy remains bounded unresolved; no catalog/authority change, experimental
  launch, new export byte or external research write occurred. `HSBM-PILOT-1` is
  selected READY and unstarted after project-wide reassessment.

- Completed a bounded external-contribution tracking checkpoint on 2026-09-13.
  A schema-backed canonical ledger now consolidates Arena PRs #176/#181/#182,
  Nanoda PRs #32/#33, and the unsubmitted `NANODA-CACHE-REGRESSION-1` pull-request
  candidate with evidence paths, dated upstream observations, review/check
  summaries, and explicit next actions. Its generated human view is wired into
  `scripts/refresh-current-state`; generation is deliberately offline and does
  not authorize an external write. Nanoda #32/#33 remain open, mergeable, and
  without review activity or reported checks as observed on 2026-09-13. The
  cache candidate remains local pending upstream capacity, fresh preflight, and
  exact human approval. This maintenance checkpoint changes no scientific
  evidence, queue rank, frontier, or external state. `SEMANTIC-LET-CONTRACT-1`
  remains selected READY and unstarted.

- Completed `NANODA-CACHE-REGRESSION-1` on 2026-09-09 with `SUCCESS` at
  current inspected Nanoda `4c544ed4099c8227f07d5de77ad1e69fb0740a27`.
  A two-test module now protects the split inference-cache contract: the valid
  same-pointer `InferOnly`-to-`Check` control succeeds and records results in
  both mode-specific maps; a fresh malformed let is rejected, weak inference
  warms only its unchecked entry, and `Check` on that identical pointer still
  rejects with the exact definitional-equality assertion. The focused pair
  passed and the complete locked suite passed 40 library tests with zero
  failures; eight documentation tests were ignored. A truncated patch hunk was
  caught and repaired before any build. No proof, current mutant, new scientific
  export byte, mutation identity, canonical classification, authority decision
  or external write occurred. The prior exported-input boundary remains bounded
  unresolved. The [result](../results/research/nanoda-cache-regression-1/result.json),
  [assessment](../results/research/nanoda-cache-regression-1/cache-contract-assessment.json),
  [patch](../results/research/nanoda-cache-regression-1/patches/infer-cache-regression.patch)
  and [unsubmitted draft](../results/action-recommendations/drafts/nanoda-infer-cache-regression.md)
  preserve the exact recommendation. Repository closure testing also found that
  the older Arena-let repair regression compared a historical successor claim
  with the mutable current queue and historical bindings with live files. The
  [third repair](../results/research/arena-let-regression-1/post-closure-repair-r3.json)
  now resolves those claims and bindings at their exact commits, binds the
  evolved test by immutable Git blob identity and validates current queue state
  separately. The rerun passed 926 live, 73 frozen-publication and 9
  portfolio-checkpoint tests. `SEMANTIC-LET-CONTRACT-1` is selected READY and
  unstarted.

- Completed a bounded post-closure provenance and CI repair on 2026-09-09
  without changing the `ARENA-LET-REGRESSION-1` scientific outcome or rewriting
  its committed audit. The
  [audit erratum](../results/research/arena-let-regression-1/arena-audit-erratum.json)
  attributes the affirmative-support rule for `either` to the active Lab
  portfolio plan, records both exact candidate/control observer profiles, and
  binds the complete 123-path Arena test inventory plus its derivation command.
  A versioned portfolio-history test adapter now reads current checkout bytes
  while comparing command identity against the original recorded workspace,
  so frozen zero-thread receipts validate from GitHub's Linux checkout without
  rewriting them. Frozen publication-study tests continue to run against their
  attested Git blobs through `scripts/run-unit-tests`; direct discovery against
  the live frontier is not a valid historical-transition check. The selected
  research item remains `NANODA-CACHE-REGRESSION-1`, READY and unstarted. The
  [repair record](../results/research/arena-let-regression-1/post-closure-repair.json)
  binds the successor code, tests, erratum, inventory and validation results.
  GitHub run `34415285434` then exposed a separate path-bound live
  `SURVIVOR-CACHE-1` transition validator. The
  [follow-up repair](../results/research/arena-let-regression-1/post-closure-repair-r2.json)
  preserves that validator and its receipts and installs a scoped checkout-path
  projection around the live unit suite. It also makes the first repair's test
  validate its bound files at commit `7aef82e` rather than silently requiring
  those current tooling paths never to evolve.

- Completed `ARENA-LET-REGRESSION-1` on 2026-09-09 with
  `BOUNDED_UNRESOLVED`. The complete current static Arena inventory at
  `da7a53f8520fb072614956007d7091d0f9a1650f` contains no byte-identical copy
  of either fixed 601-byte let artifact. Its only serialized-let fixtures are
  broad `constlevels` and `rec-missing-ih` cases, while tutorial wiring provides
  only three positive lets; none establishes equivalent negative coverage. The
  retained official profile rejects the candidate and accepts its control, but
  that remains implementation evidence rather than semantic authority. Neither
  a strict `reject` nor Arena's `either` classification has the affirmative
  support required for a new package, so no build-test, checker, proof, mutation,
  new export byte or external action occurred. The
  [audit](../results/research/arena-let-regression-1/arena-audit.json),
  [unresolved-policy packet](../results/research/arena-let-regression-1/unresolved-policy-packet.md),
  and [result](../results/research/arena-let-regression-1/result.json) preserve
  the exact boundary. `NANODA-CACHE-REGRESSION-1` is selected READY and
  unstarted; `SEMANTIC-LET-CONTRACT-1` retains the focused outcome question.

- Completed `NANODA-TEST-NONVACUITY-1` on 2026-09-09 with `SUCCESS`.
  At current Nanoda `4c544ed4099c8227f07d5de77ad1e69fb0740a27`, the existing
  hash test generated 10,000 String and 10,000 Nat pairs while both extensions
  were disabled, so all constructor results were `None` and no literal expression
  was exercised. An assertion-only focused cell failed immediately as predicted.
  The final test-only patch makes disabled behavior explicit, enables extensions
  before fresh DAG construction, requires actual `StringLit`/`NatLit` values and
  payloads, and preserves equal-value hash/interning assertions. The focused test
  passed and the complete locked suite passed 38 library tests with zero failures;
  eight doc tests were ignored. A stable-rustfmt probe rewrote unrelated files,
  so those bytes were rejected and preserved while the patch was rebuilt in a
  clean detached checkout. No checker campaign, proof, mutation identity, export
  byte, canonical classification, authority decision or external write occurred.
  The [result](../results/research/nanoda-test-nonvacuity-1/result.json),
  [assessment](../results/research/nanoda-test-nonvacuity-1/test-effectiveness-assessment.json),
  [patch](../results/research/nanoda-test-nonvacuity-1/patches/final-test-repair.patch)
  and [unsubmitted draft](../results/action-recommendations/drafts/nanoda-literal-hash-test-nonvacuity.md)
  preserve the exact recommendation. The [evidence-linked draft successor](../results/action-recommendations/drafts/nanoda-literal-hash-test-nonvacuity-evidence-v2.md)
  references immutable repository evidence while retaining the content-bound
  original unchanged; its [successor record](../results/research/nanoda-test-nonvacuity-1/recommendation-successor.json)
  binds the paths and hashes. With owner authorization, the evidence-linked
  repair was submitted as [Nanoda PR #33](https://github.com/ammkrn/nanoda_lib/pull/33);
  the [submission record](../results/research/nanoda-test-nonvacuity-1/external-submission-record.json)
  preserves the exact source revision, preflight and fresh validation. `ARENA-LET-REGRESSION-1` is selected READY
  and unstarted.

- Completed `CONTRIBUTION-PORTFOLIO-REVIEW-1` on 2026-09-09 with
  `SUCCESS`: reviewed the constitution, live queue, HSBM proposal, current
  upstream source and contribution dispositions across corpus, checker and
  independent semantics paths. The successor portfolio contains nine READY
  candidates and one result-gated PLANNED reserve, selects `NANODA-TEST-NONVACUITY-1`
  unstarted, and defers the one-thread operational survivor without changing
  its budget or evidence. Arena PRs #181/#182 are merged; Nanoda PR #32 is open.
  The zero-thread recommendation is corrected prospectively: no current defect
  does not rule out a useful preventive regression. No scientific process,
  semantic adjudication or external research write occurred. See the
  [review](../results/research/contribution-portfolio-review-2026-09-09/result.json),
  [recommendation successor](../results/research/contribution-portfolio-review-2026-09-09/zero-thread-recommendation-successor.json),
  and [portfolio plan](research/EXTERNAL_CONTRIBUTION_PORTFOLIO_PLAN.md).

- Completed `SURVIVOR-CACHE-PREDICATE-TRANSFER-1` on 2026-09-09 with
  `SUCCESS`. Both exact mutation identities recompute and replace the same
  pinned `infer` cache-guard occurrence. On the complete two-value `InferFlag`
  domain, `(flag != InferOnly)` and `!(flag == InferOnly)` are false for
  `InferOnly` and true for `Check`, so the existing same-checker staged-cache
  distinction transfers to `nanoda-gen-af1dac9744e9`. One append-only registry
  row records `SURVIVED` / `MEANINGFUL_SEMANTIC` under that internal-only scope.
  Ordinary exported-input reachability remains bounded unresolved; no corpus
  kill, production impact or semantic authority is claimed. Pending survivors
  move from three to two while the modeled 135/142 score and fourteen
  equivalents remain unchanged. No network, build, checker, proof, scientific
  byte, mutation identity or external action occurred. See the
  [assessment](../results/research/survivor-cache-predicate-transfer-1/predicate-transfer-assessment.json),
  [result](../results/research/survivor-cache-predicate-transfer-1/result.json),
  and [report](../results/research/survivor-cache-predicate-transfer-1/report.md).
  `SURVIVOR-THREAD-ONE-DETERMINISM-1` is selected READY and unstarted.

- Completed `NANODA-ZERO-THREAD-UPSTREAM-READINESS-1` on 2026-09-09 with
  `SUCCESS` and a source-bound `NO_GO` for external action. Four bounded public
  GETs bound current `ammkrn/nanoda_lib` master to
  `05055695879dfebb6628a67da88ceca6cd6b0421` (0.4.16), retained the exact
  archive, and retrieved the complete 29-item issue/PR inventory. Current
  `num_threads` remains a public serde-default `usize`, but the dispatcher uses
  parallel checking only above one thread; zero and one call the serial loop,
  which checks every declaration before success reporting. No same-case report
  or regression was found, but current source safety independently makes a new
  defect issue inaccurate. Two conditional request slots were unused. No
  build, checker, proof, new scientific byte, mutation identity or external
  write occurred; canonical mutation classifications and historical evidence
  are unchanged. See the [source assessment](../results/research/nanoda-zero-thread-upstream-readiness-1/current-source-assessment.json),
  [duplicate assessment](../results/research/nanoda-zero-thread-upstream-readiness-1/duplicate-assessment.json),
  [result](../results/research/nanoda-zero-thread-upstream-readiness-1/result.json),
  and [report](../results/research/nanoda-zero-thread-upstream-readiness-1/report.md).
  `SURVIVOR-CACHE-PREDICATE-TRANSFER-1` is selected READY and unstarted.

- Completed `SURVIVOR-THREAD-CONFIG-REGRESSION-1` on 2026-09-08 with
  `SUCCESS`. Two exact offline builds and four strictly ordered checker calls
  reproduced the zero-thread source prediction: baseline and mutant both
  accepted the matching 601-byte control; the baseline rejected the existing
  invalid 601-byte candidate at the bound type-equality assertion; and
  `nanoda-gen-93b21593b0d8` returned the exact clean success message after its
  zero-worker parallel path checked no declarations. All reservations retain
  raw request, process, stdout, stderr, cleanup and hash-chain evidence. Total
  scientific process time was 30.36 seconds; zero network, Lean proof, new
  export byte, mutation identity or external action occurred. The predecessor's
  scoped `MEANINGFUL_SEMANTIC` classification, historical one-thread
  `SURVIVED` status and modeled mutation metrics remain unchanged; the derived
  assurance snapshot refreshed only its producing revision. See the
  [result](../results/research/survivor-thread-config-regression-1/result.json),
  [report](../results/research/survivor-thread-config-regression-1/report.md),
  and [raw ledger](../results/research/survivor-thread-config-regression-1/run-0001/execution/events.jsonl).
  `NANODA-ZERO-THREAD-UPSTREAM-READINESS-1` is selected READY and unstarted.

- Completed `SURVIVOR-THREAD-CONFIG-REACHABILITY-1` on 2026-09-08 with
  `SUCCESS`. `num_threads` is a public `usize` configuration field with serde
  default zero, and config validation imposes no thread bound. The original
  zero-thread path checks every declaration serially; `nanoda-gen-93b21593b0d8`
  instead calls the parallel helper with zero workers, checks no declarations,
  returns normally and permits post-check success reporting. An existing
  601-byte parsed-and-rejected export makes the source counterexample concrete,
  so one append-only registry row records `MEANINGFUL_SEMANTIC` while retaining
  historical `SURVIVED` status and making no corpus-kill or authority claim.
  `nanoda-gen-2bdfe18a9ec2` changes only the one-thread path: successful task
  coverage matches serial checking, but the 16 MiB worker stack, spawn failure
  and joined-panic behavior differ, so its unresolved classification is
  preserved. Pending survivors move from four to three and meaningful survivors
  from three to four; the modeled 135/142 score and fourteen equivalents are
  unchanged. No build, checker, proof, network, new export byte, mutation
  identity or external action ran. See the
  [assessment](../results/research/survivor-thread-config-reachability-1/dispatch-assessment.json),
  [result](../results/research/survivor-thread-config-reachability-1/result.json),
  and [report](../results/research/survivor-thread-config-reachability-1/report.md).
  `SURVIVOR-THREAD-CONFIG-REGRESSION-1` is selected READY and unstarted.

- Completed `SURVIVOR-FVAR-REACHABILITY-1` on 2026-09-08 with
  `SUCCESS`. Pinned Nanoda's public export parser cannot construct
  `Expr::Local`, the only expression form for which `has_fvars` is true.
  Insertion-order induction over parser reconstruction shows that every
  persistent expression has `has_fvars = false`; every exported declaration
  type points directly into that DAG, and every current guard caller receives
  an original parsed declaration. The mutation is therefore `EQUIVALENT` only
  for the pinned public export/checking path. A synthetic internal Local-typed
  declaration remains a source-level counterexample, so the guard is preserved
  as defense in depth and input non-representability is not reported as
  semantic enforcement. One append-only registry row moves pending survivors
  from five to four and equivalent mutants from thirteen to fourteen. The
  historical 184-test match is supporting observation only. No build, checker,
  proof, network request, scientific export byte, mutation identity or external
  action ran. See the
  [assessment](../results/research/survivor-fvar-reachability-1/reachability-assessment.json),
  [result](../results/research/survivor-fvar-reachability-1/result.json), and
  [report](../results/research/survivor-fvar-reachability-1/report.md).
  `SURVIVOR-THREAD-CONFIG-REACHABILITY-1` is selected READY and unstarted.

- Completed `SURVIVOR-UNIVERSE-EQUIVALENCE-1` on 2026-09-08 with
  `SUCCESS`. The `diff < 0` to `diff <= 0` mutation is outcome-equivalent at
  pinned Nanoda's public level-comparison entrypoints. Mutual source induction
  over normalization and recursive comparison closes every reachable
  right-`Zero`, diff-zero state. The unrestricted private function is not
  equivalent: raw `leq_core(Max(Zero,Zero), Zero, 0)` returns `true` in the
  baseline and `false` in the mutant, but public `leq` simplifies that lhs to
  `Zero` first. One append-only registry row classifies the mutant
  `EQUIVALENT` under this explicit scope; pending survivors move from six to
  five. The historical 163-test match is supporting observation only. No build,
  focused scientific test, checker campaign, Lean proof, network request, new
  export byte, mutation identity or external action ran. See the
  [analysis](../results/research/survivor-universe-equivalence-1/equivalence-analysis.json),
  [result](../results/research/survivor-universe-equivalence-1/result.json), and
  [report](../results/research/survivor-universe-equivalence-1/report.md).
  `SURVIVOR-FVAR-REACHABILITY-1` is selected READY and unstarted.

- Completed `SURVIVOR-UNIVERSE-DIFF-1` on 2026-09-08 with `SUCCESS`.
  The existing non-Prop theorem reaches pinned Nanoda
  `leq_core(Succ Zero, Zero, 0)`: the baseline skips the original guard,
  recurses to `(Zero, Zero, -1)` and returns `false`, while the mutant's
  broadened guard returns `false` immediately. This is exact reachability and a
  control-flow difference, not a local Boolean difference or whole-checker
  equivalence. The historical 163-test no-difference record is consistent but
  not semantic authority. No build, checker, proof, network, scientific-byte
  or external-action launch ran, and the canonical survivor classification is
  unchanged. See the
  [result](../results/research/survivor-universe-diff-1/result.json),
  [assessment](../results/research/survivor-universe-diff-1/reachability-assessment.json),
  and [report](../results/research/survivor-universe-diff-1/report.md).
  `SURVIVOR-UNIVERSE-EQUIVALENCE-1` is selected READY and unstarted after the
  project-wide closure review.

- Completed `SURVIVOR-CACHE-EXPORT-1` on 2026-09-08 with
  `BOUNDED_UNRESOLVED`. Source and export-format analysis confirms the Eq
  K-recursor weak-major route, but each assessed ordinary carrier origin
  strongly checks the candidate major before the desired weak visit. A prior
  constant carrier also has its type rebuilt into the fresh checker DAG, so it
  does not automatically preserve the exact expression pointer required by the
  cache key. This is an exact pinned-source construction boundary, not a general
  impossibility proof. No build, checker, proof, network, scientific export
  pair or external action ran, and the canonical survivor classification is
  unchanged. See the [result](../results/research/survivor-cache-export-1/result.json),
  [boundary](../results/research/survivor-cache-export-1/construction-boundary.json),
  and [report](../results/research/survivor-cache-export-1/report.md).
  `SURVIVOR-UNIVERSE-DIFF-1` is selected READY and unstarted after the
  project-wide closure review.

- Completed `SURVIVOR-CACHE-1` on 2026-09-08 with `SUCCESS` for an exact
  internal cache-contract comparison. Both controls and the baseline malformed
  let candidate passed; the mutant candidate failed at the frozen no-rejection
  assertion after reusing the warmed no-check cache. The result is scoped to the
  same-checker internal harness and does not establish exported-input reachability,
  production impact, semantic authority or a corpus kill. The canonical survivor
  classification remains unchanged. See the [result](../results/research/survivor-cache-1/result.json),
  [report](../results/research/survivor-cache-1/report.md), and
  [closure review](../results/research/queue-reviews/2026-09-08-survivor-cache-closure-strategic.json).
  `SURVIVOR-CACHE-EXPORT-1` is selected READY and unstarted after a project-wide
  reassessment.

- Completed `ALT-TRANSFER` on 2026-09-08 with `SUCCESS` for a bounded
  feasibility assessment and **NO_GO** phase decision. Four fresh queries,
  five primary-source groups, one pinned code inspection and the local exposure
  audit exclude the three assessed routes: known observations, an unestablished
  Ferriprove checker path, and Lean4Less ancestry/translation confounding.
  No transfer design, checker/proof/build launch, scientific byte or external
  research action occurred. No general impossibility claim is made. See the
  [entry point](../results/research/alt-transfer-2026-09-08/README.md),
  [result](../results/research/alt-transfer-2026-09-08/result.json), and
  [queue review](../results/research/queue-reviews/2026-09-08-alt-transfer.json).
  `TRANSFER-HOLDOUT-INTAKE-1` is selected WAITING for a supplied independent
  input/custody package or concrete functioning target evidence and separate
  authorization; no successor starts. Six pending survivors remain unchanged.

- Completed `SURVIVOR-LET-ASSOCIATION-1` on 2026-09-08 with `SUCCESS`.
  The canonical registry now classifies `nanoda-gen-9face4e6a6f7` as
  `KILLED` / `MEANINGFUL_SEMANTIC` from the fresh fixed-pair result while
  reusing the exact existing 21ef candidate, control and expected-outcome
  bytes. No 9face corpus artifact was created. The unchanged historical
  admission producer re-renders its preserved 606-line successor, and the
  prior reuse closure validates through an explicit historical substitution
  map. Pending survivors move from seven to six; the modeled denominator stays
  144 and its numerator moves from 134 to 135. The declaration-validation
  catalog and authority state remain unchanged. See the
  [result](../results/research/survivor-let-association-1/result.json),
  [association](../results/mutants/nanoda-gen-9face4e6a6f7/reuse-association-v1.json),
  and [transition](../results/research/survivor-let-association-1/historical-transition.json).
  `ALT-TRANSFER` is selected WAITING for separate phase authorization and
  fresh methods/independence review.

- Completed `SURVIVOR-LET-REUSE-1` on 2026-09-08 with `SUCCESS` for the
  exact existing-regression comparison. Both the pinned baseline and freshly
  built `nanoda-gen-9face4e6a6f7` accepted the 601-byte control. The baseline
  candidate reached the source-bound let-value `assert_def_eq` refusal, while
  the mutant accepted. One overly strict output normalizer classified the first
  baseline receipt as `CRASH`; that receipt and cost remain, and a committed
  tooling revision replayed only that cell. See the
  [result](../results/research/survivor-let-reuse-1/result.json),
  [report](../results/research/survivor-let-reuse-1/report.md), and
  [association recommendation](../results/research/survivor-let-reuse-1/association-recommendation.json).
  Canonical classifications remain unchanged because the frozen admission
  producer accepts only its two historical witnesses. `SURVIVOR-LET-ASSOCIATION-1`
  is selected WAITING for a separately authorized no-duplicate successor.

- Completed `ALT-SURVIVORS` on 2026-09-08 with `SUCCESS` for a fixed
  existing-regression reuse proposal. It selects `nanoda-gen-9face4e6a6f7`,
  preserving all seven pending classifications. The exact let pair, pinned
  source, old observations, comparative rationale and finite future execution
  gates are bound in the
  [proposal package](../results/research/alt-survivors-2026-09-08/README.md).
  No checker, proof, setup/build, scientific byte variant, research-network
  request or external research action ran. Required closure verification is in
  the [validation record](../results/workflow-refresh/alt-survivors-2026-09-08/validation.json).
  `SURVIVOR-LET-REUSE-1` is selected WAITING and unstarted; execution is PAUSED
  pending separate owner authorization and exact prelaunch gates. The prior
  authorization placeholder was resolved directly by the owner's decision,
  not executed as a second research item.

- Completed `CVC-5-CONDITIONAL` on 2026-09-08 with `SUCCESS` for an
  existing-evidence reuse package and `REUSE` phase decision. The
  [entry point](../results/research/conditional-validation-contracts/cvc-5-conditional/README.md)
  connects four checked A7 obligations, exact assumptions, all finite observations
  and the existing two-stream serialization regression. No new scientific byte,
  proof, observer, setup/build, research-network launch or external action ran.
  See the [result](../results/research/conditional-validation-contracts/cvc-5-conditional/result.json),
  [review](../results/research/queue-reviews/2026-09-08-cvc-5-conditional.json), and
  [validation](../results/workflow-refresh/cvc-5-conditional-2026-09-08/validation.json).
  `CVC-NEXT-AUTHORIZATION` is selected WAITING and unstarted; further execution
  is PAUSED pending owner authorization of a named successor or substantive
  upstream guidance. No READY item is manufactured to maintain activity.

- Completed `CVC-4-OWNERSHIP-1` on 2026-09-08 with `SUCCESS`: both pinned
  observers accepted the exact parameter-record control and then refused the
  unowned candidate at their ownership checks. The serializer regression
  preserves predecessor bytes and ASTs; no invalid accepted proof is shown.
  Four new plus twelve old reservations reach the cumulative sixteen-launch
  ceiling; new process time is 0.139021 seconds. See the
  [result](../results/research/conditional-validation-contracts/cvc-4-ownership-1/result.json),
  [report](../results/research/conditional-validation-contracts/cvc-4-ownership-1/report.md),
  [review](../results/research/queue-reviews/2026-09-08-cvc-4-ownership-1.json), and
  [validation](../results/workflow-refresh/cvc-4-ownership-1-2026-09-08/validation.json).
  `CVC-5-CONDITIONAL` is selected READY and unstarted for a bounded
  existing-evidence reuse package and phase decision; no new experiment starts.

- Contributed declaration-level evidence on 2026-09-08 to the existing
  [Lean #12747](https://github.com/leanprover/lean4/issues/12747#issuecomment-5584574955)
  normalization issue. The comment links the exact CVC-4 right-successor
  artifact and replay, the corrected right-zero controls, the conditional A7
  semantic evidence, and a source-only comparison through master commit
  `c40679c`. It asks whether a focused C++ kernel regression or fix remains
  useful relative to PRs #13366/#14356. No current-master execution, kernel
  soundness claim, normative-source promotion, or new Nanoda/Kiota defect
  recommendation is asserted. The public interaction is indexed in
  [Upstream issue participation](UPSTREAM_ISSUES.md).

- Completed `CVC-4-ADAPTER-REVIEW` on 2026-09-08 (UTC) with `SUCCESS`
  for an existing-evidence scientific-input review and `SUCCESSOR` decision.
  One exact unused `v` parameter-level insertion is proposed for each retained
  ownership stream; all old bytes, observations and charges remain unchanged.
  The candidate is `CHECKED_UNSUPPORTED`, not a checked invalid proof. See the
  [assessment](../results/research/conditional-validation-contracts/cvc-4-adapter-review/assessment.json),
  [proposal](../results/research/conditional-validation-contracts/cvc-4-adapter-review/successor-proposal.json),
  [report](../results/research/conditional-validation-contracts/cvc-4-adapter-review/report.md),
  [review](../results/research/queue-reviews/2026-09-08-cvc-4-adapter-review.json)
  and [validation](../results/workflow-refresh/cvc-4-adapter-review-2026-09-08/validation.json).
  `CVC-4-OWNERSHIP-1` is selected READY and unstarted: one pair, four new
  launches of at most 30 seconds, and 5400 active seconds including engineering,
  after exact committed prelaunch gates. This review generated no scientific
  byte variant and ran no proof, observer, setup or research-network launch.

- Completed `CVC-4-CONDITIONAL` on 2026-09-07 with `BOUNDED_UNRESOLVED`
  at a characterized frozen-byte/importer boundary. The right-successor and zero
  pairs completed: Nanoda accepted E-POS while official Lean refused it, and both
  refused the zero-invalid candidate after accepted controls. Nanoda's ownership
  control failed in parsing because unused declared `v` lacks a parameter-level
  record. Neither ownership candidate ran. The parser error is not a model
  counterexample or ownership rejection. No same-byte/binary repair remains.
  Original reporting failure and all twelve charges remain preserved, with four
  launch slots unused, 2830.644582 active seconds and
  0.386228 process seconds. No setup or research-network launch
  ran. See the [result](../results/research/conditional-validation-contracts/cvc-4-conditional/result.json), [report](../results/research/conditional-validation-contracts/cvc-4-conditional/report.md),
  [adapter diagnosis](../results/research/conditional-validation-contracts/cvc-4-conditional/adapter-boundary.json), [review](../results/research/queue-reviews/2026-09-07-cvc-4-conditional.json)
  and [validation](../results/workflow-refresh/cvc-4-conditional-2026-09-07/validation.json).
  `CVC-4-ADAPTER-REVIEW` is selected READY and unstarted. A7 and refinement gaps
  remain explicit; withdrawn imax defect recommendations remain withdrawn.

- Completed `CVC-A7-REPAIR-1` on 2026-09-07 with `SUCCESS`: all four original
  Lab obligations are checked under `CVC-U1-A7`. Fresh signature and exact
  nine-type-pair/seven-assumption baseline passed, then the first proof attempt
  proved encoding, preservation, positive acceptance and boundary rejection.
  The item used three builds, 1191.641326 active seconds including engineering,
  and 4.791141 compiler seconds; A7 totals are five builds and 1247.239069 active
  seconds. Neither cap was exhausted. Historical failures remain unchanged.
  See the [result](../results/research/conditional-validation-contracts/cvc-a7-repair-1/result.json),
  [report](../results/research/conditional-validation-contracts/cvc-a7-repair-1/report.md),
  [queue review](../results/research/queue-reviews/2026-09-07-cvc-a7-repair-1.json), and
  [validation](../results/workflow-refresh/cvc-a7-repair-1-2026-09-07/validation.json).
  `CVC-4-CONDITIONAL` is selected READY and unstarted to map the checked result
  to exact artifacts and implementation behavior. Assumptions remain explicit;
  arbitrary-byte parsing and executable-validator refinement are unproved.

- Closed `CVC-3-CONDITIONAL` on 2026-09-07 with `BOUNDED_UNRESOLVED` at
  an immutable baseline-audit implementation boundary. The unchanged signature
  compiled as attempt 1. Attempt 2's fixed baseline compiled, but the frozen
  parser rejected universe-decorated axiom output; wrapped type headers and
  linter warnings expose additional transcript incompatibilities. No Lab proof
  or observer ran. Both reservations, raw failures, and the completed
  55.597743-second session are retained in the
  [result](../results/research/conditional-validation-contracts/cvc-3-conditional/result.json),
  [diagnostic](../results/research/conditional-validation-contracts/cvc-3-conditional/stop-diagnostic.json),
  [report](../results/research/conditional-validation-contracts/cvc-3-conditional/report.md), and
  [queue review](../results/research/queue-reviews/2026-09-07-cvc-3-conditional.json).
  `CVC-A7-REPAIR-1` is selected READY and unstarted for an explicit parser/protocol
  successor followed by the original bridge, gated by a new counted baseline.
  At most four new builds preserve the combined six-build A7 ceiling; consumed
  research time carries forward. Required closure validation is retained in the
  [validation record](../results/workflow-refresh/cvc-3-conditional-2026-09-07/validation.json).

- Completed `CVC-CONDITIONAL-1` on 2026-09-07 with `SUCCESS` for the minimal
  A7 protocol/runner preparation. No Lean, signature, baseline, Lab proof,
  dependency or observer launch ran. All 607 full-payload tests pass (534
  current and 73 unchanged historical; no skips), including 19 new pure A7
  regressions. The existing process tests consumed 23 reserved launches / 115
  reserved seconds within the 64 / 320 cap. Exact types, seven comparator
  assumptions, original semantic inputs, runner and payloads are bound in the
  [manifest](../config/cvc-u1-a7-proof-0001.json). See the
  [result](../results/research/conditional-validation-contracts/cvc-conditional-1/result.json),
  [report](../results/research/conditional-validation-contracts/cvc-conditional-1/report.md),
  [entry review](../results/research/conditional-validation-contracts/cvc-conditional-1/entry-review.json),
  and [queue review](../results/research/queue-reviews/2026-09-07-cvc-conditional-1.json).
  `CVC-3-CONDITIONAL` is selected READY and unstarted. Its counted baseline
  remains uncompiled; no assumptions are discharged and no Lab result is checked.
  Final administrative closure validation is retained in the
  [validation record](../results/workflow-refresh/cvc-conditional-1-2026-09-07/validation.json).

- Completed `CVC-AXIOMS-1` on 2026-09-06 with `SUCCESS` for a source-only
  assumption review and `SUCCESSOR` recommendation. Both retained comparator
  reports contain the same seven assumptions. The two omitted helpers concern
  opaque runtime equality and a partial-function bridge; all four helper axioms
  remain substantive conditional trust assumptions, not discharged facts.
  Six source files were reviewed; two match predecessor hashes and four are
  newly hashed local sources under the already-selected runtime release, with
  source-to-binary correspondence unproved. No checked Lab result or research
  launch is claimed. See the
  [assessment](../results/research/conditional-validation-contracts/cvc-axioms-1/assessment.json),
  [report](../results/research/conditional-validation-contracts/cvc-axioms-1/report.md),
  and [review](../results/research/queue-reviews/2026-09-06-cvc-axioms-1.json).
  `CVC-CONDITIONAL-1` is selected READY and unstarted for a new protocol/runner
  under explicitly conditional model `CVC-U1-A7`; `CVC-3-CONDITIONAL` is PLANNED.
  CVC-2's allowlist and the terminal CVC-3 failure remain unchanged. Required
  closure validation and its separately instrumented regression fixtures are
  retained in the
  [validation record](../results/workflow-refresh/cvc-axioms-1-2026-09-06/validation.json).

- Closed `CVC-3` on 2026-09-06 with `BOUNDED_UNRESOLVED` at an
  immutable assumption boundary. The unchanged signature compiled as attempt 1;
  proof attempt 2 failed with local proof errors and exposed two unlisted axioms
  in both mandatory imported comparator reports: `Lean.Level.instLawfulBEqLevel`
  and `Lean.Level.isExplicitSubsumedAux_eq`. No checked Lab result is claimed.
  All two reservations and raw failures are retained; the run used 199.947 active
  seconds and 2.358 compilation seconds. No observer or dependency launch ran.
  The allowlist and all predecessor evidence remain unchanged. See the
  [result](../results/research/conditional-validation-contracts/cvc-3/result.json),
  [diagnostic](../results/research/conditional-validation-contracts/cvc-3/stop-diagnostic.json),
  and [review](../results/research/queue-reviews/2026-09-06-cvc-3.json).
  `CVC-AXIOMS-1` is selected READY and unstarted for a bounded source-only
  assumption review. CVC-4 and CVC-5 remain conditional PLANNED stages.
  Required full-payload verification passed 575 tests (502 current and 73
  unchanged historical; no skips). The closure validator also passes in a
  fresh full-history clone without proof payloads. Exact checks are retained in
  the [validation record](../results/workflow-refresh/cvc-3-2026-09-06/validation.json).

- Completed `CVC-RUNNER-2` on 2026-09-06 with `SUCCESS` for the bounded runner
  implementation and instruction repair. Required current/historical checks
  pass; no Lean, signature, proof or checker ran. The exact manifest and
  implementation checkpoint are bound by the
  [entry review](../results/research/conditional-validation-contracts/cvc-runner-2/entry-review.json).
  CVC-3 is selected READY and unstarted. The failed CVC-RUNNER-1 evidence and
  broader assurance disagreements remain unchanged.

- Closed `CVC-RUNNER-1` on 2026-09-06 with `BOUNDED_UNRESOLVED`.
  A SIGTERM cancellation fixture terminated the root test controller and left
  one five-second reservation without a terminal receipt. The worker reported
  two additional discovery runs without durable fixture receipts. Actual process
  duration and cap compliance are unknown; exact tested bytes were not bound
  before concurrent edits. Preserve these failures and the untested later draft.
  The live endpoint now refuses execution and session start. No Lean, signature,
  proof or checker ran. See the
  [result](../results/research/conditional-validation-contracts/cvc-runner-1/result.json),
  [report](../results/research/conditional-validation-contracts/cvc-runner-1/report.md),
  and [review](../results/research/queue-reviews/2026-09-06-cvc-runner-1.json).
  `CVC-RUNNER-2` is selected READY and unstarted for an explicit supervised
  fixture/accounting repair and completion of the fixed runner controls.
  CVC-3 through CVC-5 remain PLANNED. Required closure verification is recorded
  in the [validation record](../results/workflow-refresh/cvc-runner-1-2026-09-06/validation.json).

- Completed `CVC-PREP-2` on 2026-09-06 with `SUCCESS`. The explicit
  controller successor fixes the path-ordering defect and compiled all 10
  remaining upstream modules once (24.381 compilation seconds) under committed
  checkpoint `a9a0701`. The complete 37-module bundle contains 141 verified
  products, including all 119 preserved products from CVC-PREP-1. The original
  27 modules were not replayed; CVC-PREP-1 remains `BOUNDED_UNRESOLVED` with its
  original evidence unchanged. All 60 prelaunch control checks and four closure
  accounting regressions passed. No Lab signature, proof or checker ran.
  See the [result](../results/research/conditional-validation-contracts/cvc-prep-2/result.json),
  [report](../results/research/conditional-validation-contracts/cvc-prep-2/report.md),
  and [stopping-point review](../results/research/queue-reviews/2026-09-06-cvc-prep-2.json).
  `CVC-RUNNER-1` is selected READY and unstarted; CVC-3 through CVC-5 remain
  PLANNED. Combined preparation cost is 50.51 active minutes and 49.755
  compilation seconds. Required full-payload, historical and current-state
  checks are retained in the
  [validation record](../results/workflow-refresh/cvc-prep-2-2026-09-06/validation.json).

- Closed `CVC-PREP-1` on 2026-09-06 with `BOUNDED_UNRESOLVED` after
  27 successful upstream module compilations (25.374 compilation seconds).
  All 119 output products match their recorded identities. A controller
  Path-component versus path-string ordering defect stopped the run before
  reserving module 28; no failed module was retried and no Lab file was
  elaborated. The exact source/runtime/controller checkpoint is `a28939b`.
  The [result](../results/research/conditional-validation-contracts/cvc-prep-1/result.json),
  [report](../results/research/conditional-validation-contracts/cvc-prep-1/report.md),
  and [review](../results/research/queue-reviews/2026-09-06-cvc-prep-1.json)
  preserve the partial bundle, failed engineering checks and a reproducing
  ordering regression. `CVC-PREP-2` is selected READY and unstarted to repair
  that control through an explicit successor and compile only the remaining
  10 modules. CVC-RUNNER-1 and CVC-3 through CVC-5 remain PLANNED. Required
  verification passed 475 full-payload tests (402 current, 73 unchanged
  historical; no skips). Exact commands and outcomes are retained in the
  [validation record](../results/workflow-refresh/cvc-prep-1-2026-09-06/validation.json).

- Completed `ALT-PAYLOADS` on 2026-09-06 with `SUCCESS` for an exact
  isolated dependency preparation proposal, labeled
  `STATIC_DEPENDENCY_REPAIR_PROPOSAL_UNEXECUTED`. The corrected static closure
  contains 37 modules (12 Lean4Lean, 25 Batteries); four public-meta import
  dependencies were absent from the prior inventory. All selected source
  identities match their pinned evidence. Defined direct compiler commands,
  isolated paths, complete-runtime binding prerequisites, and separate finite
  preparation/runner budgets. No build, Lean/Lake invocation, download,
  installation, Lab elaboration or checker execution ran. See the
  [proposal](../results/research/conditional-validation-contracts/alt-payloads/proposal.json),
  [report](../results/research/conditional-validation-contracts/alt-payloads/report.md), and
  [stopping-point review](../results/research/queue-reviews/2026-09-06-alt-payloads.json).
  `CVC-PREP-1` is selected READY and unstarted; `CVC-RUNNER-1` and CVC-3 through
  CVC-5 remain PLANNED. Required validation results are retained in the
  [validation record](../results/workflow-refresh/alt-payloads-2026-09-06/validation.json).

- Closed `OPS-UPSTREAM-1` on 2026-09-06 with `BOUNDED_UNRESOLVED`:
  the required GitHub CLI preflight failed authentication, so no disposition or
  duplicate-inventory GET request ran. Current Arena changes are unknown; the
  last known PR #181/#182 submissions and the owner-deferred Kiota clarification
  are preserved. Repair access with `gh auth login -h github.com --web`, then
  rank a fresh bounded check after successful preflight. No browser fallback,
  checker launch, build, external message, or repeated polling occurred. See the
  [status packet](../results/research/ops-upstream-1/status-packet.json),
  [report](../results/research/ops-upstream-1/report.md), and
  [stopping-point review](../results/research/queue-reviews/2026-09-06-ops-upstream-1.json).
  `ALT-PAYLOADS` is selected READY and has not started. The full-payload suite
  passed 444 tests (371 current, 73 unchanged historical; no skips), along with
  historical/snapshot, queue, evidence and contribution-catalog checks. Exact
  commands and outcomes are retained in the
  [validation record](../results/workflow-refresh/ops-upstream-1-2026-09-06/validation.json).

- Completed `CVC-2` on 2026-09-06 with `SUCCESS` for one interpretation
  contract and proof-target specification, labeled
  `SPECIFICATION_PROPOSAL_UNCHECKED`. Model CVC-U1 fixes the supplied sort
  value, has two exact required acceptance artifacts and two model boundary
  examples, and states an encoding bridge and one preservation target without
  assuming checker correctness. Structural extraction and integrity checks
  bind the byte/AST/source mappings; no proof builds or checker launches ran.
  The finite CVC-3 protocol is specified but not executable. A read-only
  inventory found missing compiled verification dependencies despite an
  installed matching Lean runtime. See the
  [report](../results/research/conditional-validation-contracts/cvc-2/report.md)
  and [stopping-point review](../results/research/queue-reviews/2026-09-06-cvc-2.json).
  `OPS-UPSTREAM-1` is selected READY; `ALT-PAYLOADS` is the second eligible
  diagnostic proposal. Neither has started; CVC-3 through CVC-5 stay PLANNED.
  The required full-payload validators, contribution catalog and 444 tests
  (371 current, 73 unchanged historical; no skips) passed, with all 27 CVC-2
  tests also passing after the final protocol-accounting clarification. Exact
  commands and outcomes are retained in the
  [validation record](../results/workflow-refresh/cvc-2-2026-09-06/validation.json).

- Completed `CVC-1` on 2026-09-06 with an evidence-backed `EXTEND` decision:
  reuse pinned Lean4Lean universe semantics/comparison results and define the
  missing Lab artifact-interpretation contract next. Compared all three bounded
  fragments using five queries, eight primary sources and four code inspections
  in one session. Preserved explicit helper axioms, active inductive-model holes,
  a source-document inconsistency, and version/import gaps. This is source review,
  not proof reproduction or validator correctness. No builds, checker launches,
  installations, authority promotions or external messages occurred. See the
  [assessment](../results/research/conditional-validation-contracts/cvc-1/report.md)
  and [stopping-point review](../results/research/queue-reviews/2026-09-06-cvc-1.json).
  `CVC-2` is selected READY; it has not started.
  The required full-payload validators, contribution catalog, and 417 tests
  (344 current, 73 unchanged historical; no skips) passed. Exact commands and
  results are retained in the
  [validation record](../results/workflow-refresh/cvc-1-2026-09-06/validation.json).

- Recorded the owner-requested conditional-validation-contracts phase plan and
  ranked work queue on 2026-09-06. The first selected item is a bounded literature
  and reuse assessment; the proposed formal fragment is deliberately undecided.
  Added stopping-point ranking, finite item budgets, explicit entry gates,
  subordinate GitHub coordination, and queue-integrity validation. This is a
  planning transition, not execution or a new semantic result. See the
  [initial ranking decision](../results/research/queue-reviews/2026-09-06-initial.json).

- Completed owner-approved external follow-through for the corpus-integration
  successor on 2026-09-05. A latest-upstream Arena preflight at `8ae1d84`
  found one intervening Sokobanoda revision bump and no exact match for either
  pair. The complete-recursor positivity artifact was submitted separately as
  [Arena PR #181](https://github.com/leanprover/lean-kernel-arena/pull/181),
  and the proof-parameter `either` characterization as
  [Arena PR #182](https://github.com/leanprover/lean-kernel-arena/pull/182).
  Both initial pairs passed their focused two-test Arena builds. Maintainer
  review later narrowed PR #181 to one `corner-cases/positivity-whnf` test with
  outcome `either`; that revised test builds 1/1. The owner deferred
  the separate Kiota clarification pending Arena feedback; no Kiota issue was
  created.
- Completed the authorized ecosystem-closure/autonomy successor on 2026-09-05.
  Validation passed 385 full-payload tests (312 current, 73 historical), with
  no skips; final focused and clean-clone checks also passed. Historical
  transition/tampering regressions preserve all frozen study content.
  Fresh GET-only inventories cover all four named repositories. Arena #176 is
  merged; four old imax/projection implementation-issue recommendations are
  withdrawn in light of the documented `either` policy, without changing raw
  disagreements or treating corpus policy as normative authority. Current
  Kiota `2d2a9fa` still accepts the proof-parameter candidate while the pinned
  official observer rejects it; both accept the control. One concrete Kiota
  contract-clarification draft remains human-gated; two Arena companion
  proposals are explicitly deferred pending current-toolchain integration.
- Preregistered two existing survivors at `18bd47b` before execution. Both
  yielded small distinguishing witnesses with accepted controls and pinned
  official rejection of the candidates (six launches each). No new mutant,
  registry promotion or score change was made. The nine-member canonical
  pending set now includes two witnessed candidates awaiting admission review.
  Three isolated offline builds and 16 total checker launches stayed within
  the fixed bounds. See the generated [successor report](research/ECOSYSTEM_CLOSURE_REPORT.md)
  and its bound decision packet for exact identities, raw outputs and limits.
- Replaced unconstrained campaign entry with exact authorized manifests,
  finite phase/total budgets, persisted attempt accounting, exclusive ownership,
  interruption/resume and process-group termination. Retired the resetting
  outer generator. A fresh full-history clone materialized and validated the
  exact proof-pair inputs without rerunning checkers. Mechanical operation
  assumes reviewed scripts and a trusted local filesystem; it is not a security
  sandbox or automatic authorization for more research.

- Closed publication-study Gates 11–12 with the literal preregistered
  `STRONG_POSITIVE / BOUNDED_PILOT / PUBLISH_BOUNDED` decision and a separate
  attestation of content commit `4cd21c6`. The bounded finding completes one
  missing control for a known negative. Completed the constitutional and
  operational [project review](PROJECT_REVIEW.md), added script-first refresh
  and historical validation workflows, and stopped this research frontier.
  Final validation passed 375 tests with full local payloads and no skips.
- Completed publication-study Gate 10 under the exact frozen Gate-9 protocol
  from `3429ca1412dc5a33259ef432e9b64670a5be4f54`. Run
  `publication-study-theorem-control-0001` charged one pair and eight checker
  launches, used 3.875 active seconds, and persisted `ISOLATED_SUCCESS`.
  All four frozen observers accepted the new matched theorem control and
  rejected the unchanged M6 negative with theorem-Prop attribution. The
  incremental result is completion of a missing control for a known negative,
  not discovery of a new negative or implementation defect.
- Added a disk-backed `scripts/run-campaign` supervisor for already-generated
  bounded mutation batches. It binds the selected mutants and source inputs,
  records phase-level interruptions and logs, adopts pre-existing completed
  build/execution evidence, and resumes without conversational state. Build
  validation now persists each mutant result, matching the existing
  per-mutant execution checkpoint. The unattended loop is deliberately limited
  to build validation, coverage-guided execution, and assurance refresh;
  witness design, semantic classification, and external publication remain
  human or model-review work.
- Created the initial durable project scaffold.
- Identified upstream Lean Kernel Arena as `https://github.com/leanprover/lean-kernel-arena`.
- Cloned Lean Kernel Arena at `external/lean-kernel-arena`.
- Created Arena Python 3.13 virtualenv at `.venv-arena` and installed Arena
  Python dependencies.
- Built `nanoda` through Arena and validated the smoke run:
  `scripts/run-arena --checker nanoda --test constlevels`.
- Defined the normalized outcome vocabulary and manually controlled mutant
  registry format.
- Added a conservative mutation report command that computes current counters
  from repository state.
- Added a first line-oriented minimizer that preserves an external mechanical
  distinction predicate.
- Registered and tested first nanoda mutant `nanoda-0001`.
- Built the complete Arena test corpus with:
  `../../.venv-arena/bin/python ./lka.py build-test --skip-declined-by nanoda`
  from `external/lean-kernel-arena`.
- Ran both mutated and baseline nanoda over the materialized corpus and compared
  normalized outcomes.
- Added `scripts/run-mutant`, a one-mutant orchestrator that applies a mutation
  spec, builds baseline and mutant checker states, runs Arena, normalizes
  outcomes, compares, updates registry status, and restores baseline source.
- Added the first exact replacement mutation spec at
  `mutations/nanoda-0001.json`.
- Validated the automated loop with:
  `scripts/run-mutant nanoda-0001 --test tutorial/012_nonPropThm`.
- Hardened normalization to reject unknown statuses, missing or duplicate test
  names, and full-run inventories that differ from the materialized corpus.
- Registered and ran semantic mutant `nanoda-0002`, which skips the
  definitional-equality check between a definition body's inferred type and its
  declared type.
- Registered narrow candidates `nanoda-0003` and `nanoda-0004`, targeting
  constant universe-argument ownership and lambda binder validation.
- Ran `nanoda-0003` over the full corpus and found the first meaningful
  survivor: zero normalized differences across all 197 materialized tests.
- Generated a nine-line NDJSON witness outside the current corpus that baseline
  nanoda rejects and `nanoda-0003` accepts, proving the survivor is not an
  equivalent mutation.
- Added a native LLVM 22 per-test Rust coverage collector with resumable,
  source-digest-checked collection state and mechanical baseline-outcome
  validation.
- Collected coverage for all 197 materialized nanoda tests across 20 Rust source
  files and built schema-2 forward/reverse indexes for 3,451 canonical covered
  source locations. The lower count is not a coverage regression: schema 2
  uses canonical executable regions from `llvm-cov export`, while schema 1
  counted rendered source lines from `llvm-cov show`.
- Added `scripts/schedule-mutant` and `scripts/run-mutant-scheduled` for
  fastest-first coverage-guided mutation execution with early kill and baseline
  restoration.
- Verified the scheduler reproduces `nanoda-0001`'s kill after executing 7 of
  67 covering tests, and exhausts all 120 covering tests for surviving
  `nanoda-0003`.
- Reproduced `nanoda-0002`'s kill after 8 of 167 covering tests and classified
  `nanoda-0004` as survived without witness after all 112 covering tests.
- Added a tracked coverage identity snapshot binding all local coverage files,
  197 corpus inputs totaling 9,506,646,641 bytes, baseline outcomes, checker
  source, Arena revision, configuration, and producer scripts by SHA-256.
- Added a `syn`-based Rust mutation parser plus deterministic generation,
  registration, isolated build validation, exact occurrence replacement, and
  resumable coverage-guided batch execution.
- Completed active batch `nanoda-syntax-0003`: 12 of 12 mutants built, 1 was
  killed, and 11 survived after executing 611 of 685 scheduled test-mutant
  pairs in 5,356.7 seconds.
- Confirmed the `nanoda-0003` witness with Arena's unmodified official Lean
  4.33 checker: the witness was rejected for an undefined universe parameter,
  while the declared-universe positive control was accepted.
- Promoted that witness into the controlled augmented corpus and verified that
  baseline nanoda rejects it while `nanoda-0003` accepts it.
- Produced `results/assurance/milestone-1.json`; all eight Milestone 1 checks
  pass.
- Defined a versioned artifact graph schema and attested 29 nodes spanning
  repositories, validators, toolchains, configuration, scripts, corpora,
  mutation definitions, coverage, runs, comparisons, witnesses,
  classifications, and reports.
- Added recursive current/stale/missing evaluation, historical and superseded
  lifecycle states, dependency-digest explanations, and report gates that
  reject stale inputs.
- Mechanically simulated validator-source, corpus, mutation-model, and
  expected-semantics changes; every required descendant became stale.
- Produced `results/assurance/milestone-2.json`; all nine Milestone 2 checks
  pass.
- Added a schema-validated mutation catalog binding all four manual specs and
  defining validation-elision, predicate-negation, relational-boundary, and
  equality-discrimination operator families across semantic subsystems.
- Extended the `syn` mutator to discover Boolean guard and comparison-boundary
  mutations with function, source-column, semantic rationale, and deterministic
  content identity.
- Classified all 480 discovered candidates in active batch
  `nanoda-semantic-0001`: 12 compiling semantic mutants, 0 build failures, 29
  duplicates, 115 unsupported sites, and 324 rejected non-semantic changes.
- Executed the 12-mutant bounded batch from 23:36:11Z to 00:26:56Z: 6 were
  killed and 6 exhausted their covering schedules and survived without
  witnesses.
- Added mutation score strata by operator, operator family, and subsystem with
  a three-mutant sufficiency threshold. Under-sampled strata retain counts and
  report `INSUFFICIENT_SAMPLE` instead of a score.
- Full-corpus audited generated killed mutant `nanoda-gen-34b1a4c65d39` and
  survivor `nanoda-gen-4238224977cc`; both coverage-guided conclusions matched
  after complete 197-test runs.
- Produced `results/assurance/milestone-3.json`; all 13 Milestone 3 checks pass.
- Replaced the witness-planning stub with direct baseline/mutant execution,
  deterministic subsystem templates, structure-aware NDJSON transformations,
  per-attempt JSONL records, content-bound inputs, and cost accounting.
- Mechanically rediscovered the confirmed `nanoda-0003` universe-ownership
  witness on attempt 1 and automatically minimized it from 522 to 512 bytes
  over 63 additional predicate checks. All 9 records and exact export metadata
  are preserved; both artifacts retain baseline `REJECT` versus mutant `ACCEPT`.
- Executed 60 of 143 deterministic universe-focused candidates against active
  survivor `nanoda-gen-ca8565ff512e`. No candidate distinguished baseline from
  mutant, so the bounded result is durably classified `UNRESOLVED` with reason
  `ATTEMPT_BUDGET_EXHAUSTED`; equivalence is not claimed.
- Added explicit states for witness found, minimized witness found, no witness,
  ambiguous semantics, and reference-checker disagreement.
- Produced `results/assurance/milestone-4.json`; all 11 Milestone 4 checks pass.
- Built unmodified Kiota at Arena-pinned revision
  `58e8636cfb51cf9c3bf3de7455a0e3c6ab68e87a` and content-bound its clean source,
  binary, Arena definition, and implementation family alongside official Lean
  4.33.
- Added validator-neutral direct execution, exact export compatibility rules,
  positive-control checks, raw process evidence, parse behavior, and explicit
  normalized states for accept, reject, decline, crash, timeout, parse error,
  and unknown behavior.
- Established exact expected `REJECT` outcomes for the original and minimized
  `nanoda-0003` witnesses using official Lean plus the accepted declared-universe
  control. Evidence is bound to each artifact SHA-256 without majority voting.
- Cross-validation found durable semantic disagreements for both artifacts:
  official Lean rejects and Kiota accepts. Both remain regression candidates
  with mechanically established expected outcomes and exceptional unresolved
  cross-validator status.
- A malformed-object probe found a separate parse-behavior disagreement:
  official Lean exits successfully after accepting zero declarations, while
  Kiota reports `PARSE_ERROR`.
- Produced `results/assurance/milestone-5.json`; all 15 Milestone 5 checks pass.
- Declared the first held-out transfer experiment before mutation execution:
  source model `nanoda-0001`, held-out validator Kiota, and an independent
  `SKIP_VALIDATION` mutation at Kiota `src/tc.rs:1172-1174`.
- Generated a renamed 438-byte non-`Prop` theorem candidate and a definition-form
  positive control from Arena's `tutorial/012_nonPropThm` seed. Nanoda baseline
  rejects while `nanoda-0001` accepts; both accept the control.
- Official Lean established exact expected rejection for the generated
  candidate and accepted the control before the held-out mutation was applied.
- Froze the corpus and generation boundary at manifest SHA-256
  `5f4776240cd8db4265d27e1f5bc21dbe474368c099a7de2d027727f59236a555`.
  The manifest excludes Kiota mutant outcomes and logs from generation inputs.
- Evaluated the exact frozen SHA against baseline and independently mutated
  Kiota. The candidate changed from `REJECT` to `ACCEPT`; the control remained
  `ACCEPT` in both states. Kiota source was restored to its exact baseline hash.
- Classified the first generalization experiment `POSITIVE_TRANSFER`.
- Produced `results/assurance/milestone-6.json`; all 16 Milestone 6 checks pass.
- Added pinned Lean4Lean at revision
  `ecb3b6661c14f8147be1069b126c629114baf4a8` as a third implementation
  family and defined an analogous Kiota/Lean4Lean fault model for let-bound
  value/type compatibility.
- Froze the fresh Lean4Lean fold before applying or executing its held-out
  mutant. Kiota baseline rejected the 476-byte malformed-let candidate while
  its source mutant accepted it; both accepted the 599-byte control. Official
  Lean independently established candidate `REJECT` and control `ACCEPT`.
- Exhaustively evaluated baseline and mutated Lean4Lean over all 197 original
  corpus tests. The original corpus killed 0 of 1 modeled mutants; the frozen
  candidate changed Lean4Lean from `REJECT` to `ACCEPT`, increasing the
  augmented score to 1 of 1. The control remained `ACCEPT` in both states and
  the held-out source was restored to its exact baseline hash.
- Recast the Milestone 6 Kiota experiment as a separate rotating fold. Its
  original corpus already killed the modeled mutant at
  `tutorial/012_nonPropThm`, so its score remained 1 of 1 after augmentation and
  the fold is `NEUTRAL`.
- Produced the two-fold rotating report with aggregate original score 0.5,
  augmented score 1.0, change +0.5, one `POSITIVE` fold, one `NEUTRAL` fold,
  no regressions, and no unresolved tests. Total measured cost was 400 checker
  runs and 6,918.1547 checker-seconds.
- Produced `results/assurance/milestone-7.json`; all 22 Milestone 7 checks pass.
  The aggregate classification is `MIXED_WITH_POSITIVE_GAIN`. All faults in
  these folds were deliberately injected mutants, not bugs found in the
  unmodified validators.
- Defined and schema-validated a versioned assurance policy and current
  snapshot. The snapshot covers three validator identities, the exact 197-test
  corpus, 29 modeled semantic mutants, subsystem scores, witness synthesis,
  generated regressions, disagreements, held-out results, coverage, and cost.
- The current assurance gate reports `FAIL` with four of five hard checks
  passing. Its sole failure is `semantic_checker_disagreements`: the two
  official Lean/Kiota semantic disagreements exceed the configured maximum of
  zero. This is preserved as the measured result rather than converted into a
  favorable milestone claim.
- Recorded 859 checker runs and 12,034.0801 checker-seconds across the
  non-overlapping measured components, with active mutation-batch and build
  wall time labeled separately. Mutation and coverage thresholds remain
  configurable contextual trends rather than enabled gates.
- Produced `results/assurance/milestone-8.json`; all 24 Milestone 8
  implementation checks pass.
- Defined seven machine-readable contribution paths with common and
  type-specific metadata, content-bound evidence validation, constitution-
  aligned guidance, a pull request checklist, and five issue forms.
- Generated `docs/PUBLIC_STATUS.md` from the exact current snapshot SHA-256,
  clearly separating injected faults from potential bugs and preserving the
  unresolved hard-gate failure.
- Produced `results/assurance/milestone-9.json`; all 25 Milestone 9 checks pass.
- Froze a 152-test Arena corpus at pre-regression revision `dd345f6`, affected
  official Lean 4.29 and pre-fix nanoda `ddfac2b`, fixed/independent checker
  binaries, two fault operators, seed `20260824`, and bounded generation inputs
  before any historical checker or disclosed holdout feedback was available.
- Generated an 11,217-byte malformed nested-inductive artifact from the frozen
  operator specification. Affected official Lean accepted it; fixed official
  Lean, Kiota, and Lean4Lean rejected it.
- Invalidated and archived the original projection result after diagnosing an
  absolute LLVM source-path mismatch: 26 projection-bearing historical inputs
  had been incorrectly reported as yielding zero target-covering schedules and
  therefore zero search attempts.
- Froze a coverage-repair amendment, parsed LLVM export data by relative source
  suffix, and found 11 target-covering historical inputs. The repaired stage
  fails closed if source mapping or coverage selection is empty.
- Froze a second amendment after the restored schedule exposed eager,
  effectively unbounded payload materialization ahead of the nominal
  64-candidate limit. The replacement applies the same seeded shuffle and
  deduplication order lazily; direct equivalence tests cover full order and
  bounded prefixes.
- Evaluated all 11 covering historical inputs against fixed nanoda and the
  modeled projection mutant, then found a distinction on structured mutation
  attempt 1. After candidate freeze, pre-fix nanoda accepted the candidate while
  fixed nanoda, both official Lean versions, Kiota, and Lean4Lean rejected it.
- Evaluated the disclosed `nested-unused-param` artifact only after the
  candidate freeze. Affected official Lean accepted it; fixed official Lean,
  fixed nanoda, Kiota, and Lean4Lean rejected it, while the pinned pre-fix
  nanoda rejected this reduced artifact.
- Classified the amended experiment `FULL_CLASS_REDISCOVERY` and produced
  `results/collatz-retrospective/assurance.json`; all 36 combined checks and all
  15 repaired-branch checks pass.
- Audited the Nanoda mutation surface: the parser finds 480 syntax candidates,
  127 satisfy the semantic policy, and 121 of those are covered, but the first
  semantic batch selected only 12 candidates in 7 of 37 eligible functions.
- Added `semantic-diversity-v1`, which spreads a bounded batch across subsystem,
  function, and operator family before considering estimated execution cost.
  The resulting 12-mutant `nanoda-semantic-0002` batch spans 12 functions and
  seven reachable subsystems; all mutants built, eight were killed, and four
  exhausted their covering schedules.
- Established three of the four survivors as equivalent at Nanoda's checker
  entrypoint: two remove assertions already guaranteed by `nat_extension`, and
  one changes only proof-irrelevant `Quot.ind` reduction behavior.
- Added inductive-metadata witness generation and found a distinction for the
  fourth survivor on attempt 20 by incrementing an exported inductive
  declaration's `numIndices`. Baseline Nanoda rejects the exact artifact while
  the mutant, official Lean 4.33, and Lean4Lean accept it. This establishes an
  implementation inconsistency; whether the metadata must be authoritative is
  still an open contract question.
- Reproduced that disagreement against current Nanoda master revision
  `05055695879dfebb6628a67da88ceca6cd6b0421`; current Nanoda accepts the
  unchanged positive control and rejects the hash-bound generated artifact.
  The mutant retains the project's designated-reference `REFERENCE_ALIGNED`
  classification and is excluded from both mutation score denominators, while
  the cross-checker contract remains unresolved.
- Rebuilt the current mutation report, three-artifact regression manifest,
  artifact graph, assurance snapshot, and public status. Artifact freshness
  passes; the sole hard-gate failure is now the three unresolved semantic
  checker disagreements.
- Ran a third semantic-diversity batch across 12 additional functions. Eleven
  mutants built, eight were killed, and three survived; the remaining mutation
  failed its isolated build because the original binder-depth operator changed
  an owned integer into a reference.
- Established the surviving constructor-owner assertion as equivalent at the
  checker entry point after a 300-attempt bounded search found no witness and
  source invariants showed that constructor ownership is reconstructed from the
  containing inductive declaration.
- Replaced the malformed binder-depth operator with
  `BINDER_DEPTH_INCREMENT_ZERO` and ran a targeted 12-mutant batch over
  substitution/lifting and bound-variable functions. All 12 built and all 12
  were killed by the existing corpus.
- Expanded the syntax audit to 524 discovered candidates, 185 on the operator
  surface, 131 eligible under the then-current semantic policy, and 125 with
  line-coverage inputs. Every modeled subsystem now has operator surface.
- Investigated all six uncovered candidates. Five belong to Nanoda's explicitly
  dead debug-only `strong_reduce` entry point and are now outside the model. The
  remaining parallel validation mutant was hidden because coverage used one
  thread while execution used four; baseline rejected two exact malformed
  artifacts that the mutant accepted.
- Changed scheduling to retain modeled zero-coverage candidates and run the
  complete baseline corpus as a conservative fallback. The targeted parallel
  batch built and killed its mutant, and the machine-readable resolution is
  `results/investigations/nanoda-uncovered-mutation-sites.json`.
- Triaged universe survivor `nanoda-gen-0bb50147dff2`. A plain-parameter
  hypothesis did not distinguish it, but a source-directed `imax u v` versus
  `imax w v` declaration changed baseline Nanoda from `REJECT` to mutant
  `ACCEPT` on attempt 2.
- Official Lean 4.33, Kiota, and Lean4Lean all reject the exact `IMax` witness
  and accept its structure-matched control. The expected outcome is established
  without disagreement, and the artifact is a confirmed regression candidate.
- Triaged declaration-visibility survivor `nanoda-gen-8317efea2c7d`. A first
  inductive forward-reference candidate showed that the mutant could cross the
  environment cutoff but remained malformed because it lacked recursor
  metadata. A six-record definition self-reference then changed baseline
  Nanoda from `REJECT` to mutant `ACCEPT`; both accept the matched control.
- Official Lean 4.33 and Lean4Lean reject the self-reference, establishing the
  expected `REJECT` outcome with baseline Nanoda. Kiota accepts it. Source
  tracing found that Kiota inserts the definition before checking its body, and
  the four-outcome disagreement reproduces on fetched upstream `main`
  `686063c`. The witness is retained as a regression candidate with unresolved
  cross-validator disagreement rather than majority-voting Kiota away.
- Rechecked the environment-cutoff mutant against current Arena's newly added
  `tutorial/014_selfProof`, materialized from Arena revision `162f4e5`. Baseline
  Nanoda passes the test by rejecting the theorem self-reference, while
  `nanoda-gen-8317efea2c7d` fails the test by accepting it. The machine
  classification is therefore `KILLED`. This is a later corpus improvement and
  does not rewrite the frozen 197-test survival result. The exact export,
  provenance, and restored differential run are under
  `results/investigations/nanoda-env-cutoff-self-reference/`.

## Command Log

```sh
ps aux | rg -i 'cargo|rustc|lean-kernel-arena/_build/checkers/nanoda'
cd external/lean-kernel-arena/_build/checkers/nanoda/src
cargo build --release
cd /Users/danphifer/Documents/ChatGPT/LeanVerifier/external/lean-kernel-arena
../../.venv-arena/bin/python ./lka.py run --checker nanoda --test constlevels
cd /Users/danphifer/Documents/ChatGPT/LeanVerifier
scripts/normalize-arena-results --checker nanoda --output results/mutants/nanoda-0001/outcomes-smoke.jsonl
scripts/compare results/baseline/outcomes/nanoda-smoke.jsonl results/mutants/nanoda-0001/outcomes-smoke.jsonl --mutant-id nanoda-0001 --output results/mutants/nanoda-0001/comparison-smoke.json
cd external/lean-kernel-arena
../../.venv-arena/bin/python ./lka.py build-test --skip-declined-by nanoda
../../.venv-arena/bin/python ./lka.py run --checker nanoda
cd /Users/danphifer/Documents/ChatGPT/LeanVerifier
scripts/normalize-arena-results --checker nanoda --output results/mutants/nanoda-0001/outcomes-full.jsonl
cd external/lean-kernel-arena/_build/checkers/nanoda/src
cargo build --release
cd /Users/danphifer/Documents/ChatGPT/LeanVerifier/external/lean-kernel-arena
../../.venv-arena/bin/python ./lka.py run --checker nanoda
cd /Users/danphifer/Documents/ChatGPT/LeanVerifier
scripts/normalize-arena-results --checker nanoda --output results/baseline/outcomes/nanoda-full.jsonl
scripts/compare results/baseline/outcomes/nanoda-full.jsonl results/mutants/nanoda-0001/outcomes-full.jsonl --mutant-id nanoda-0001 --baseline-id nanoda-baseline-full --candidate-id nanoda-0001-full --output results/mutants/nanoda-0001/comparison.json
scripts/mutate status nanoda-0001 KILLED MEANINGFUL_SEMANTIC "Killed by full Arena corpus: tutorial/012_nonPropThm changed REJECT to ACCEPT after theorem Prop validation was skipped"
scripts/report
scripts/run-mutant nanoda-0001 --test tutorial/012_nonPropThm
scripts/mutate register nanoda-0002 nanoda src/tc.rs 92 SKIP_VALIDATION definition-body-typecheck "Disabled definitional equality between inferred definition body type and declared type in check_declar"
scripts/run-mutant nanoda-0002 --reuse-baseline
scripts/report
scripts/mutate register nanoda-0003 nanoda src/tc.rs 191 SKIP_VALIDATION universes "Disabled validation that universe levels supplied to referenced constants are declared by the current declaration"
scripts/mutate register nanoda-0004 nanoda src/tc.rs 597 SKIP_VALIDATION declaration-validation "Disabled sort well-formedness validation for lambda binder types during checked inference"
scripts/run-mutant nanoda-0003 --reuse-baseline
cd external/lean-kernel-arena/_build/checkers/nanoda/src
target/release/nanoda_bin config.json < /Users/danphifer/Documents/ChatGPT/LeanVerifier/corpus/generated/nanoda-0003-undeclared-const-universe.ndjson
cd /Users/danphifer/Documents/ChatGPT/LeanVerifier
scripts/mutate status nanoda-0003 SURVIVED MEANINGFUL_SEMANTIC "Survived all 197 current Arena tests with zero normalized differences; generated witness is rejected by baseline and accepted by mutant"
scripts/report
scripts/collect-coverage --reuse-build --resume --timeout 7200 --checker-threads 1
scripts/reindex-coverage --append-from /tmp/nanoda-coverage-bogus1/coverage.jsonl
scripts/schedule-mutant nanoda-0001 --output results/mutants/nanoda-0001/schedule.json
scripts/schedule-mutant nanoda-0002 --output results/mutants/nanoda-0002/schedule.json
scripts/schedule-mutant nanoda-0003 --output results/mutants/nanoda-0003/schedule.json
scripts/schedule-mutant nanoda-0004 --output results/mutants/nanoda-0004/schedule.json
scripts/run-mutant-scheduled nanoda-0001
scripts/run-mutant-scheduled nanoda-0003
scripts/run-mutant-scheduled nanoda-0002
scripts/run-mutant-scheduled nanoda-0004
scripts/snapshot-coverage
scripts/snapshot-coverage --verify
scripts/verify-portable-coverage
scripts/verify-portable-coverage --verify
scripts/generate-mutations --limit 12 --batch-id nanoda-syntax-0003 --write --register
scripts/validate-mutation-batch nanoda-syntax-0003
scripts/run-mutation-batch nanoda-syntax-0003
cd external/lean-kernel-arena
../../.venv-arena/bin/python ./lka.py build-checker official
cd /Users/danphifer/Documents/ChatGPT/LeanVerifier
scripts/confirm-witness nanoda-0003-undeclared-const-universe --checker official --control corpus/controls/nanoda-0003-declared-const-universe.ndjson
scripts/run-mutant-input nanoda-0003 corpus/generated/nanoda-0003-undeclared-const-universe.ndjson --output results/mutants/nanoda-0003/augmented-comparison.json
scripts/assurance-snapshot
scripts/report --output results/assurance/milestone-1-report.json
scripts/build-artifact-graph
scripts/artifact-status --require-current --output results/artifacts/status.json
.venv-arena/bin/python -c 'import json, jsonschema; from pathlib import Path; jsonschema.Draft202012Validator(json.loads(Path("schemas/artifact-graph.schema.json").read_text()), format_checker=jsonschema.FormatChecker()).validate(json.loads(Path("results/artifacts/graph.json").read_text()))'
python3 -m unittest discover -s tests -p 'test_*.py' -v
scripts/milestone-2-assurance
scripts/artifact-status --simulate-change validator:nanoda
scripts/artifact-status --simulate-missing corpus:arena-materialized
scripts/generate-mutations --limit 12 --batch-id nanoda-semantic-0001 --write --register
scripts/validate-mutation-batch nanoda-semantic-0001
scripts/run-mutation-batch nanoda-semantic-0001
scripts/report --allow-stale-artifacts --output results/assurance/milestone-3-report.json
scripts/audit-coverage-guidance nanoda-gen-34b1a4c65d39 nanoda-gen-4238224977cc
scripts/generate-mutations --limit 12 --batch-id nanoda-semantic-0001 --write --refresh
.venv-arena/bin/python -c 'import json,jsonschema; from pathlib import Path; jsonschema.Draft202012Validator(json.loads(Path("schemas/mutation-catalog.schema.json").read_text())).validate(json.loads(Path("mutation-model/catalog.json").read_text()))'
scripts/milestone-3-assurance --allow-stale-artifacts
scripts/build-artifact-graph
scripts/artifact-status --require-current --output results/artifacts/status.json
python3 -m unittest discover -s tests -p 'test_*.py' -v
scripts/milestone-3-assurance
scripts/generate --mutant-id nanoda-0003 --subsystem universes --random-seed 4103 --max-attempts 20 --max-minimization-checks 200 --expected-outcome REJECT --expected-evidence results/witnesses/nanoda-0003-undeclared-const-universe/confirmation.json --witness-id nanoda-0003-auto-universe
scripts/generate --mutant-id nanoda-gen-ca8565ff512e --subsystem universes --seed-artifact external/lean-kernel-arena/_build/tests/tutorial/good/013_levelComp1.ndjson --seed-artifact external/lean-kernel-arena/_build/tests/tutorial/good/016_levelParams.ndjson --seed-artifact external/lean-kernel-arena/_build/tests/tutorial/good/020_imax1.ndjson --seed-artifact external/lean-kernel-arena/_build/tests/level-imax-leq.ndjson --random-seed 4104 --max-attempts 60 --witness-id nanoda-gen-ca8565ff512e-search-0001
scripts/milestone-4-assurance --allow-stale-artifacts
cd external/lean-kernel-arena
../../.venv-arena/bin/python ./lka.py build-checker kiota
cd /Users/danphifer/Documents/ChatGPT/LeanVerifier
scripts/validator-inventory
scripts/establish-expected-outcome nanoda-0003-original corpus/generated/nanoda-0003-auto-universe.ndjson --control corpus/controls/nanoda-0003-declared-const-universe.ndjson --reference official --rationale 'undefined universe parameter references must be rejected'
scripts/establish-expected-outcome nanoda-0003-minimized corpus/minimized/nanoda-0003-auto-universe-min.ndjson --control corpus/controls/nanoda-0003-declared-const-universe.ndjson --reference official --rationale 'structurally minimized distinguishing artifact must be rejected'
scripts/cross-validate nanoda-0003-original corpus/generated/nanoda-0003-auto-universe.ndjson --control corpus/controls/nanoda-0003-declared-const-universe.ndjson --expected-evidence results/expected-outcomes/nanoda-0003-original.json --checker official --checker kiota
scripts/cross-validate nanoda-0003-minimized corpus/minimized/nanoda-0003-auto-universe-min.ndjson --control corpus/controls/nanoda-0003-declared-const-universe.ndjson --expected-evidence results/expected-outcomes/nanoda-0003-minimized.json --checker official --checker kiota
scripts/cross-validate malformed-object-probe corpus/probes/malformed-object.ndjson --probe-mode --checker official --checker kiota
scripts/build-regression-candidates
scripts/report --allow-stale-artifacts --output results/assurance/milestone-5-report.json
scripts/milestone-5-assurance --allow-stale-artifacts
scripts/freeze-transfer-experiment
scripts/run-transfer-experiment
scripts/report --allow-stale-artifacts --output results/assurance/milestone-6-report.json
scripts/milestone-6-assurance --allow-stale-artifacts
scripts/freeze-rotating-fold
scripts/run-rotating-fold
scripts/evaluate-m6-rotating-fold
scripts/build-rotating-heldout-report
scripts/report --allow-stale-artifacts --output results/assurance/milestone-7-report.json
scripts/milestone-7-assurance --allow-stale-artifacts
scripts/build-artifact-graph
scripts/artifact-status --require-current --output results/artifacts/status.json
scripts/milestone-7-assurance
scripts/current-assurance-snapshot
scripts/milestone-8-assurance --allow-stale-artifacts
scripts/render-public-status
scripts/validate-contribution --check-catalog
scripts/milestone-9-assurance --allow-stale-artifacts
scripts/build-artifact-graph
scripts/artifact-status --require-current --output results/artifacts/status.json
scripts/milestone-8-assurance
scripts/milestone-9-assurance
```

Notes:

- The first non-escalated full corpus build failed because sandboxed commands
  cannot resolve GitHub hosts. Retrying the same Arena build with approved
  network escalation fixed this and produced `57 succeeded, 0 failed`.
- The built test corpus currently occupies about 24 GB under
  `external/lean-kernel-arena/_build/tests`.
- The nanoda source checkout is restored to baseline after the comparison; the
  mutant is preserved in the registry and result artifacts.
- `scripts/run-mutant` clears stale Arena `_results/<checker>_*.json` before
  each side of a run. The normalized full-run artifacts remain in `results/`,
  but raw Arena JSON in `external/lean-kernel-arena/_results` is intentionally
  treated as scratch space.
- The materialized corpus contains 197 unique `*.stats.json` test identities.
  The `nanoda-0002` full run emitted 197 unique raw and normalized results, and
  the new exact-inventory check confirmed the identity sets match. The earlier
  note that an Arena summary reported 198 was historical and is not a current
  dropped-record condition.
- Per-test coverage is stored under `results/coverage/nanoda/` and occupies
  about 26 MB. Valid instrumented checker time was 5,114 seconds (85.2 minutes):
  mathlib 3,949.5 seconds, cslib 639.7 seconds, cedar 220.2 seconds, and std
  161.3 seconds. Single-thread checking was fastest because multi-threaded
  coverage counters caused severe contention.
- The reverse coverage index selected 67 tests for `nanoda-0001`, 167 for
  `nanoda-0002`, 120 for `nanoda-0003`, and 112 for `nanoda-0004`. It included
  all 20 historical killing relationships across the first two mutants.
- Coverage-guided `nanoda-0001` took about 22 seconds including two builds and
  stopped at `tutorial/012_nonPropThm`; the prior full loop took about nine
  minutes. Coverage-guided `nanoda-0003` took about 489 seconds because its
  central line is covered by every large library export.
- The first generated candidate set was superseded because AST-discovered
  `assert!` statements included configuration guards and internal invariants.
  A second partial batch established one survivor before being narrowed again.
  These attempts remain classified in durable manifests instead of being
  omitted from the record.
- Generated source replacements originally exposed a restoration bug because
  `if false { original }` still contains the original text. All source-state
  transitions now check the full mutant first, repeated statements carry an
  exact occurrence index, and batch validation proves the baseline source
  digest before and after isolated builds.
- The active 12-mutant batch ran from 21:31:34Z to 23:00:51Z. The only kill was
  `nanoda-gen-1c536a57344e`; `proj-of-prop` changed from `REJECT` to `ACCEPT`
  after 73 of 147 covering tests. The other 11 mutants exhausted their full
  schedules and are classified `SURVIVED_WITHOUT_WITNESS`.

## Legacy Metrics Snapshot — Superseded

The following numbers preserve an earlier working snapshot and are not current
metrics. Current facts are generated in [PUBLIC_STATUS.md](PUBLIC_STATUS.md)
from `results/assurance/current.json`; the final [project review](PROJECT_REVIEW.md)
also binds its exact machine-readable inputs. Do not copy these legacy numbers
into a new assurance claim.

```yaml
mutation_score: 0.9375
mutation_score_scope: explicit MEANINGFUL_SEMANTIC classifications only
modeled_mutation_score: 0.9375
modeled_mutation_score_denominator: 48
generated_mutants: 79
evaluated_mutants: 65
killed_mutants: 49
surviving_mutants: 16
build_failed_mutants: 1
superseded_mutants: 13
unevaluated_mutants: 0
classified_equivalent: 12
classified_reference_aligned: 5
classified_unreachable: 0
classified_performance_only: 0
classified_non_semantic: 10
meaningful_survivors: 3
survived_without_witness: 0
unknown_equivalence: 4
witnesses_found: 4
minimized_witnesses: 3
witness_searches_without_result: 2
confirmed_witness_semantics: 3
ambiguous_witness_semantics: 0
witness_checker_disagreements: 1
generated_regression_candidates: 23
artifact_nodes: 162
current_artifacts: 151
historical_artifacts: 7
superseded_artifacts: 4
milestone_2_checks_passing: 9
milestone_3_checks_passing: 13
milestone_4_checks_passing: 11
cross_validators: 3
configured_validators: 3
cross_validation_cases: 24
cross_validation_checker_disagreements: 13
expected_outcomes_established: 23
regression_candidates_with_unresolved_disagreement: 12
milestone_5_checks_passing: 15
transfer_experiments: 1
positive_transfer: 1
neutral_transfer: 0
negative_transfer: 0
inconclusive_transfer: 0
incompatible_transfer: 0
unresolved_transfer: 0
milestone_6_checks_passing: 16
rotating_held_out_folds: 2
rotating_positive_folds: 1
rotating_neutral_folds: 1
rotating_negative_folds: 0
rotating_unresolved_folds: 0
rotating_original_score: 0.5
rotating_augmented_score: 1.0
rotating_score_change: 0.5
rotating_checker_runs: 400
rotating_checker_seconds: 6918.154678831925
milestone_7_checks_passing: 22
current_assurance_status: FAIL
current_hard_gates_passing: 4
current_hard_gates_failing: 1
current_failure_reason: semantic_checker_disagreements
current_semantic_disagreements: 13
current_parse_behavior_disagreements: 1
current_recorded_checker_runs: 925
current_recorded_checker_seconds: 6921.168137743953
milestone_8_checks_passing: 24
contribution_paths: 7
community_issue_forms: 5
milestone_9_checks_passing: 29
action_recommendation_findings: 2
external_actions_pending_human_review: 5
current_upstream_action_preflight_pairs: 8
prepared_external_action_drafts: 5
```

## First Mutation Result

- Mutant: `nanoda-0001`
- Operator: `SKIP_VALIDATION`
- Subsystem: `declaration-validation`
- Source: `src/tc.rs:175`
- Mutation: theorem `Prop` validation in `check_declar_info` was weakened from
  `if !self.ctx.is_zero(sort)` to `if false && !self.ctx.is_zero(sort)`.
- Smoke comparison: survived `constlevels`
  (`results/mutants/nanoda-0001/comparison-smoke.json`).
- Full corpus comparison: killed by one normalized outcome difference
  (`results/mutants/nanoda-0001/comparison.json`).
- Distinguishing test: `tutorial/012_nonPropThm`.
- Mechanical difference: baseline `REJECT`, mutant `ACCEPT`.
- Full comparison size: 197 normalized result records.
- Automated scoped rerun: killed again by `tutorial/012_nonPropThm`, with
  artifacts at
  `results/mutants/nanoda-0001/comparison-tutorial_012_nonPropThm.json`.

## Second Mutation Result

- Mutant: `nanoda-0002`
- Operator: `SKIP_VALIDATION`
- Subsystem: `definition-body-typecheck`
- Source: `src/tc.rs:92`
- Mutation: skipped `assert_def_eq(inferred_type, d.info().ty)` after inferring
  the value of a definition, theorem, or opaque declaration.
- Full corpus comparison: killed by 19 normalized outcome differences
  (`results/mutants/nanoda-0002/comparison.json`).
- All 19 differences were baseline `REJECT` to mutant `ACCEPT`; the first was
  `bogus1`, and the direct tutorial witness was `tutorial/002_badDef`.
- Both sides contained the same 197 test identities; no comparison difference
  came from a missing result.

## First Meaningful Survivor

- Mutant: `nanoda-0003`
- Operator: `SKIP_VALIDATION`
- Subsystem: `universes`
- Source: `src/tc.rs:191`
- Mutation: skipped the check that every universe level supplied to a referenced
  constant is declared in the current declaration's `levelParams`.
- Full corpus result: survived with zero differences across the exact same 197
  test identities (`results/mutants/nanoda-0003/comparison.json`).
- Semantic witness:
  `corpus/generated/nanoda-0003-undeclared-const-universe.ndjson`.
- Witness behavior: restored baseline rejects with exit 101 at the mutated
  assertion; `nanoda-0003` accepts with exit 0.
- The witness declares `unused.{u} : Prop`, then defines a declaration with no
  universe parameters whose value references `unused.{u}`. The undeclared level
  does not appear in the resulting type, so removing the ownership check admits
  the artifact.
- Durable records:
  `results/survivors/inventory.jsonl` and
  `results/witnesses/nanoda-0003-undeclared-const-universe/metadata.json`.

## Unresolved Problems

- Two mechanically executed survivors await triage within the current canonical
  modeled population; `results/assurance/current.json` records the current count
  and exact IDs.
  Earlier campaign counts in the legacy snapshot above use a different state
  and scope. Unresolved survivors are not claimed equivalent.
- Coverage payloads remain ignored local files; their complete identities and
  corpus inputs are tracked and mechanically verified, but remote payload
  storage is not yet implemented.
- The current operator families remain a narrow source-level semantic model.
  Substitution/lifting and bound-variable handling are now represented and the
  first targeted batch killed all 12 mutants, but match-arm and richer reduction
  mutations remain future work.
- Large corpus files are expensive: `mathlib.ndjson` is about 5.2 GB,
  `cslib.ndjson` about 2.0 GB, and `cedar.ndjson` about 790 MB.
- The repository revision recorded by an attestation becomes historical after
  the attestation commit. Current claims depend on content digests and the exact
  upstream Arena revision, avoiding a self-referential commit hash while
  preserving the producing repository revision for audit.
- The first automated negative witness search was deliberately bounded at 60
  attempts out of 143 generated candidates. It establishes only that those 60
  candidates did not distinguish the checkers; the survivor remains unresolved.
- Kiota accepts both universe-ownership witnesses that official Lean and
  baseline nanoda reject. The minimized case was reproduced against current
  upstream Kiota revision `686063c13b22ce379c05dfe7fc03656655ac60e5` with a
  passing positive control. The schema-validated record is
  `results/investigations/kiota-universe-ownership/upstream-main.json`, and the
  report is `docs/investigations/KIOTA_UNIVERSE_OWNERSHIP.md`. It was submitted
  as [Kiota issue #3](https://github.com/sankalpsthakur/kiota/issues/3). The
  disagreement remains unresolved until upstream adjudication; no majority or
  implementation count is used to decide semantics.
- The minimized witness preserves export metadata but official Lean rejects it
  at `defnInfo invalid`, earlier than the original undefined-universe error.
  Its expected rejection is established, but its explanatory semantics are not
  claimed identical to the original witness.
- Official Lean's direct checker accepts the malformed-object probe as zero
  declarations while Kiota reports a JSON parse error. The probe is diagnostic,
  not a regression candidate.
- The positive transfer result covers one fault family, one small generated
  candidate, and one held-out validator. It demonstrates the protocol and one
  transfer event; it does not establish a general transfer rate.
- The first candidate is structurally derived from an existing Arena test by a
  deterministic rename and control conversion. Later rotating experiments
  should include less direct generators and different semantic subsystems.
- The rotating report contains only two folds and one independently introduced
  mutant per held-out validator. Its positive aggregate change is real for those
  exact models, but it is not a general transfer-rate estimate and cannot rule
  out implementation-specific overfitting.
- The Lean4Lean fold required 6,917.90 checker-seconds because both checker
  states processed every original test and the large `mathlib` export dominated
  the tail. Future folds use `scripts/run-rotating-fold-resumable`, which
  atomically saves every baseline and mutant result, resumes only against exact
  bound inputs and runner hashes, validates the completed corpus prefix, and
  reports abandoned in-flight attempts. The original Milestone 7 runner remains
  unchanged because its content hash is part of the completed evidence.
- The current assurance hard gate remains `FAIL` until the semantic
  official Lean/Kiota disagreements and the current Nanoda `numIndices`
  inconsistency are adjudicated, or the policy changes with an explicit
  rationale. No implementation count is used to collapse these disagreements.
- The Collatz retrospective is operator-informed and post-disclosure. Its
  amended full-class result is evidence only for the frozen bounded protocol,
  not prospective discovery, prevention of the original incident, or a general
  bug-finding rate. The invalid zero-attempt run is preserved for audit. The
  protocol repairs kept the corpus, strategy, generator semantics, seed,
  limits, and feedback boundary fixed, but cannot recreate the original blind
  execution.

## Research Frontier

### Recently Completed

- `F-ASSURANCE-METHODS-LANDSCAPE`: preserved the broader assurance-methods
  landscape in the
  [assurance methods map](research/ASSURANCE_METHODS_MAP.md) with
  primary/official source provenance, explicit project analogues and
  mismatches, non-prioritizing maturity, and evidence-based reconsideration
  conditions. The map is institutional memory; this file remains the planning
  authority.
- `F-RULE-LEVEL-FACTORING-PHASE1`: adversarially factored five existing
  checker-rule boundaries in the
  [Phase 1 factoring experiment](research/RULE_LEVEL_FACTORING_EXPERIMENT.md).
  The result is decision B: normative or normative-candidate obligations and
  scoped empirical contract scenarios need different claim kinds with a shared
  evidence envelope. Serialized `Quot` fails as a universal rejection
  obligation, and `isUnsafe` fails as one rule.
- `F-ASSURANCE-CLAIM-PROTOTYPE-GATE`: built the accepted falsification-first
  [Phase 2 prototype](research/ASSURANCE_CLAIM_PROTOTYPE.md) from existing
  evidence. The generated research artifact passes all thirteen mechanical
  checks: quotient `Eq` fits a bounded normative-candidate obligation, while
  `isUnsafe` is representable only after splitting ingestion from dependent
  visibility. The gate does not yet justify a matrix, RIPR integration,
  semantics-directed reproduction, production schema, or semantic-coverage
  claim.
- `F-ASSURANCE-CLAIM-PROTOTYPE-REMAINDER`: applied the unchanged two-kind
  prototype to theorem proposition-valued results, referenced-constant universe
  ownership, and serialized base `Quot` exact-type handling. The generated
  [representative-set artifact](../results/research/assurance-claim-prototype.json)
  now passes all seventeen checks over six claims. Theorem and universe
  ownership fit normative-candidate obligations with different authority
  states; serialized `Quot` fits only an empirical contract scenario. The old
  Nanoda universe-control provenance gap remains explicit rather than being
  reconstructed from the present checkout. No third claim kind was added.
- `F-ENV-CUTOFF`: found and independently validated the definition
  self-reference witness for `nanoda-gen-8317efea2c7d`. Current Arena's later
  `tutorial/014_selfProof` also kills the mutant, so no duplicate Arena proposal
  is needed. The separate Kiota disagreement is reported as
  [Kiota #5](https://github.com/sankalpsthakur/kiota/issues/5).
- `F-IMAX-EQUALITY`: found a source-directed `imax` witness for
  `nanoda-gen-0bb50147dff2`; official Lean, Kiota, and Lean4Lean all establish
  the expected `REJECT` outcome.
- `F-NUMINDICES-REPORT`: reproduced the nested `numIndices` disagreement on
  current Nanoda master and reported it as
  [Nanoda #29](https://github.com/ammkrn/nanoda_lib/issues/29). The issue now
  explicitly asks whether the serialized field is authoritative rather than
  assuming Nanoda is incorrect.
- `F-UNIVERSE-BOUNDARY`: proved `nanoda-gen-7447f6511962` equivalent by
  match-arm shadowing. The preceding `(Zero, _) if diff >= 0` arm consumes every
  input on which the original later predicate could be true, so the mutated
  `Zero, Param` arm is reachable only for `diff < 0`, where both `>= 0` and
  `> 0` are false. A source-derived candidate and instrumentation reproduction
  confirmed the reachability analysis; the earlier 120-second `mathlib`
  timeout remains archived as an invalid undersized-bound result.
- `F-RESTORED-RECURSOR`: found a one-field restored auxiliary recursor witness
  for `nanoda-gen-8237cd6d3cb2`. The unchanged 105-record nested-inductive
  control is accepted by every tested checker. Changing only `k: false` to
  `k: true` makes baseline Nanoda reject at `src/inductive.rs:1687` while the
  mutant accepts. Official Lean establishes `REJECT` and Lean4Lean confirms;
  Kiota accepts, so its metadata-contract disagreement remains unresolved.
- `F-RESTORED-RECURSOR-TYPE`: found a one-field type witness for
  `nanoda-gen-7b603be7dc87`. Replacing only the restored auxiliary recursor's
  serialized type with the independently well-formed base recursor type makes
  baseline Nanoda reject while the mutant accepts. Official Lean and Lean4Lean
  reject; Kiota accepts, reinforcing one broader restored-recursor validation
  disagreement rather than a separate issue per field.
- `F-RESTORED-CTOR-METADATA`: found a one-field constructor-index witness for
  `nanoda-gen-a59d7fa2cfb3`. Changing only `LALNest.node`'s serialized `cidx`
  from `0` to `1` makes baseline Nanoda reject while the mutant accepts.
  Official Lean and Lean4Lean reject; Kiota accepts, extending the same restored
  nested declaration-validation disagreement to constructor metadata.
- `F-INDUCTIVE-BINDER-TYPE-0`: proved `nanoda-gen-96211e002bfd` equivalent.
  `local_params` and the first inductive-spec traversal derive their compared
  binder types from the same unchanged inductive type, in the same order and
  under identical prior substitutions. Nested specialization rewrites only
  constructors, so the skipped equality assertion cannot fail.
- `F-CONSTRUCTOR-PARAM-BINDER`: proved `nanoda-gen-da679d93da63` equivalent at
  whole-checker scope. A cumulative-sort mismatch survives the local skipped
  check but is rejected by mandatory standalone constructor-type inference.
  More generally, the exact-parameter result check forces each corresponding
  bound variable into the parent inductive application, where standalone
  inference re-establishes the same binder-domain equality.
- `F-IMAX-DIFF-BOUNDARY`: proved `nanoda-gen-ca8565ff512e` equivalent. Disabling
  the equal-`IMax`, `diff = 0` fast path only routes the comparison through the
  exhaustive parameter or nested-maximum fallbacks. Two exported candidates
  matched, and Nanoda's focused equal-`IMax` unit test passed under the mutant.
- `F-QUOT-IND-GUARD`: proved `nanoda-gen-701a664f39e5` equivalent and duplicate
  to the previously classified `nanoda-gen-cb4949d04bbf`. The audit covers both
  loss of proof-only `Quot.ind` reduction and the inverted guard's newly enabled
  path for other quotient primitives; mandatory structural application checking
  prevents malformed overapplications from being hidden by reduction.
- `F-LET-VALUE-TYPE-TRANSFER`: killed `nanoda-gen-e551a17020ce` with the exact
  malformed-let artifact previously generated for Kiota and evaluated against
  held-out Lean4Lean. Baseline Nanoda rejects, the mutant accepts, and both
  accept the matched control. Official Lean, Kiota, and Lean4Lean all confirm
  `REJECT`, so this is a clean regression candidate without a disagreement.
- `F-QUOT-PRIMITIVE-TYPES`: classified four exact-type mutants as
  `REFERENCE_ALIGNED`: base `Quot`, `Quot.mk`, `Quot.lift`, and `Quot.ind`.
  Each one-field sort replacement makes baseline Nanoda reject and its mutant
  accept, while official Lean, Kiota, and Lean4Lean accept every exact artifact.
  The evidence forms one serialized primitive-contract finding, not four issues.
- `F-QUOT-EQ-TYPE`: killed `nanoda-gen-d39c873fbcb7` with a structurally valid
  equality family returning `Sort (max 1 u)` in place of proposition-valued
  built-in `Eq`. Baseline Nanoda rejects exactly at the skipped prerequisite
  assertion and the mutant accepts; both accept the canonical control. Official
  Lean and Lean4Lean reject the candidate, while Kiota accepts it, leaving an
  explicit checker disagreement attached to the regression candidate.
- `F-QUOT-EQ-REFL`: killed `nanoda-gen-cd41c71bc814` with a valid Eq family
  whose sole constructor has one extra unused field. Baseline rejection is
  isolated to `src/quot.rs:105`, the mutant accepts, and both accept the
  canonical control. Official Lean and Lean4Lean reject while Kiota accepts,
  matching the adjacent Eq-type disagreement and completing one prerequisite
  family.
- `F-SERIAL-DECLARATION-LOOP`: killed `nanoda-gen-1dedcb13793f` under Nanoda's
  supported one-thread configuration. The prior 173-test survival used the
  four-thread differential config, which bypassed the mutated serial branch.
  `scripts/run-mutant-input` now accepts and records `--config`; the existing
  malformed-let case is rejected by baseline and accepted by the mutant, while
  both accept its matched control.
- `F-STRING-EXTENSION-GUARD`: classified `nanoda-gen-4238224977cc` equivalent
  at Nanoda's public file/config entrypoint. The active config makes the
  assertion true; with the extension disabled, both the parser and internal
  constructors prevent a string literal from reaching inference.
- `F-BINDER-SORT-SURVIVORS`: classified `nanoda-0004` and
  `nanoda-gen-9a8edf073073` equivalent at the public declaration entrypoint.
  Let value-type equality and recursive comparison of lambda Pi telescopes
  against independently sort-checked expected types re-establish the skipped
  checks. Source-derived malformed probes are rejected by both builds.
- `F-QUOTIENT-CONTRACT-MATRIX`: synthesized four primitive-signature cases and
  two Eq-prerequisite cases into one executable checker matrix. Nanoda rejects
  all six deviations; official Lean and Lean4Lean accept the four primitive
  deviations but reject both Eq deviations; Kiota accepts all six. This is a
  bounded inferred contract, not a complete specification, and no issue was
  filed automatically.
- `F-SPEC-DERIVATION-PILOT`: generalized the rule-to-test method to three
  restored nested-declaration fields. Nanoda, official Lean, and Lean4Lean
  reject restored recursor `k`, recursor type, and constructor-index
  mismatches; Kiota accepts all three. Both pilot matrices are machine-derived
  from exact differential and cross-validation evidence.
- `F-DECLARATION-ENVIRONMENT-MATRIX`: derived two separate executable rules
  for referenced-constant universe ownership and current-declaration
  self-reference. Nanoda, official Lean, and Lean4Lean reject both exact
  violations; Kiota accepts both. `numIndices` remains in the restored
  inductive-metadata family rather than being conflated with environment scope.
- `F-CORE-DECLARATION-TYPING-MATRIX`: added executable characterization cases
  for let annotation/value agreement and the requirement that theorem types are
  propositions. Nanoda, official Lean, Kiota, and Lean4Lean reject both exact
  violations and accept their matched controls.
- `F-CHECKER-RULE-INVENTORY`: aggregated five bounded matrices into 18 directly
  executable checker boundaries. Official Lean and Lean4Lean agree on all 18;
  Nanoda differs from them on six cases, and Kiota differs on nine. The
  inventory records unmodeled surfaces and ranks reduction/projection typing as
  the next source-derived family.
- `F-UNIVERSE-DEFINITIONAL-EQUALITY-MATRIX`: characterized five exact `IMax`
  boundaries. All four checkers accept left-one and right-zero reductions and
  reject equality with distinct left parameters. Nanoda and Kiota accept both
  tested comparisons of `imax` with a successor right operand against `max`;
  official Lean and Lean4Lean reject the general case and its `imax u 1`
  specialization while accepting matched direct-`max` controls. This remains
  an unresolved checker-contract disagreement; no issue was filed.
- `F-PROJECTION-TYPING-MATRIX`: froze three exact Arena tutorial exports plus a
  structure-matched non-projection control. Official Lean and Kiota accept both
  Arena-good projections from a structure that may instantiate to `Prop`;
  Nanoda and Lean4Lean reject both. All four reject the Arena-bad definite-Prop
  data projection and accept the control. The aggregate inventory now covers
  21 boundaries across six matrices.
- `F-INVESTIGATION-ACTION-SOP`: made concrete follow-through a constitutional
  requirement. Every mature finding must recommend a named action, target,
  priority, prerequisites, and evidence. A schema-backed current register
  records two findings and five recommended external actions; external issues,
  pull requests, comments, and disclosures remain blocked on explicit human
  authorization for each target.
- `F-UPSTREAM-ACTION-PREFLIGHT`: rebuilt current Nanoda master `0505569`, Kiota
  main `686063c`, and Lean4Lean arena `bce3448`. All eight candidate/control
  runs reproduce the two finding families, four exact tracker searches found no
  duplicate issues, and the public-report security assessment found no concrete
  exploit requiring private disclosure. Five focused external drafts are
  prepared and hash-bound. At the preflight boundary none had been submitted;
  the later Arena proposal is recorded separately below.
- `F-REDUCTION-SEMANTICS-MATRIX`: normalized eight exact beta, zeta,
  projection, recursor, quotient, and native-natural reduction boundaries.
  All four checkers accept every candidate and control. The focused
  `Quot.lift` candidate kills its dispatch mutant; `Quot.ind` cannot expose
  proof-valued reduction suppression because proof irrelevance identifies the
  results. The exact `Nat.ble` case survives its dispatch mutant, while
  `Nat.land` kills the same mutant by exposing collateral misclassification.
  No checker issue is recommended from this passing bounded matrix.
- `F-ORDINARY-INDUCTIVE-WELL-FORMEDNESS`: characterized six exact strict-
  positivity, constructor-parameter, result-parameter, result-universe, and
  recursive-index boundaries from canonical Arena cases. All four checkers
  reject every malformed candidate and accept every control. Focused Nanoda
  positivity and result-parameter omission probes survive because independent
  `isRec` or reconstructed-recursor consistency checks reject the canonical
  artifacts. That is defense-in-depth evidence, not an equivalence result; no
  external issue is recommended from the consensus matrix.
- `F-ORDINARY-INDUCTIVE-PARAMETER-WITNESS`: killed `nanoda-0006` with a
  fully exporter-generated inductive whose proof parameters `p` and `q` are
  swapped only in the constructor result. Baseline Nanoda rejects at exact
  parameter matching, the omission mutant accepts, and both accept the control.
  Official Lean and Lean4Lean reject; current Kiota main `686063c` accepts.
  One Arena reject-test proposal and one Kiota issue are recommended but remain
  human-gated; no external action has been taken.
- `F-ORDINARY-INDUCTIVE-POSITIVITY-WITNESS`: killed `nanoda-0005` with a
  full-recursor artifact whose shared constructor/recursor field domain changes
  from `Unit` to definitionally equal `LALConstType Unit I`. Baseline Nanoda
  rejects at strict positivity, the omission mutant accepts, and both accept the
  control. Official Lean, Kiota, and Lean4Lean all confirm rejection. A single
  Arena test proposal is recommended because the existing dummy-recursor case
  does not isolate the rule; no implementation issue is recommended.
- `F-LITERAL-PARSER-CONFIGURATION`: closed the family at Nanoda's pinned public
  entrypoint. Two Nat-extension assertion omissions and one String-extension
  assertion omission are already proved equivalent: active config enables the
  extensions, while disabled config rejects literal records in the parser and
  internal constructors before the mutated downstream checks. No checker issue
  or additional matrix is recommended from this configuration-reachability
  result.
- `F-IMAX-ARENA-PROPOSAL`: filed
  [Arena #175](https://github.com/leanprover/lean-kernel-arena/issues/175) to
  clarify and add reject coverage for the two right-successor comparisons.
  Maintainer guidance invited the corner-case tests, and one small Arena test
  contribution was submitted as
  [Arena PR #176](https://github.com/leanprover/lean-kernel-arena/pull/176).
  The single `Tutorial.lean` change adds the adjacent `imax u 1` and
  `imax u (v + 1)` reject cases. The PR is open and mergeable as of 2026-08-29,
  not yet merged. Nanoda and Kiota implementation reports remain unpublished.

### Frontier Transition — 2026-08-30

- The human-approved
  [Declaration Validation Contract Slice](research/DECLARATION_VALIDATION_CONTRACT_SLICE_PLAN.md)
  takes the deliberate-supersession path defined by its Milestone 0. This is a
  planning-authority change, not a claim that the previous characterization
  gate was completed.
- `F-ASSURANCE-CLAIM-CHARACTERIZATION-VIEW` is superseded before its proposed
  builder was implemented. Its two-kind model, evidence-fidelity requirements,
  and prohibition on treating empirical observations as a semantic denominator
  remain mandatory inputs to the replacement frontier.
- `F-AXIOM-UNSAFE-DECLARATIONS` is absorbed as a bounded sub-question of the
  declaration-validation slice. Its existing evidence and unresolved states
  remain intact. This transition does not authorize a broad axiom campaign or
  permit trust-policy behavior into the primary kernel-validity denominator.

### Completed Predecessor — Declaration Validation Contract Slice

1. `F-DECLARATION-VALIDATION-CONTRACT-SLICE`: execute the revised
   [declaration-validation mandate](research/DECLARATION_VALIDATION_CONTRACT_SLICE_PLAN.md).
   The deliberate frontier transition and starting dirty-tree dispositions are
   recorded in the
   [Milestone 0 result](../results/research/declaration-validation-milestone-0.json).
   Milestone 1 is complete: the
   [semantic target lock](../config/declaration-validation-target.json) pins the
   Lean 4.33.0 checked declaration-addition judgment separately from the Lean
   4.29.1 artifact producer, the lean4export 3.1.0 producer/importer revisions,
   and all four Arena observer profiles. The lock preserves Lean4Lean's official
   C++ kernel lineage and the distinct parser revisions instead of treating
   checker agreement or version labels as semantic authority. Its schema and
   cross-field/evidence checks run with
   `scripts/validate-declaration-validation-target`; completion details are in
   the
   [Milestone 1 result](../results/research/declaration-validation-milestone-1.json).
   Milestones 2 and 3 are also complete. The canonical
   [characterization model](../config/declaration-validation-characterization-model.json)
   and strict
   [entry schema](../schemas/declaration-validation-characterization-entry.schema.json)
   preserve normative candidates separately from empirical scenarios; make
   layer, authority, lifecycle, and soundness relevance orthogonal; and require
   every evidence item to carry a role, source type, lock, exact locator,
   structured claim, and assumptions. Lean4Lean's derived lineage is enforced,
   and a four-observer implementation consensus is mechanically rejected as
   sufficient normative support. Run
   `scripts/validate-declaration-validation-characterization-model`; the durable
   results are
   [Milestone 2](../results/research/declaration-validation-milestone-2.json)
   and
   [Milestone 3](../results/research/declaration-validation-milestone-3.json).
   Milestone 4 is complete. The frozen
   [discovery closure](../config/declaration-validation-discovery-closure.json)
   exhausts 22 pinned source files into 59 disposed sites, closes 22 required
   topics with exact four-observer vectors, and assigns 13 helper dependencies
   to included, imported-prerequisite, or excluded states. It records 21
   provisional `SEED.*` groups but creates no catalog entry and assigns no
   stable semantic ID. In particular, Kiota's pinned current-declaration
   visibility and universe-ownership differences remain empirical observations,
   not normative or soundness conclusions. Run
   `scripts/validate-declaration-validation-discovery-closure`; completion
   details are in the
   [Milestone 4 result](../results/research/declaration-validation-milestone-4.json).
   Milestone 5 is complete. The frozen
   [stable identity registry](../config/declaration-validation-identity-registry.json)
   resolves all 21 provisional discovery seeds into 30 implementation-neutral
   identities: 19 normative candidates, 9 empirical scenarios, and 2 identities
   whose kind remains unresolved. The generated
   [decision log](../results/research/declaration-validation-milestone-5-decisions.json)
   preserves every keep, merge, split, reuse, deferral, and exclusion with
   discovery-only evidence and content-bound before/after hashes. It assigns no
   authority, layer, soundness relevance, catalog status, or coverage
   eligibility. Run `scripts/validate-declaration-validation-milestone-5`;
   completion details are in the
   [Milestone 5 result](../results/research/declaration-validation-milestone-5.json).
   Milestone 6 is complete. The frozen
   [source lock](../config/declaration-validation-source-lock.json) binds nine
   repository/revision identities, 41 pinned source/configuration/build files,
   19 tracked Lab evidence artifacts, 12 existing witnesses, 18 optional local
   observations, and all four observer configurations. Offline validation is
   independent of the ignored `external/` checkout; online verification has
   confirmed all 9 remote revisions, all 41 raw-content SHA-256 values, and 13
   enabled locator tokens. Normative-documentation and mechanized-result slots
   remain explicitly empty pending per-identity authority review. Run
   `scripts/validate-declaration-validation-source-lock`; completion details are
   in the
   [Milestone 6 result](../results/research/declaration-validation-milestone-6.json).
   Milestone 7 is complete. The authoritative
   [canonical catalog](../config/declaration-validation-catalog.json) is
   intentionally empty until Milestone 8 adjudicates the frozen identities.
   Six versioned
   [authority rules](../config/declaration-validation-authority-rules.json)
   cover both object kinds and all three authority states without admitting
   checker consensus as normative support. The
   [generated report](research/DECLARATION_VALIDATION_OBLIGATIONS.md) derives
   all catalog views and embeds the catalog hash; the
   [freeze manifest](../results/research/declaration-validation-milestone-7-freeze.json)
   binds the source lock, authority rules, catalog, report, and decision logs
   in an acyclic order. Run
   `scripts/validate-declaration-validation-catalog`; completion details are in
   the
   [Milestone 7 result](../results/research/declaration-validation-milestone-7.json).
   A separate adversarial review then exposed and the hardened M7 architecture
   corrected additional epistemic-boundary failures: semantic-target
   configuration and implementation files can no longer be relabeled as
   normative support; evidence type is coupled to locked record kind;
   unresolved or active normative assumptions and statement contradictions
   block `ESTABLISHED`; soundness remains mechanically restricted to
   `NOT_ASSESSED`; stable IDs bind their structured denotations; observer and
   implementation mappings are attribution-bound; and Milestone 8 requires an
   exact disposition of all 30 frozen identities. Decision records now bind a
   tracked before snapshot and the supplied after catalog. A new immutable
   [Milestone 7 evidence-lock root](../config/declaration-validation-evidence-locks/milestone-7.json)
   permits later evidence selection through a versioned successor without
   rewriting the frozen Milestone 6 lock. The generated report is status-aware,
   the completion record is schema/render/test gated, and JSON Pointer handling
   is strict RFC 6901. The predecessor sweep also changed Milestone 4's
   completion verification to content-check its mutable frontier documents and
   original validator as historical Git blobs, matching Milestones 5 and 6
   without rewriting historical bytes. These checks mechanically enforce the
   qualification rules; they do not prove those rules epistemically
   sufficient. The five-entry Milestone 8 candidate batch was then prepared
   for independent review before any further identity adjudication. Its canonical
   candidate data is
   [bound separately](../config/declaration-validation-milestone-8-pilot.json),
   and its generated review view is
   [available here](research/DECLARATION_VALIDATION_MILESTONE_8_PILOT.md).
   The pilot repair preserved its five frozen semantic identities and left all
   authority dispositions `PROVISIONAL` and all soundness relevance
   `NOT_ASSESSED`. Existing Lab witnesses are now discovery evidence rather
   than unsupported isolation; Kiota acceptance/rejection differences are
   implementation observations rather than authority contradictions. A
   content-bound M4-to-M5-to-M8 site-disposition vector closes all 31 relevant
   site/identity pairs for the five-entry scope, preserving Kiota's two
   universe-ownership absences as absence findings. Every pilot identity now
   has an explicit Arena disposition, with the existing
   `tutorial/012_nonPropThm` linkage bound as empirical coverage only. The
   repaired pilot binds the immutable empty pre-M8 authority registry snapshot
   and uses a sequence-3
   [repair successor lock](../config/declaration-validation-evidence-locks/milestone-8-pilot-repair.json).
   Authority-source successors now require a separately content-bound,
   predecessor-bound approval decision before a later catalog can bind them;
   no source was approved here. Validation passed
   `scripts/validate-declaration-validation-catalog`,
   `scripts/validate-declaration-validation-source-lock`,
   `scripts/validate-declaration-validation-milestone-8-pilot`, and all 123
   declaration-validation tests. At that point the next authorized action was
   an independent adversarial review of this corrected five-entry pilot; its
   later acceptance is recorded below with the lifecycle repair.

   A final residual exploit-first pass at
   `0bee1b71fe8d49ebe6a8adb5e4193c507ea2e43a` then demonstrated three remaining
   attacks with zero-error validation before repair: locally manufactured
   normative authority, checker outcomes asserted through free-form secondary
   metadata rather than result bytes, and stable-ID denotation drift through
   additional predicates or a different resolving judgment pointer. Equivalent
   probes also admitted forged authoritative documentation, self-asserted formal
   mechanization, and empirical precondition/observation drift. M7 now binds an
   intentionally empty, separately frozen
   [approved authority-source registry](../config/declaration-validation-approved-authority-sources.json).
   Evidence-lock snapshots cannot establish normative authority unless their
   external source identity was approved before catalog adjudication; M8 cannot
   extend that registry. Concrete checker observations are extracted from exact
   structured result pointers, with secondary locator strings treated only as
   annotations. Stable IDs bind a canonical semantic projection covering the
   modeled judgment, exact applicability/reach structure, target predicate,
   violation semantics, and empirical scenario scope/observation target while
   excluding editorial and research-result metadata. The named residual attack
   tests are frozen in `tests/test_declaration_validation_catalog.py`, and the
   generated Milestone 7 completion record preserves the accepted-at-baseline
   and rejected-after-hardening results. The catalog remains empty, the approved
   registry contains zero sources, soundness remains `NOT_ASSESSED`, and the M8
   five-entry pilot remained review-only without asserting M8 completion. The exact
   claim is limited to mechanical rejection of these
   attacks, not epistemic sufficiency of the authority model.

   The repository operating-instruction prerequisite is complete: `AGENTS.md`
   now routes agents through this status artifact and the active plan, and the
   repository-local declaration-validation adjudication skill routes M8/M9
   catalog work to the canonical artifacts and validators. This organizational
   change does not start M8, alter the frontier, or change any research finding.

   The M7→M8 historical transition boundary is now mechanically safe. The
   actual pre-M8 M7 catalog, its M7-era schema, generated report, validator,
   tests, freeze, completion record, and all completion dependencies are
   recovered through the exact Git blobs at
   `da6b56af92ce2bcbfa6f2f29a6f699b2f0b24c19`. The new historical attestation
   preserves the trail that `a9c52cc334886cebbeb8d38e47454c02b893613a`
   legitimately evolved the current catalog schema but had re-rendered mutable
   M7 paths. Historical validation now uses the recovered blobs and their own
   historical schemas, never the current catalog path.

   The five-entry repaired pilot is likewise historical: its M7 predecessor is
   the M7 attestation; its prior pilot provenance, authority registry, source
   lock, evidence-lock chain, schemas, decision log, and other inputs are
   pinned to exact Git blobs from the repair commit. A transition regression
   supplies an M8-shaped current catalog with different bytes and proves that
   the M7 catalog, freeze, and completion blobs and the pilot bytes remain
   unchanged while both historical validators pass. This does not populate the
   remaining 25 identities, approve authority sources, assess soundness, or
   start M9. Validation passed
   `scripts/validate-declaration-validation-source-lock`,
   `scripts/validate-declaration-validation-catalog`,
   `scripts/validate-declaration-validation-milestone-8-pilot`,
   `scripts/validate-declaration-validation-historical`, and all 127
   declaration-validation tests. The exact next authorized action is:
   **Populate and adjudicate the
   complete Milestone 8 frozen identity inventory.**

   The reviewed five-entry M8 pilot is now independently immutable. Its new
   [reviewed-pilot historical attestation](../results/research/declaration-validation-milestone-8-pilot-reviewed-historical.json)
   binds the exact `config/declaration-validation-milestone-8-pilot.json`
   bytes from `62e0631949f514c1d8458bd0562621dfba60cefe` (Git blob
   `8a76bb539083e440b048b26076b7c4c9f5c92ae8`, SHA-256
   `6fa2622de2d23e520a609a811d38f67097778a89203349993a619f0afc3057ed`),
   its historical v2 schema, and its M7 historical-attestation predecessor.
   The reviewed-pilot validator resolves those Git blobs directly; it no
   longer loads the mutable pilot path as historical input. The current path
   remains only a convenience representation.

   The strengthened M7→M8 transition regression proves that a different
   M8-shaped current catalog leaves immutable M7 and reviewed-pilot validation
   passing, then proves that an invalid mutable current pilot cannot redefine
   the reviewed blob. It rejects wrong reviewed-pilot blob, SHA-256, and
   historical-commit bindings. This provenance-only repair leaves the five
   semantic denotations, classifications, observer outcomes, authority-source
   counts (0 normative, 0 mechanized), and `NOT_ASSESSED` soundness conclusion
   unchanged. Validation passed
   `scripts/validate-declaration-validation-source-lock`,
   `scripts/validate-declaration-validation-historical`,
   `scripts/validate-declaration-validation-milestone-8-pilot`,
   `scripts/validate-declaration-validation-catalog`, and all 130
   declaration-validation tests. The exact next authorized action remains:
   **Populate and adjudicate the
   complete Milestone 8 frozen identity inventory.**

   Milestone 8 is now complete. The canonical
   [catalog](../config/declaration-validation-catalog.json) has status
   `MILESTONE_8_CHARACTERIZATION_INVENTORY` and exactly dispositions all 30
   frozen identities: 27 active entries, one deferred unresolved-kind identity,
   and two reserved out-of-scope identities. The active entries comprise 19
   normative candidates and 8 empirical scenarios. All 27 authority states
   remain `PROVISIONAL`, the frozen approved-authority-source registry remains
   empty, and all soundness relevance remains `NOT_ASSESSED`. The complete
   149-row site-disposition vector preserves every relevant M4/M5 identity-site
   pair, including the reviewed pilot's Kiota absence findings, while 104
   source-locked implementation mappings make the broader inventory
   reproducible without treating implementations as authority.

   The sequence-4
   [M8 evidence lock](../config/declaration-validation-evidence-locks/milestone-8-inventory.json)
   extends the immutable repaired-pilot chain without selecting normative or
   mechanized authority. The generated obligations report, M8 freeze manifest,
   and M8 completion record bind the canonical result. Validation passed the
   source-lock, historical M7/reviewed-pilot transition, canonical catalog, M8
   completion, and declaration-validation test gates. No M9 challenge has been
   adjudicated and no Arena coverage denominator has been created. The exact
   next authorized action is: **Conduct Milestone 9 as a separate reproducible
   adversarial review of the frozen M8 inventory.**

   A bounded M8 correction pass has now finalized its Phase-A content. The
   validator derives 41 exact frozen existing-evidence/identity pairs: 18 from
   direct witness/control `relevant_case_id` tags, 22 from tracked evidence
   containing those exact witness paths or SHA-256 values, and one from the
   immutable reviewed-pilot Arena link. Twenty-four pairs are linked and 17
   are explicitly dispositioned; deleting any row or redirecting it to an
   unrelated identity fails validation. Existing structured rows add concrete
   official, Lean4Lean, and Kiota outcomes to the replay-visibility,
   axiom-admission, and declaration-safety-reconstruction scenarios. Nanoda
   remains `NOT_INSPECTED` for those cases. The five reviewed pilot entries are
   still reused byte-for-byte.

   Authority did not strengthen: all 27 entries remain `PROVISIONAL`, the
   approved normative and mechanized source counts remain zero, and all
   soundness relevance remains `NOT_ASSESSED`. The prior path-hashed M8
   "freeze" is corrected to a final content manifest.

   The corrected Phase-A content is commit
   `714d0466a9f3e0ed1c8a8c6d20508324a48b3a1d`; its catalog SHA-256 is
   `b3e5b9f59de3600d2c42a1549af51e32e0a589be7484ad4dd0b85cab53c0207f`
   and its recorded gate is 137 declaration-validation tests with zero
   failures or errors. The separate Phase-B
   [M8 historical attestation](../results/research/declaration-validation-milestone-8-historical.json)
   has SHA-256
   `54facd2b732e612f21d0016b2525cb61a950cf78811b62b9ac8374fa9e15985a`.
   It resolves 56 core artifacts and 31 evidence records exclusively as exact
   Git blobs at the Phase-A commit. Current path edits therefore cannot
   redefine M8.

   The M8→M9 transition regression simulates a different future current
   catalog while proving that M7, the reviewed pilot, and corrected M8 still
   validate unchanged. Tampering with the M8 catalog blob, catalog SHA-256,
   historical commit, or completion/content-manifest binding fails. The final
   Phase-B gate passed the source-lock, historical M7/reviewed-pilot/corrected-
   M8, reviewed-pilot, and canonical-catalog validators plus all 139
   declaration-validation tests with zero failures or errors.

   Milestone 9 is being repaired at its own frontier. The prior renderer had
   synthesized all twelve favorable dispositions and the zero-correction
   conclusion, so that state was only a reproducible M8 self-consistency audit.
   The replacement architecture treats immutable M8 as data, the M9 JSON review
   as canonical authored judgment, and renderers/validators as presentation and
   procedural enforcement only.

   The primary reviewer performed the bounded semantic attacks over every
   normative candidate and empirical scenario, all four lineages, independent
   observability, duplicate/merge/split clusters, established-state vacuity,
   exact pinned discovery entrypoints and helper chains, exclusions, soundness
   language, and reconstruction. The authored result is zero catalog
   corrections. The result was not predetermined: regressions prove an authored
   failed challenge with a matching catalog correction can validate and that a
   changed authored disposition/rationale survives rendering unchanged.

   All 27 active entries remain `PROVISIONAL`; approved normative and mechanized
   sources remain zero; all soundness relevance remains `NOT_ASSESSED`; and no
   Arena denominator or broad study has begun. The M9 start binding now verifies
   corrected M8 attestation commit
   `15c76f27479dafc4213774b0acffb0d1d84fa2ed`. The repaired Phase-A content is
   commit `69dad9d13e4802e5ef29c958c60d2ee387293847`; its content gate passed 158
   declaration-validation tests and the 11-test transition module with the two
   Phase-B-only tests skipped.

   The separate Phase-B
   [M9 historical attestation](../results/research/declaration-validation-milestone-9-historical.json)
   has SHA-256
   `6a26aff21d26284b5e6298a33bc0977c9c20b0c063d42aafcf0e33210d821a89`
   and binds 46 exact Git blobs at the Phase-A commit. Historical M9 validation
   uses those blobs rather than mutable M9 paths. The active M9→M10 transition
   and tampering module passes all 11 tests with no skips; the complete Phase-B
   declaration-validation suite passes all 158 tests. Wrong reviewed-catalog
   blob or SHA, historical commit, review blob, and completion/content-manifest
   binding are rejected. Milestone 9 is now an immutable historical
   predecessor. **Milestone 10 has not started.**

   A pre-M10 specification amendment now makes the next milestone's design-only
   boundary explicit. Immutable reviewed M9 Git blobs are the eligibility
   input; the strict normative denominator is expected to be empty because all
   active entries remain `PROVISIONAL`; and M10 may neither resolve authority
   nor execute Arena, checker, mutation, witness-synthesis, or cross-validation
   research. M10 must still analyze every frozen entry across separate semantic
   negative-testability, Arena-representability, and isolation-feasibility
   dimensions, derive both the strict denominator and separately labeled
   exploratory set, specify the future protocol, and freeze that design through
   the corrected-M8/repaired-M9 two-phase historical pattern. This amendment
   changes no catalog state, evidence, authority, or research finding.
   Milestone 10 Phase A is now finalized. The canonical
   [study design](../config/declaration-validation-milestone-10-study.json)
   resolves eligibility only from the exact reviewed-catalog and identity-
   registry Git blobs in the immutable M9 attestation. It independently records
   kind, authority, kernel-layer, study-scope, semantic-negative-testability,
   Arena-representability, isolation-feasibility, and lifecycle determinations
   for all 30 identities without authority short-circuiting.

   The generated
   [populations](../results/research/declaration-validation-milestone-10-populations.json)
   mechanically derive an empty strict primary denominator, 19 provisional
   exploratory candidates, eight empirical characterization-context entries,
   and the complete three-identity deferred/reserved boundary. No normative
   percentage is reported. The frozen future protocol defines the
   `Reach(x) AND NOT P(x)` evidence contract, positive controls, competing-
   obligation analysis, authority-scoped expected outcomes, checker
   attribution, synthesis tiers, and ten successor execution gates. No
   authority or soundness state changed and no substantive campaign ran.

   The Phase-A design content is commit
   `2811fdbbe146009775ebdb1bd3b153f59ae503eb`. The separate
   [M10 historical attestation](../results/research/declaration-validation-milestone-10-historical.json)
   has SHA-256
   `976d450f9f1afd6f1a41c388c5bb623ce524d28aa1d1ac6c6634316eb3a31120`
   and binds 24 exact Git blobs at that commit. Historical validation rebuilds
   the M9 predecessor binding, M10 design, populations, report, content
   manifest, completion, schemas, renderers, validators, and tests from those
   blobs rather than mutable successor paths.

   The M10→successor transition permits later current study inputs and plans to
   evolve without redefining the frozen protocol. Wrong study blob, population
   SHA-256, historical commit, and completion/content-manifest bindings fail.
   The complete Phase-B declaration-validation suite passes all 175 tests with
   no skips. **Milestone 10 has reached its stop condition. This mandate
   authorizes no coverage, synthesis, mutation, checker, authority-resolution,
   or successor experiment; any such work requires a separately governed plan.**

   A post-M10 protocol erratum now corrects the future matched-positive-control
   rule for `DECL.THEOREM.TYPE_PROP` without changing any frozen M10 byte. A
   definition-form artifact removes applicability of the theorem-specific
   proposition-type premise, so it remains only auxiliary representability and
   well-formedness evidence. Any future isolated-coverage claim must instead
   bind a Prop-valued theorem in the same construction family with a matching
   valid proof. The erratum preserves the empty primary denominator, all
   readiness statuses and populations, and the M10 stop condition. It
   authorizes no successor experiment. The Phase-A correction content is commit
   `3f8d88ad4df80d746dbb3415156a1d31a01053e5`. Its separate historical
   attestation has SHA-256
   `1480e214881bc45c10f23bdac27663c8f31bc2dee6b0e50558c002cae4cdc786`
   and binds 13 exact Git blobs at that commit. The complete Phase-B
   declaration-validation suite passes 185 tests with no skips. M10 remains at
   its stop condition and no successor research is authorized.

### Frontier Transition — 2026-09-01

- The human-authorized
  [Declaration-Validation Obligation-Sensitive Coverage Study](research/DECLARATION_VALIDATION_PUBLICATION_STUDY_PLAN.md)
  activates `F-DECLARATION-VALIDATION-OBLIGATION-COVERAGE-STUDY` from the exact
  pushed plan at commit `34304bd39b6d0416b4c2a2fcb3c72f2d7b30c08a`
  (SHA-256
  `7beae5f915511005b7e6e601c610265b2ff11534b98394e2e205c0f63cf0e92c`).
- `F-DECLARATION-VALIDATION-CONTRACT-SLICE` is complete at its M10 stop
  condition and is an immutable predecessor, not an active source of successor
  semantics. The successor must resolve M10 through
  `results/research/declaration-validation-milestone-10-historical.json`
  (SHA-256
  `976d450f9f1afd6f1a41c388c5bb623ce524d28aa1d1ac6c6634316eb3a31120`)
  and protocol erratum 1 through
  `results/research/declaration-validation-milestone-10-protocol-erratum-1-historical.json`
  (SHA-256
  `1480e214881bc45c10f23bdac27663c8f31bc2dee6b0e50558c002cae4cdc786`).
- This transition authorizes the bounded publication study, including the
  separately staged authority-source process. It does not authorize external
  publication or contact, adaptive cohort substitution, authority inference
  from implementations/checkers/LLMs, or reinterpretation of M10 through
  mutable current files.

### Source-Discovery Freeze — 2026-09-02

- The exact 15-candidate preregistration is frozen at commit
  `c420e451b50fbbb56bb5ba89fb7faa4b65ac9a9a`, Git blob
  `0acc79081f6b81ea9b3ee59f029ee64b88474377`, and SHA-256
  `94f2a293407b6917b44361ca4b173c7e74972867c52d127ce336e10c1ed7592a`.
- Bounded authority-source discovery is `CLOSED`: all 30 preregistered queries
  executed with no access failure, and the canonical result retains 18
  content-bound source candidates. The discovery record and compact review
  packet are frozen before approval; neither records a human authority
  decision.
- The study is stopped at the separately governed source-approval boundary.
  The fixed post-approval process sentinels remain
  `DECL.THEOREM.TYPE_PROP` and `EXPR.LET.VALUE_TYPE_MATCH`. No catalog entry,
  denominator, baseline, synthesis, mutation, or checker work is authorized
  until the retained source-to-claim mappings receive explicit human
  `APPROVE`, `REJECT`, or `DEFER` decisions.

### Human Authority-Source Approval — 2026-09-04

- The separately human-approved source decision is frozen against the exact
  source-discovery result. It approves only
  `CLAIM.SOURCE.MANUAL.DEFS.THEOREM_PROP` for
  `DECL.THEOREM.TYPE_PROP` from the exact v4.33 Lean Language Reference
  `Manual/Defs.lean` bytes. The same source's header-before-body statement is
  rejected for current-declaration visibility; all other source mappings are
  deferred or rejected as recorded.
- The immutable M7 pre-M8 authority registry remains byte-for-byte empty. Its
  versioned successor
  `ordinary-declaration-validation.approved-authority-sources.publication-study.v2`
  contains only the claim-scoped manual source and cannot be extended by
  catalog adjudication.
- The next separately bounded activity is the fixed two-entry authority-process
  sentinel. It has not begun. No catalog adjudication, denominator freeze,
  baseline, synthesis, mutation, or checker campaign is authorized by the
  approval decision alone.

### Gate-5 Sentinel Validation — 2026-09-04

- The fixed sentinel adjudication is complete for exactly
  `DECL.THEOREM.TYPE_PROP` and `EXPR.LET.VALUE_TYPE_MATCH`. The theorem
  obligation is `ESTABLISHED` from the exact claim-scoped v4.33 Lean Language
  Reference source. The let-value/type obligation remains `PROVISIONAL`
  because all relevant Gate-4 mappings are deferred or rejected and no
  approved source is scoped to its frozen raw-expression denotation.
- The sentinel exposed an epistemic-boundary defect in the pre-sentinel
  architecture: approved document identity was checked mechanically, but the
  exact human-approved source-claim-candidate mapping was not. Gate 5 adds an
  explicit claim-scope guard bound to the full frozen approval result; a
  cross-claim attempt to use the theorem-only approval for the let obligation
  is now rejected. The repaired sentinel architecture passes.
- The M10 theorem-control erratum remains operative and content-bound: any
  future matched positive control must be a Prop-valued theorem in the same
  construction family with a matching valid proof. The definition-form
  artifact remains auxiliary representability and well-formedness evidence.
- The remaining 13 candidates have not been adjudicated. No denominator,
  baseline, coverage, synthesis, mutation, or checker work has begun. The next
  bounded activity is Gate 6 complete adjudication under the repaired
  claim-scope architecture.

### Gate-6 Complete Authority Adjudication — 2026-09-04

- All 15 preregistered candidates now have durable validated authority
  dispositions. `DECL.THEOREM.TYPE_PROP` remains the sole `ESTABLISHED`
  obligation. The other 14 candidates are `PROVISIONAL`; no candidate is
  `UNRESOLVED`.
- The 13 Gate-6 decisions reproduce every applicable frozen Gate-4 claim
  disposition under the Gate-5 claim-scope repair. All relevant mappings are
  `DEFER` or `REJECT`, so none supplies qualifying normative support. The exact
  candidate order, identity hashes, semantic-denotation hashes, evidence
  references, qualification rules, and disposition counts are mechanically
  checked.
- The Gate-5 catalog and evidence lock are preserved through exact Git-blob
  bindings at commit `f1161457c9b1eb817f020021d8d39e8d95a6497d`; both
  sentinel entry records remain unchanged. The sequence-8 evidence-lock
  successor adds no evidence and inherits only the claim-scoped theorem source.
- Gate 6 does not derive the denominator or claim tier. No source discovery,
  source approval change, baseline, coverage, synthesis, mutation, or checker
  work occurred. Gate 7 denominator freeze is the next bounded activity.

### Gate-7 Denominator Freeze — 2026-09-04

- The required presentation-only living manuscript skeleton was committed
  before Gate 7 at `e38b845e2ed0382f1682e509e089abf26ef9602e`. It contains
  the five frozen research questions, preregistered methodology and threats,
  all twelve required sections, and empty baseline and synthesis tables. It is
  explicitly not semantic authority.
- The exact Gate-6 adjudication, catalog, and evidence-lock Git blobs are bound
  at commit `b2099c4008c836de873c09504e2e1fccae78c0fc`. Reapplying the
  unchanged `M10.PRIMARY.NORMATIVE.NEGATIVE.COVERAGE.ELIGIBILITY.V1`
  conjunction mechanically derives a one-entry strict primary denominator:
  `DECL.THEOREM.TYPE_PROP`.
- The other 14 cohort entries remain a separately labeled provisional
  exploratory set; the unresolved cohort set is empty. Four technical-
  readiness holdouts, eight empirical contexts, and three deferred or reserved
  identities remain outside the normative denominator.
- One established obligation in one preregistered semantic family mechanically
  selects the `BOUNDED_PILOT` claim tier. This tier limits later claim scope; it
  does not change denominator membership or establish representativeness.
- No authority disposition or source approval changed. No baseline,
  comparator, coverage percentage, synthesis, mutation, checker, or external-
  action work began. Gate 8 baseline and comparator freeze is the next bounded
  activity.

### Gate-8 Baseline and Comparator Freeze — 2026-09-04

- The exact existing Arena and repository corpus inventories, exporter and
  reconstruction pipeline identities, four observer profiles and binaries,
  build recipes, test-to-artifact mappings, resource policy, classification
  tooling, and prior-knowledge register are frozen against the Gate-7 content
  commit. No checker, coverage, mutation, or synthesis execution was performed.
- The sole denominator entry, `DECL.THEOREM.TYPE_PROP`, is classified
  `OBSERVED_NEGATIVE_NOT_ISOLATED`. The exact existing non-Prop theorem case is
  reachable, violates the established obligation, has complete competing-rule
  analysis and exact four-checker rejection attribution, but the frozen inputs
  contain no Prop-valued same-family theorem control satisfying M10 erratum 1.
  Existing isolated-negative coverage is therefore 0/1 (0.0%).
- Its separate contextual comparator classifications are `SOURCE_REACHED`,
  `MUTANT_KILLED`, and `EXISTING_CASE_LINKED`. These labels do not establish
  semantic coverage. The source-reach claim is limited to the exact unchanged
  theorem artifact and reciprocal Nanoda line map because the legacy aggregate
  coverage snapshot names an older Arena revision.
- The ignored raw coverage maps are content-bound in the input freeze and the
  relevant mapping is excerpted. Retaining or reproducibly regenerating those
  local files remains necessary for later full-payload verification.
- `DECL.THEOREM.TYPE_PROP` is the sole Gate-9 target because the required
  matched theorem control is missing. Gate 9 has not begun: no strategy or
  budget is frozen and no witness or control was created or modified.

### Gate-9 Synthesis Protocol — 2026-09-04

- The [bounded synthesis protocol](../config/declaration-validation-publication-study-gate-9.json)
  binds the exact Gate-8 baseline, input freeze, preregistration, validator and
  manuscript Git blobs at `6cb81b2e87651f5380272e8f59e53a6cb0142fc1`.
  Its sole target remains `DECL.THEOREM.TYPE_PROP`; the denominator, authority
  dispositions, baseline and all predecessor bytes remain unchanged.
- Run `publication-study-theorem-control-0001` permits one Tier-1 pair: reuse
  the exact M6 negative and construct a same-family Prop-valued theorem with
  a matching identity proof. The definition-form artifact remains auxiliary.
  All 18 competing obligations must be re-evaluated for the exact pair.
- The protocol caps execution at eight checker launches, 30 seconds per
  launch and 600 seconds cumulative active run time. It permits no Tier-2/3
  fallback, minimization, new mutants, coverage collection or feedback-driven
  repair. Failed construction and interrupted launches consume budget.
- The new Gate-9 validator and tampering/transition tests check the protocol
  against immutable inputs. Commit the protocol before materialization; bind
  the future constructor and runner before generation and the exact candidate
  pair before checker feedback. Gate 10 execution has not started.
- Verification passed: the Gate-9 full-chain/payload validator, canonical
  catalog validator, 331-test local full-payload run (no skips), and four
  runner-boundary tests. The fresh full-history clone passed its 331-test run
  with three explicit materialization-dependent skips; its strict payload
  preflight failed as expected. Historical transition/tampering tests are
  included in the unit runs. Community gates passed 24/24 and 30/30 checks.
- The result must distinguish completion of a missing matched control from
  discovery of a new negative or implementation defect. A possible 0/1 to 1/1
  change alone cannot support broad methodological or bug-finding claims.

### Reproduction and Agent Workflow Repair — 2026-09-04

- CI now fetches complete Git history for historical evidence validation.
  `scripts/run-unit-tests` preserves the frozen tests and reports an explicit
  skip for the exact Gate-8 full-payload integration test when inventoried
  local payloads are absent. `--require-full-payload` instead fails preflight;
  present payloads retain the original validation and hash checks. The full
  assurance validators are unchanged.
- [Agent task navigation](AGENT_WORKFLOW.md) records the owner's delegation
  preferences, progressive evidence loading, file ownership and context
  handoff procedure. It is an operational index, not research authority.

### Gate-10 Result and Recommendation Closure — 2026-09-04

- The protocol, schema, validator, constructor and runner bytes were bound
  before reserving the single candidate pair. The exact negative/control,
  metadata, transformation, expected outcomes and all 18 competing-obligation
  analyses were frozen before the first of eight launches. Raw process bytes,
  reservations and the completed active interval are retained under
  `results/research/publication-study-theorem-control-0001/`.
- The canonical result is `ISOLATED_SUCCESS`: every frozen observer accepted
  the identity-theorem control and rejected the unchanged M6 negative with
  target attribution. The paired construction closes all seven M10 isolation
  elements under erratum 1. The 3.875-second run did not use repairs, retries,
  minimization, new mutants or new coverage collection.
- Validation passed: Gate-10 full-chain/full-payload entrypoint, canonical
  catalog validator, 353-test local full-payload suite without skips, and the
  final 16-test focused Gate-10 suite. The full suite includes historical
  transition/tampering regressions and the bounded runner tests. A fresh
  full-history clone with the exact working changes overlaid passed the
  tracked-result validator and all 16 focused tests without local observer
  payloads; its strict payload preflight failed as expected. Community gates
  passed 24/24 and 30/30. The artifact graph is current; the broader assurance
  gate retains its pre-existing failure on 15 unresolved semantic disagreements.
- The generated Gate-10 report is an explicit successor presentation artifact;
  the manuscript bound by Gate 9 and all frozen predecessor bytes remain
  unchanged. An Arena companion-control recommendation is deferred with
  concrete unmet prerequisites. Gate 11 publication interpretation requires
  the separate scientific review flagged below; Gate 12 final study historical
  freeze and external publication have not begun.

### Gate-11 Decision and Gate-12 Phase-A Preparation — 2026-09-04

- The separately requested Ultra scientific review found no consequential
  isolation defect or need for a Gate-10 erratum. The frozen machine-readable
  preregistration requires `STRONG_POSITIVE` before the secondary specification
  trigger. The derived decision is `STRONG_POSITIVE / BOUNDED_PILOT /
  PUBLISH_BOUNDED`, with a bounded technical report recommended. This registered
  label does not establish broad method strength, new defect discovery or a
  general synthesis-performance result.
- The final report preserves the 14 provisional candidates as a bounded
  qualification gap, including target correspondence, raw-expression mapping,
  and proof-dependency/axiom closure. It does not infer global absence of Lean
  documentation. The Arena companion-control proposal remains deferred.
- Gate 12 is prepared as a two-phase freeze: first commit the exact study
  content and non-self-referential manifest, then create a separate Git-blob
  attestation. Its validator reconstructs the committed tree and executes the
  bound validator there, so later live facts and code cannot redefine history.
  Phase-A verification passed all 367 full-payload unit tests without skips,
  the full-payload closure validator, focused decision/history tests, and the
  scripted assurance refresh with a current artifact graph. The actual Phase-B
  attestation remains to be completed.

### Gate-12 Historical Closure — 2026-09-04

- Phase A committed the complete study content and 245-file manifest as
  `4cd21c61b3252d325103d67afcd79a63e051f4c2`. Phase B created the separate
  [historical attestation](../results/research/declaration-validation-publication-study-historical.json),
  SHA-256 `df435204d56c77edb073c9cac9f167658eb2b76d561627eaa6018a241f5ff6f7`.
  Creation validated exact committed blobs, reconstructed the committed tree,
  and ran its bound closure validator, including the prior historical chain.
- Gates 0–12 are closed. The final decision, report, manifest and attestation
  are historical; do not regenerate them against later current state. Validate
  with `scripts/close-declaration-validation-publication-study validate-historical`.
  This live status file is a successor of the exact Phase-A status preserved in
  the historical commit. The study's stop recommendation is now effective.
- Initial post-transition full-payload verification exposed the old Gate-8
  requirement that the study be the Active frontier. Historical validation
  itself passed. The explicit successor `scripts/validate-publication-study-snapshot`
  supplies the original committed state and exact local payloads to unchanged
  validators. The unit runner likewise partitions exact attested study modules
  into the historical tree and retains future tests in the live tree. The
  obsolete frontier is not reactivated and no frozen guard is weakened.
- Final verification on 2026-09-05 passed: 302 current tests and 73 unchanged
  frozen study tests, all with full local payloads and no skips. The exact-study
  transition changed and committed successor facts, schemas and validator code
  while preserving validation against the original content. Snapshot full-payload
  validation and the scripted assurance refresh also passed. The initial
  post-transition run's two Active-frontier failures are resolved through the
  explicit successor; the frozen validators, tests and attestation are unchanged.

### Project Review Completed — 2026-09-05

- The [generated review](PROJECT_REVIEW.md) and
  [canonical input-bound review](../results/research/project-review.json) assess
  the project against the constitution and give ranked next steps with targets,
  prerequisites and falsifiable completion conditions. They use current local
  records; they do not claim a fresh upstream status survey.
- The project is aligned in reproducibility, scoped claims and preserved
  uncertainty. The highest-value next work is ecosystem closure of existing
  findings, coupled with portable, explicitly budgeted operation. More work on
  this completed one-obligation study is not recommended.
- Proposed order: close mature imax/proof-uniformity/projection/positivity
  recommendations; harden materialization and authorized bounded execution;
  triage a fixed subset of existing survivors; then consider a separately
  preregistered prospective or held-out transfer study. These are proposals,
  not automatic research activation.
- Mechanical refresh and report generation now use scripts; the operating guide
  preserves selective Luna/Terra delegation and separate Ultra review for named
  consequential scientific questions. The old hand-maintained metrics block is
  explicitly historical. External publication and new source approvals retain
  their recorded human decision boundaries.

### Corpus Integration and Witness Admission Closure — 2026-09-05

- The bounded successor completed its local work. Two companion packages build
  against Arena `abc55357aee17c59dfdbf39c8a2e19739e23dd10` in two bounded
  `build-test` calls, with zero checker launches and zero toolchain downloads.
  The proof-parameter package is control `accept` / candidate `either`; the
  complete-recursor positivity package is control `accept` / proposed candidate
  `reject`. Package outcomes are corpus policy, not normative authority.
- A separate Ultra scientific review found no currently approved qualified
  source that makes exact proof-parameter order a universal cross-validator
  obligation. It records an implementation-profile disagreement and corrects
  the pair description: the two edited expression nodes are shared into the
  recursor motive and rule annotation even though complete recursor metadata
  remains present.
- The two fixed Nanoda witnesses `nanoda-gen-f19ffc8a2e9b` and
  `nanoda-gen-21ef4d1d32a1` are admitted through the explicit
  `nanoda-augmented-v2` successor without new checker execution. They reduce
  `SURVIVED_WITHOUT_WITNESS` from 9 to 7. The current report records mutation
  score `0.9781021897810219` and modeled score `0.9305555555555556`; the new
  witnesses remain semantically `UNRESOLVED`, so the count of confirmed witness
  semantics remains 3.
- Three exact external review packets are ready: one Kiota contract-clarification
  issue, one Arena proof-parameter characterization pair, and one Arena
  complete-recursor positivity pair. No issue, comment, pull request, source
  approval, or publication was created by this successor.
- Owner follow-through is now recorded in the explicit external-action
  successor. The recent-commit check found neither pair already addressed.
  Arena PRs #181 and #182 were submitted separately after their focused builds
  passed. Maintainer feedback was then addressed: both PR descriptions were
  replaced with stand-alone source-level explanations, PR #182 moved to
  `tests/corner-cases/` as `proof-param-ok` and `proof-param-swap`; the renamed
  pair builds 2/2, and PR #181 was narrowed to the single
  `corner-cases/positivity-whnf` test with outcome `either`; it builds 1/1. The
  Kiota packet is deferred pending Arena feedback.

### Completed predecessor — Conditional reuse handoff, 2026-09-08

The following block records the completed conditional phase at entry to the
owner-authorized survivor-planning successor. Its pause was superseded only
for the planning scope in the Active section below.

1. `F-CONDITIONAL-VALIDATION-CONTRACTS` — assess whether a small conditional
   formal contract can explain a real validation boundary and improve a shared
   assurance asset. Owner-selected successor on 2026-09-06, governed by
   [docs/research/CONDITIONAL_VALIDATION_CONTRACTS_PLAN.md](research/CONDITIONAL_VALIDATION_CONTRACTS_PLAN.md).

Selected next item: `CVC-NEXT-AUTHORIZATION`.

Queue handoff: PAUSED.

The [ranked queue](../config/research-queue.json) governs order, eligibility,
finite budgets and closure records. CVC-1 retains its source-only `EXTEND`
decision; CVC-2 retains its `SPECIFICATION_PROPOSAL_UNCHECKED` historical result.
The four original Lab obligations are now checked under the separately named
conditional model `CVC-U1-A7`. Historical studies and failed runs stay closed.

`CVC-3` is COMPLETE with `BOUNDED_UNRESOLVED`. Its unchanged signature compiled
in attempt 1; attempt 2 failed with repairable lookup/decidability errors. Both
mandatory imported comparator reports independently exposed two axioms outside
the frozen allowlist: `Lean.Level.instLawfulBEqLevel` and
`Lean.Level.isExplicitSubsumedAux_eq`. These fixed reports are required in both
proof and counterexample modes. Lab proof repair cannot remove that immutable
input boundary, so the run is terminal and its 10 unspent slots are not reusable.
See the [result](../results/research/conditional-validation-contracts/cvc-3/result.json),
[diagnostic](../results/research/conditional-validation-contracts/cvc-3/stop-diagnostic.json),
and [stopping-point review](../results/research/queue-reviews/2026-09-06-cvc-3.json).
The failed Lab declarations and their error-recovery `sorryAx` reports are raw
failure evidence, not a checked theorem or counterexample. No observer ran.

`CVC-AXIOMS-1` is COMPLETE with `SUCCESS` for a source-only review, labeled
`SOURCE_ASSUMPTION_REVIEW_ONLY`. Its input-bound table records all seven
actually printed assumptions, their exact source statements, visible/partial
paths and discharge alternatives. `SUCCESSOR` recommends model `CVC-U1-A7`:
the same structured meaning and exact examples under an explicit seven-axiom
host envelope. Neither model selection nor independent review approves a
normative source, proves helper truth or consistency, or establishes runtime
refinement. The original CVC-2 allowlist remains frozen.

`CVC-CONDITIONAL-1` is COMPLETE with `SUCCESS` for protocol and minimal runner
preparation, labeled `PROTOCOL_PREPARED_BASELINE_UNEXECUTED`. The new runner
reuses existing process supervision, accounting, timeouts and cleanup, with
successor paths, six-build/two-session limits, and an obligatory audited baseline
stage. No materially new process machinery was introduced. Canonical reviewed
type declarations generate the exact baseline source; both comparator axiom
reports must equal A7, while per-Lab-result reports may use subsets. The
607-test full-payload suite passes; 23 required inert fixture reservations use
115 of the 320 reserved-second cap. No Lean, dependency or observer launch ran.

`CVC-3-CONDITIONAL` is COMPLETE with `BOUNDED_UNRESOLVED`. Its manifest,
controller, baseline and semantic inputs remain unchanged. Both signature and
baseline compiled, but attempt 2 failed the frozen baseline output audit with
`malformed full axiom list`. The transcript includes universe-decorated axiom
names, wrapped type headers and linter warnings. The diagnostic extraction does
not replace the failed audit; no semantic mismatch, checked Lab result or
assumption discharge is established. No proof feedback or observer ran. The
terminal ledger retains two attempts, four unspent slots, 55.59774324996397
research seconds and 2.71219816734083 compilation seconds.

`CVC-A7-REPAIR-1` is COMPLETE with `SUCCESS`. Its new source-bound tooling
repaired transcript compatibility and proof implementation without changing the
original scientific inputs. The fresh counted signature and baseline passed;
all nine independent type pairs and both exact A7 comparator reports match.
The first proof attempt checked `EncodingTarget`, `PreservationTarget`,
`AcceptanceTarget` and `BoundaryTarget`. `encoding_preserves` uses `propext`
and `Quot.sound`; the other three results use the full seven-assumption envelope.
No assumptions, consistency, parser/importer refinement or runtime
correspondence are thereby proved. See the
[result](../results/research/conditional-validation-contracts/cvc-a7-repair-1/result.json)
and [review](../results/research/queue-reviews/2026-09-07-cvc-a7-repair-1.json).

The owner-authorized [repair policy](../config/cvc-a7-repair-policy.json), pushed
as `d6f156d`, keeps scientific inputs and prior evidence fixed while allowing
tested tooling revisions within one item. Actual cumulative work includes
engineering; short checkpoints do not forfeit a full session. The repair used
1191.6413262079004 active seconds and three builds, including the fresh signature
and baseline. Combined A7 totals are five builds and 1247.2390694578644 seconds,
below six builds and 7200 seconds. Including original CVC-3, seven builds were
consumed. One A7 build is unused; the successful run is terminal. No dependency,
observer or research-network launch ran. Closure tests are separately recorded.

`CVC-4-CONDITIONAL` is COMPLETE with `BOUNDED_UNRESOLVED`. The fixed
right-successor and zero pairs completed under A7: official Lean refused E-POS,
Nanoda accepted it, and both refused the zero-invalid candidate after accepting
controls. Both parsers preserve raw imax. Nanoda's comparator simplifies its
right-successor case to max. Internal C++ comparator bytes and executable
refinement remain unproved; no invalid accepted proof is demonstrated.

The ownership comparison is unresolved. Official accepted its control, but
Nanoda failed before typechecking because the stream declares unused `v`
without a parameter-level record. Neither ownership candidate ran. Diagnosis
found no configuration repair that preserves both frozen scientific bytes and
observer binaries. A wrapper would change observed bytes; rebuilding would
change the pinned binary and exceed the zero-build allowance. This is an
explicit scientific-input boundary, not a semantic rejection or an automatic
stop for an undiagnosed tooling error. Original evidence remains unchanged.

The initial two-launch reporting pause was repaired within the same item by
disabling only axiom printing. Its two charges plus ten revised launches total
12/16, with 2830.644582/16200 active seconds and
0.386228 process seconds. Four slots remain unused. No setup or
research-network launch ran. See the [result](../results/research/conditional-validation-contracts/cvc-4-conditional/result.json),
[adapter diagnosis](../results/research/conditional-validation-contracts/cvc-4-conditional/adapter-boundary.json) and [review](../results/research/queue-reviews/2026-09-07-cvc-4-conditional.json).

`CVC-4-ADAPTER-REVIEW` is COMPLETE with `SUCCESS` for the existing-evidence
review and `SUCCESSOR` recommendation. It proposes one fresh unused `v` level
record immediately before each ownership definition, preserving every old byte
in order, the declared parameter lists and referenced syntax. This addresses
Nanoda's known importer prerequisite; parser success and subsequent ownership
behavior on those proposed bytes remain unobserved. The older constant-universe
witness includes an axiom and `Expr.const`, so it cannot directly replace the
fixed empty-environment Sort pair. The marginal value is a reproducible
serialization regression and one finite ownership-boundary comparison.

`CVC-4-OWNERSHIP-1` is COMPLETE with `SUCCESS`. The exact sole unused-`v`
level insertion preserves every old byte in order and the fixed name, ordered
parameters, value and type syntax. Both pinned observers accepted fresh owned
controls before either candidate. Official refused unowned `u`; Nanoda reached
the ownership assertion at `tc.rs:520`, beyond its prior `parser.rs:506` failure.
The candidate remains CHECKED_UNSUPPORTED, not a checked invalid proof.

The four new reservations plus twelve preserved predecessor reservations use the
cumulative sixteen-launch ceiling. New process time is 0.13902070792391896 seconds;
combined process time is 0.5252482886426151 seconds. Final active work, including
engineering and closure validation, is recorded in the
[work record](../results/research/conditional-validation-contracts/cvc-4-ownership-1/work-record.json).
No proof, setup or research-network launch ran. See the
[result](../results/research/conditional-validation-contracts/cvc-4-ownership-1/result.json),
[report](../results/research/conditional-validation-contracts/cvc-4-ownership-1/report.md),
[review](../results/research/queue-reviews/2026-09-08-cvc-4-ownership-1.json), and
[validation](../results/workflow-refresh/cvc-4-ownership-1-2026-09-08/validation.json).

`CVC-5-CONDITIONAL` is COMPLETE with `SUCCESS` for an existing-evidence
reuse package and `REUSE` phase decision. Its
[entry point](../results/research/conditional-validation-contracts/cvc-5-conditional/README.md)
and [canonical result](../results/research/conditional-validation-contracts/cvc-5-conditional/result.json)
tie the checked theorem and exact A7 assumptions to every original observation,
the distinct ownership successor, raw receipts and local serializer regression.
The original two-member AcceptanceTarget remains unchanged; later controls are
valid by definition and the unowned candidate remains CHECKED_UNSUPPORTED.
All previous failures, charges and limitations stay visible. No scientific
process or new variant ran. Actual active work and separately bounded closure
fixtures are recorded in its work and validation records.

`CVC-NEXT-AUTHORIZATION` is selected WAITING and unstarted. The phase now reuses
its completed assets and pauses further scientific execution. No valuable
currently authorized local successor remains: the finite comparison is complete,
the sixteen observer reservations are consumed, other semantic families and
research themes need authorization, and upstream work lacks a new recorded
substantive trigger. Original CVC-4/CVC-5 dependencies remain unchanged.

The next decision is owner authorization of a bounded `ALT-SURVIVORS` proposal
(the strongest concrete alternative), another named direction with its method
review and finite gates, or continued pause. Substantive maintainer guidance may
instead justify a scoped follow-up. The September 6 review remains applicable
to this unchanged slice; adopting a new method needs a fresh scoped assessment.
No external contribution adds demonstrated value now beyond the local regression
and existing Lean/Arena interactions. No new external action is recommended.

The explicit schema-v2 queue handoff records this authorization/state blocker.
Queue integrity can validate while execution is paused; readiness checks must
refuse it. Schema-v1 behavior and historical bindings remain unchanged.

The review created no new scientific bytes or observer outcome. A7, the checked
proof, old parser/reporting failures and all prior costs remain unchanged.
`E-UNOWNED` remains outside the model's Supported domain, not a semantic-invalidity
example. The catalog ownership obligation remains PROVISIONAL; no universal
normativity, refinement or invalid accepted proof is established. Original CVC-4
and CVC-5 remain PLANNED under their unmet original dependencies, and withdrawn
imax defect recommendations remain withdrawn. No external action is recommended
now; another successor is not automatic.

`CVC-RUNNER-2` remains SUCCESS for its bound protocol implementation and inert
control checks. `CVC-RUNNER-1` remains `BOUNDED_UNRESOLVED`; its cancellation,
orphan, uninstrumented worker launches and unknown actual duration stay unchanged.
Its original endpoint still refuses execution. CVC-PREP-2 remains SUCCESS with
37 upstream modules and 141 products; CVC-PREP-1 remains `BOUNDED_UNRESOLVED`.
CVC-3 adds 199.947382292 active seconds and 2.357550584 compilation seconds.
Before CVC-CONDITIONAL-1, aggregate preparation/runner/proof active time was 7174.931631292 seconds;
aggregate preparation/proof compilation time is 52.112492251 seconds. Prior
unknown fixture duration remains unknown. CVC-AXIOMS-1 source-review time is
recorded separately in its work record; it adds no research compilation or
observer time. CVC-CONDITIONAL-1 adds 1281.220193 active seconds, for a combined 8456.151824 seconds before its final administrative closure. Its 23 fixture reservations / 115 reserved seconds include the required full-suite fixtures. Final closure time is separately recorded and remains within this item’s total bound. Prior unknown fixture duration stays unknown.

CVC-3-CONDITIONAL adds 55.59774324996397 research seconds and
2.71219816734083 compilation seconds. The prior aggregate scope is
now 8511.749567541963 active seconds and
54.82469041808508 compilation seconds; source-review and
administrative closure costs remain separately visible in their records.
CVC-A7-REPAIR-1 adds 1191.6413262079004 research seconds and
4.791140998946503 compilation seconds. The same aggregate scope is now
9703.390893749864 active seconds and 59.61583141703158 compilation seconds.
Prior unknown fixture duration stays unknown.

`OPS-UPSTREAM-1` remains COMPLETE with `BOUNDED_UNRESOLVED`: required CLI
preflight failed authentication and no post-preflight GET ran. Current Arena
feedback/dispositions remain unknown. Repair access with
`gh auth login -h github.com --web`, then rank a fresh bounded check after
successful preflight. No repeated polling is enabled.

At each logical research-item closure, select the next item without starting it
unless the owner has explicitly requested continuation. This policy checkpoint
changes no normative-source approval or catalog disposition and publishes no
external research message. Reevaluate at the next stop using
[Research workflow](RESEARCH_WORKFLOW.md).

### Completed predecessor — Survivor reuse proposal, 2026-09-08

1. `F-SURVIVOR-TRIAGE-PROPOSAL` — the owner-authorized fixed planning item is
   complete under
   [docs/research/SURVIVOR_TRIAGE_PROPOSAL_PLAN.md](research/SURVIVOR_TRIAGE_PROPOSAL_PLAN.md).

Selected next item: `SURVIVOR-LET-REUSE-1`.

Queue handoff: PAUSED.

`ALT-SURVIVORS` is COMPLETE with `SUCCESS` for one fixed, non-executable proposal.
It selects `nanoda-gen-9face4e6a6f7` and reuses the exact 601-byte mismatch/control
pair from the prior `21ef` investigation. The mutation negates the same let
checking predicate with a different spelling. That source relationship and the
old observations motivate a small attribution test; they do not supply a new
selected-mutant outcome or semantic classification. All seven survivors and
the modeled population remain unchanged. See the
[entry point](../results/research/alt-survivors-2026-09-08/README.md),
[result](../results/research/alt-survivors-2026-09-08/result.json),
[execution proposal](../results/research/alt-survivors-2026-09-08/execution-proposal.json),
[review](../results/research/queue-reviews/2026-09-08-alt-survivors.json), and
[validation](../results/workflow-refresh/alt-survivors-2026-09-08/validation.json).

`SURVIVOR-LET-REUSE-1` is selected WAITING and unstarted. The owner authorized
planning only. Execution needs separate authorization of this exact proposal
and all seven prelaunch gates. The proposal fixes four primary baseline/mutant
cells, both controls before candidates, at most eight 30-second checker
reservations, two 120-second offline build reservations and 5400 cumulative
active seconds including engineering. The original selected-mutant binary was
not retained with an attributable identity; an isolated counted build is a
required future step. No new export-stream variants, proof, network requests
or external research actions are proposed. These are proposed execution caps,
not authority to launch. No runner or scientific process was started here.

The owner supplied the previous `CVC-NEXT-AUTHORIZATION` decision by explicitly
approving this one planning item. The exact prior placeholder and queue remain
in the entry snapshot; no second research item was executed to resolve it.
Historical conditional results, source assumptions, sixteen observer charges,
failed runs, unknown costs and original CVC-4/CVC-5 dependencies remain intact.
Current and historical transition checks preserve their original bindings.
No new catalog or normative-source decision is made.

The next owner decision is to authorize `SURVIVOR-LET-REUSE-1`, select another
named bounded direction, or retain this pause. No external action is recommended:
the proposed added value is association of an existing local regression with
one pending identity, not a distinct upstream behavior. A new method or broader
family requires its own scoped review. Existing Lean/Arena Waiting triggers and
Kiota deferrals remain unchanged. Only `ALT-SURVIVORS` closes in this work.

### Completed predecessor — Survivor association, 2026-09-08

1. `F-SURVIVOR-LET-ASSOCIATION` — the owner-authorized no-duplicate canonical
   association is complete under
   [docs/research/SURVIVOR_LET_ASSOCIATION_PLAN.md](research/SURVIVOR_LET_ASSOCIATION_PLAN.md).

Selected next item: `ALT-TRANSFER`.

Queue handoff: PAUSED.

`SURVIVOR-LET-REUSE-1` is COMPLETE with `SUCCESS`. The exact fixed matrix
distinguishes the selected 9face guard mutant: both controls accepted, the
baseline candidate followed the bound let-value refusal path, and the mutant
candidate accepted. One offline build and five checker reservations consumed
15.865707375 process seconds, including a retained output-attribution replay.
No new scientific export bytes, proof, research network request, official
observer run, external action or upstream report occurred.

`SURVIVOR-LET-ASSOCIATION-1` is COMPLETE with `SUCCESS`. Its tested successor
reuses the existing 21ef pair, appends only the 9face classification, and
creates no corpus bytes or research launches. The historical f19/21ef admission
and completed reuse result validate unchanged. The canonical pending set is six.

`ALT-TRANSFER` is selected WAITING and unstarted. It requires separate phase
authorization, a fresh literature/reuse review, an independent target and
preregistration. No transfer design or execution begins in this item.

The six remaining pending survivors and all historical admission bytes remain
unchanged. The planning proposal, prior CVC results,
sixteen observer charges, failed/unknown costs and original CVC-4/CVC-5
dependencies remain intact. Existing Lean/Arena Waiting triggers and Kiota
deferrals are preserved.

### Completed predecessor — Prospective transfer assessment, 2026-09-08

1. `F-PROSPECTIVE-TRANSFER-ASSESSMENT` — the owner-authorized bounded
   `ALT-TRANSFER` assessment is complete under
   [docs/research/PROSPECTIVE_TRANSFER_ASSESSMENT_PLAN.md](research/PROSPECTIVE_TRANSFER_ASSESSMENT_PLAN.md).

Selected next item: `TRANSFER-HOLDOUT-INTAKE-1`.

Queue handoff: PAUSED.

`ALT-TRANSFER` is COMPLETE with `SUCCESS` for an assessment and **NO_GO** for
its three assessed routes. The existing four-checker known-case pool contains
prior observed outcomes; Ferriprove's pinned CLI is a placeholder; Lean4Less
shares Lean4Lean ancestry and changes the checked object/theory. None establishes
both a usable target and a valid independent/unobserved comparison. This is a
bounded eligibility decision, not a general negative transfer result. Prior
M6/M7 scoped transfer evidence remains valid under its original feedback rules.

The fresh methods review retains fault isolation, suite-size/coverage controls,
direct outcome reporting and separate interpretation/checker trust boundaries.
No design was frozen and no checker, proof, setup/build, new scientific byte or
external research action ran. Read-only source requests and access failures are
preserved in the [assessment package](../results/research/alt-transfer-2026-09-08/README.md).
Required closure verification is recorded under
`results/workflow-refresh/alt-transfer-2026-09-08/`.

`TRANSFER-HOLDOUT-INTAKE-1` is selected WAITING and unstarted. Supply one
owner-designated independently curated input/custody package or concrete new
functioning target evidence, then separately authorize its one-hour metadata-only
intake. No curator or package has been supplied. Do not repeat the completed
search, unseal outcomes, build a checker or contact a provider to manufacture
activity. A different named bounded direction may instead be authorized.

All six pending survivors, current modeled population, historical study and
conditional results, consumed/unknown costs, catalog authority and source locks
remain unchanged. Existing Lean/Arena waiting triggers and Kiota deferrals are
preserved. The exact accepted authority and entry state remain bound in
[work-record.json](../results/research/alt-transfer-2026-09-08/work-record.json).

### Active

1. `F-DISCOVERY-AND-CONFORMANCE` — explore fresh public-input behavior and build
   reusable shared conformance assets under
   [docs/research/DISCOVERY_AND_CONFORMANCE_PLAN.md](research/DISCOVERY_AND_CONFORMANCE_PLAN.md).
   This explicitly succeeds the contribution portfolio; it crosses no assurance
   milestone and preserves its completed work and external-action gates.

Selected next item: `E0-UNIVERSE-CORPUS-REUSE-1`.
Queue handoff: EXECUTABLE.
The canonical queue retains one READY item and zero ACTIVE items.

The one-endpoint Comparator screen is COMPLETE: the actual clean endpoint passed
Lean and Nanoda, and the added LAL check passed that baseline while rejecting all
four controlled checking/identity/freshness failures. This is E0 integration
evidence at trusted configuration/executable boundaries, not a kernel defect or
a claim about published historical runs. No upstream action, automatic confirmation
or broader replay follows. See the [bounded result](../explorations/runs/EXPLORE-COMPARATOR-CONSUMER-1/summary.md).

Both small symbolic-universe screens are COMPLETE. The first accepted six
valid cases on both validators; the [rejection screen](../explorations/runs/EXPLORE-SYMBOLIC-UNIVERSE-REJECTION-1/summary.md)
then obtained six expected accepts and six expected rejections from three
matched pairs. Retain six valid fixtures plus three single-record invalid
variants, without claiming global correctness or a fault-detection rate.
Select the [source-only corpus reuse assessment](research/E0_UNIVERSE_CORPUS_REUSE_1_PLAN.md)
READY and unstarted. Compare those nine cases with existing pinned Nanoda/Arena
tests before adding more cases or preparing a contribution. Reuse source
snapshots; no build, general framework or formal model is required.

Kernel/validator conformance and verification-pipeline integrity remain the
focus; mathematical-meaning fidelity stays a separate deferred direction.
Independent transfer intake remains WAITING on its unchanged input/custody and
authorization gates. Build-mode conformance remains PLANNED with its rejected
three-profile premise retained; a narrower comparison still needs a property
and suitable fixture. Agent retrieval requires a concrete witness bottleneck;
memory accounting still lacks a named decision dependency. The
[current frontier selection](research/DISCOVERY_AND_CONFORMANCE_PLAN.md#current-selection--2026-10-21)
supersedes earlier next-item and pause wording without changing their evidence.

The Tree2 continuation is stopped as of 2026-10-01.
`E0-TREE2-COMPUTATION-PILOT-1` is COMPLETE with a NEGATIVE usefulness outcome:
the checked restricted model proofs are preserved, but no concrete downstream
obligation was discharged. The [utility assessment](../results/research/tree2-utility-disposition-1/report.md)
found the actual historical success-or-decline theorem in `complete3-parked`,
with explicit simulation, typing, freshness and key-restriction premises.
The earlier claim about a missing general bridge described pinned main only;
it did not establish absence from upstream's preserved branch.
No further grammar, output, value/fold or completeness expansion is selected.

`LEAN-ETA-ALIAS-PILOT-PREPARATION-1` completed its source, duplicate,
fixture-shape, independent-oracle and exact-runner capability review on
2026-10-02. `E0-LEAN-ETA-ALIAS-PILOT-1` then closed `INCONCLUSIVE`: Docker
Desktop became healthy, but the sole allowed `linux/amd64` base-image pull
emitted no output and reached its supervised 900.103-second limit. Cleanup was
complete, but no image, official PR15373 runner, scientific container or one of
the four fixed Meta/kernel observations exists. This is a capability boundary,
not evidence about Lean eta behavior. The explicit stop rule forbids a source
build or alternate infrastructure route in this campaign. See the
[retained report](../explorations/runs/EXPLORE-LEAN-ETA-ALIAS-1/report.md).

The linked `E0-LEAN-ETA-ALIAS-PILOT-RETRY-1` completed with E0 `SIGNAL` after
the normal sandbox approval mechanism was clarified for the exact task-created
container. The one repaired four-case replay exited 0. Explicit arbitrary
function rejection was `Meta=false, Kernel=false`; both constructor controls
were `true,true`. The preserved-alias arbitrary-function negative was
`Meta=false, Kernel=true`, contrary to the independent correctness oracle and
consistent with the prereviewed alias-sensitive branch risk. The repair changed
only exception rendering and reserved local names; raw expressions, alias
identity, assertions, order and expectations stayed fixed. Terminal inspection
recorded an exited non-OOM container with code 0; the exact container was then
removed and lookup by full ID returned `No such object`. This is a one-fixture
PR15373 signal, not whole-validator, exploitability, current-main or general
kernel evidence. The earlier append-only INCONCLUSIVE finish remains historical
at the pre-approval capability boundary. No publication or upstream action
occurred. See the [authorized recovery report](../explorations/runs/EXPLORE-LEAN-ETA-ALIAS-RETRY-1/authorized-recovery-report.md).
One subsequent fresh-process confirmation passed all in-container identity gates
and reproduced the same matrix. `Kernel.check` reported the disputed left
operand as `FnAlias` and the constructor as `Bool → Box`; `Kernel.isDefEq`
again returned true only for that alias-negative case while Meta returned false.
The exact confirmation container exited 0, was removed, and is absent by full-ID
lookup. This strengthens the result to a reproducible pinned-artifact API
disagreement. It still does not establish PR causation or production declaration
acceptance because no exact parent binary or declaration-level check was used.
See the [fresh confirmation report](../explorations/runs/EXPLORE-LEAN-ETA-ALIAS-RETRY-1/fresh-confirmation-report.md).
`E0-LEAN-ETA-ADMISSION-1` completed with E0 `SIGNAL` on 2026-10-02.
At exact official PR15373 commit `015d5464`, a trust-zero checked
`Kernel.Environment.addDeclCore` accepted the closed alias-domain invalid
theorem while the separately launched explicit `Bool → Box` control rejected.
Raw shapes confirm that only the accepted cell retained `FnAlias`. This resolves
the minimal API-to-admission question at that one artifact; it does not establish
PR causation, current-main or release behavior, a derivation of `False`, broader
exploitability or general kernel correctness. No upstream action occurred. See
the [report](../explorations/runs/EXPLORE-LEAN-ETA-ADMISSION-1/report.md).
At the 2026-10-04 handoff, transfer intake was selected WAITING and the queue
was PAUSED with no READY or ACTIVE item; the 2026-10-18 selection supersedes
that operational state while retaining the intake's blockers.
The memory audit remains DEFERRED and must not auto-start. The owner directed
publication-ready completion of the separately planned E1 confirmation. An
inherited Daybreak Blue reviewer conditionally passed its four-cell design and
required matched source builds, explicit checked admission, exact exception
classification, stored-declaration verification and immutable launch inputs.
Those controls are now frozen. The first final review of checkpoint `b71712a9`
failed closed on missing launch-time shared-library enforcement and an
unretained githash-header mutation; no scientific cell ran. The repair now
retains the exact guarded header operation, validates the injected `libuv`,
`libleanshared` and every resolved dependency, and rebuilds both runners and
runner-specific `.olean` files through the recorded path. Exact head and parent Release runners were built
from content-addressed Git trees with the same GCC 14.2/CMake 4.1.2, GMP-off,
four-job method; both independently compiled runner-neutral fixtures and now
self-report their exact commits. The retained first identities exposed and the
repair record explains a detached-worktree CMake githash defect. E1 remains
`ACTIVE` after Daybreak Blue passed immutable checkpoint `edb92569` and
authorized exactly the frozen four cells. All four cells then completed: the exact
PR head accepted the alias-domain invalid theorem and rejected its explicit-domain
control, while the exact parent rejected both with `declTypeMismatch`. This confirms
an exact-head checked trust-zero admission regression in the bounded comparison.
The [result](../results/research/lean-eta-admission-confirmation-1/result.json),
[report](../results/research/lean-eta-admission-confirmation-1/report.md), private
disclosure draft, proposed regression and action recommendation are retained as a
publication-ready private package. No upstream contact occurred. External disclosure
requires explicit human approval of the exact private destination and draft; current
master, releases, broader exploitability, severity and a fix remain untested.
The three-case test-effectiveness campaign then completed on 2026-10-03.
Nanoda's unchanged 44-test suite missed all three seeded omissions. The fixed
90-file compact Lab sample detected the declaration-type fault with three cases;
the separately retained targeted pair detected the congruence fault. The lambda
omission changed no final verdict, consistent with its prior public-entrypoint
equivalence classification, so it is not a third coverage gap. The invalid
shared-target attempt and one sandbox monitor failure remain retained; the
repaired 376-process execution has distinct binaries and complete supervision.
See the [E0 summary](../explorations/runs/EXPLORE-TEST-EFFECTIVENESS-1/summary.md).

`E0-HISTORICAL-FAULT-TRANSFER-SCREEN-1` is COMPLETE with `SUCCESS` for its
bounded screen. **What did we find?** The unchanged 90-file compact sample did
not distinguish the affected and fixed official Lean binaries. It produced two
Nanoda differences, but both exact fixed diagnostics and the retained source
diff trace them to a separate, already-known conservative possibly-Prop
projection policy rather than the target projection-structure identity fix.
All 360 supervised executions completed without a compatibility, timeout or
cleanup boundary. **Is it interesting?** Yes, negatively: the sample's useful
seeded-fault coverage did not transfer to either target historical fault, and
causal review prevented two unrelated verdict changes from being counted as
target coverage. **Does it require more work?** No result-driven confirmation,
PR or external action follows. See the [campaign summary](../explorations/runs/EXPLORE-NANODA-PROJECTION-TRANSFER-1/campaign-summary.md)
and [diagnostic review](../explorations/runs/EXPLORE-NANODA-PROJECTION-TRANSFER-1/diagnostic-review.json).

At the 2026-10-04 handoff, `TRANSFER-HOLDOUT-INTAKE-1` was selected WAITING and
unstarted. The queue was PAUSED because no independently curated fresh input/custody package or concrete
new functioning target evidence has been supplied. The memory audit remains
DEFERRED without a decision that depends on its historical accounting question,
and build-mode work remains PLANNED: its three-profile premise is not distinct,
while a narrower two-profile question lacks a named property and valid fixture.
Box/FnAlias remains with the owner's separate agent.

The prior conclusion that no result-driven work followed was too narrow. It
applied to transfer from the fixed compact corpus, not to construction of a new
fault-specific regression. Arena already has a direct regression for official
Lean's nested-unused-parameter fault. Current Nanoda `3a240721` still has the
historical projection-name guard but no direct test in its source inventory.
`E0-NANODA-PROJECTION-IDENTITY-REGRESSION-1` is therefore ACTIVE under its
[E0 plan](research/E0_NANODA_PROJECTION_IDENTITY_REGRESSION_1_PLAN.md). It will
attempt one small public-`def_eq` test and require exact historical-mutant
sensitivity plus a passing fixed full suite before recommending a PR. No
upstream action is authorized.

`E0-NANODA-PROJECTION-IDENTITY-REGRESSION-1` is COMPLETE with E0 `SIGNAL`.
**What did we find?** A new test through public `TypeChecker::def_eq` passes on
current Nanoda `3a240721`, fails at the intended assertion when only the
historical projection-name conjunct is removed, and leaves the fixed full suite
passing 45/45. Current source and GitHub duplicate review found no equivalent
direct test. **Is it interesting?** Yes. This turns the earlier general-corpus
miss into a small regression that detects the exact historical omission without
changing production code; it does not establish a current defect or security
issue. **Does it require more work?** The owner authorized the recommended
test-only submission, and [Nanoda draft PR #43](https://github.com/ammkrn/nanoda_lib/pull/43)
now carries the exact validated regression as coverage for historical PR #23.
No further local research follows; the draft awaits maintainer review, and any
later external action requires fresh exact authorization. Official Lean needs
no parallel case because Arena already retains its direct regression. See the
[E0 summary](../explorations/runs/EXPLORE-NANODA-PROJECTION-IDENTITY-REGRESSION-1/summary.md).
The original [Tree2 plan](research/TREE2_COMPUTATION_PILOT_1_PLAN.md) and all
closed trial reports remain historical evidence.

On 2026-10-01 the owner explicitly selected `E0-NANODA-CONGRUENCE-FAULT-PILOT-1`
as the sole ACTIVE campaign after the Tree2 stop. It screens one current-Nanoda
constant-application congruence fault against a preregistered invalid declaration,
matched valid control and existing corpus. `LEAN-ETA-ALIAS-PILOT-PREPARATION-1`
is DEFERRED without execution while this campaign is active. No Nanoda upstream
write, broad mutation campaign, checker-defect claim or security claim is authorized.

`E0-NANODA-CONGRUENCE-FAULT-PILOT-1` completed with E0 SIGNAL on 2026-10-01.
At current Nanoda `3a240721`, the clean checker accepted the valid control and
rejected the invalid `F A`/`F B` declaration; the one-conjunct intentional fault
accepted both. All 44 existing active tests passed under the fault. A minimal
three-file regression passes baseline, fails under the fault, and the baseline
full suite passes 45/45; independent scientific review passed. This is a local
test-sensitivity result, not a production checker defect or Lean vulnerability.
No upstream action occurred. The canonical queue again selects
`LEAN-ETA-ALIAS-PILOT-PREPARATION-1` READY and unstarted with zero ACTIVE campaigns.

Lean-action regression preparation has26 fresh reviewed shell/model controls and two internal technical evidence/patch packages. Earlier AI-authored comment drafts are historical only and NOT FOR POSTING. Any later communication must be human-authored and follow the public target policies, including AI disclosure/manual review for contributions. Its local completion is conditional on the exact strict full-payload and ordered closure receipt at results/workflow-validation/lean-action-regression-1; it is not published.
The real Nanoda screen and separate whole-module retry are COMPLETE; the original timeout remains historical INCONCLUSIVE, while the exact retry is E0 NO_SIGNAL with 59,349 declarations accepted. General checker parity, YAML workflow execution and host-security effects remain untested.
The restricted Tree2/List-tower proof and its unchanged historical closure are published. Queue and summary restoration does not reattest current-tree strict closure.
[Bounded package](../results/research/lean-action-regression-preparation-1/report.md) and [local E2 closure plan](../results/research/lean-action-regression-preparation-1/closure/e2-plan.md).
The alias source/fixture preparation later completed and the exact four-case E0 screen is now ACTIVE under its separate plan. No parent fvar-reuse investigation or larger eta campaign started here.
The owner authorized restoring these omitted records, refreshing planning views and pushing that cleanup on 2026-10-01. That cleanup is complete. The owner's later explicit instruction authorizes normal validated milestone publication to lab main; this supersedes the earlier local-only Tree2 publication boundary. Upstream messages, contributions and privileged security setting changes remain unauthorized.

The closure-automation successor completed its full-suite and refresh gates.
Its source-only comparison selected the now-completed
[lazy-reduction pilot](research/LAZY_REDUCTION_CONFORMANCE_PILOT_1_PLAN.md).
The exact twelve scientific cells all accepted with the six required KAM
demand observations, and all four capability cells matched. Its reviewed
adapter, independent auditor, six regressions and preserved build repair remain
local assets; [the report](../results/research/lazy-reduction-conformance-pilot-1/report.md)
scopes the same-implementation and host/profile limits. STATEFUL subsequently
completed all six public kernel environment-history comparisons, twelve
histories and 25 requests under [its exact report](../results/research/stateful-validation-pilot-1/report.md).
REAL-PROOF-SLICES completed twelve fixed dispositions, including nine accepted
slices and three oversize `std` selections. Its provenance-preserving slicer
and independent auditor remain local assets under the exact
[report](../results/research/real-proof-slices-pilot-1/report.md).
BINDER-MODEL completed its exact finite comparison: both selected APIs matched
on 30,000 outputs across 10,000 rows. The scoped plain-language finding,
limits, and retained local assets are in its [report](../results/research/binder-model-pilot-1/report.md).
RESOURCE-ENVELOPE is COMPLETE with SUCCESS under its
[plan](research/RESOURCE_ENVELOPE_PILOT_1_PLAN.md) and
[work record](../results/research/resource-envelope-pilot-1/work-record.json).
The exact matrix has 24 ACCEPTED scientific checks and 12 ACCEPTED baselines.
All 18 Nanoda rows have zero sampled RSS points; sampled group peaks remain
unknown. Earlier construction recursion and sandbox-monitoring failures remain
preserved in the work-record attempt index. The 2026-09-27 owner direction holds
Kiota/Nanoda follow-up absent substantive feedback; ledger observations remain
dated.

`KIOTA-RECURSOR-PR-REFINEMENT-1` is COMPLETE with SUCCESS under its
[refinement plan](research/KIOTA_RECURSOR_PR_REFINEMENT_1_PLAN.md). The reviewed
successor removes full-environment copies, restores documented K compatibility,
adds direct boundary tests and rewrites the upstream rationale. Fifteen focused
tests, six preserved fixture cells and all 168 Kiota tests pass; the full
repository current/historical suite passes. The earlier package remains
immutable. Read-only preflight found the same upstream main and no apparent
open duplicate. On 2026-09-23, the owner authorized the fork and submission;
the exact reviewed patch is now [Kiota PR #11](https://github.com/sankalpsthakur/kiota/pull/11),
OPEN and ready for review at the dated ledger observation. The trust-assumption
pilot is COMPLETE with SUCCESS;
[its report](../results/research/trust-assumption-pipeline-pilot-1/report.md)
preserves the exact scope and original reporting incident. The stateful pilot
is COMPLETE under [its plan](research/STATEFUL_VALIDATION_PILOT_1_PLAN.md)
after completion of the later lazy-reduction pilot. Its exact public API
comparison preserves all six relations; the real-proof slice successor is
COMPLETE under [its staged plan](research/REAL_PROOF_SLICES_PILOT_1_PLAN.md).


`ACCEPTANCE-IMPACT-PILOT-1` is COMPLETE under the
[acceptance-impact plan](research/ACCEPTANCE_IMPACT_PILOT_1_PLAN.md). Its exact
retained `LALNest.rec_1` candidate/control pair and archived Kiota `9fa2c297`
source are bound. The first stage is a fixed four-cell current reproduction
against Kiota and official Lean. Downstream construction remains forbidden
unless both controls accept, current Kiota accepts the candidate and official
Lean rejects it. If that gate passes, commit the assumption audit, one matched
consequence criterion and exact execution manifest before constructing or
observing the use. The exact pair audit, safe archived-source materializer and
observable build/execution controller now pass their focused preparation tests.
The exact offline release build passed in 17.45 seconds with 549 positive RSS
samples, a 362,283,008-byte maximum observation and complete cleanup; its
post-build 90-file source tree remains archive-identical. The exact four-cell
execution manifest produced a complete current-premise result: both controls
accepted, Kiota `9fa2c297` accepted the candidate and official Lean 4.33.0
rejected it with the exact `Invalid recursor LALNest.rec_1` diagnostic. All
four cells had positive RSS observations and complete cleanup. The Stage-2
assumption audit, fixed five-application consequence contract, deterministic
producer, independent structural auditor and bounded controller are committed,
and their exact tooling revision is frozen. The deterministic producer emitted
the two fixed 121-record artifacts; the independent structural audit passed and
the exact four-cell execution manifest is committed. Stage-2 observation is
complete under that immutable matrix. Both Kiota cells and the official control
accepted. The official candidate reached `LALNest.rec_1_impact` and rejected its
fifth argument with an application type mismatch, rather than the precommitted
`Invalid recursor LALNest.rec_1` diagnostic. The immutable decision replay is
therefore `CONSTRUCTION_OR_SEMANTIC_BOUNDARY`. The completed closure preserves
that exact result without relabeling it, while recording the narrower evidence
that the fixed declaration exposes a downstream cross-observer typing
difference.

`RECURSOR-TYPE-TRUST-BOUNDARY-1` is COMPLETE under its
[source-bound plan](research/RECURSOR_TYPE_TRUST_BOUNDARY_1_PLAN.md). It binds
the exact Kiota and official replay paths, explains the two preserved rejection
locations, states a narrow local import policy and freezes the exact
reject-candidate/accept-control regression. Its result is a validated regression
target with a source boundary, not a production repair or universal format rule.

`KIOTA-RECURSOR-TYPE-DESIGN-1` is COMPLETE under its
[source/design plan](research/KIOTA_RECURSOR_TYPE_DESIGN_1_PLAN.md). It validated
a complete construction for ordinary, mutual and nested groups from the exact
Kiota APIs and archived Lean 4.33.0 kernel algorithm. It selected positional
universe alpha normalization, Kiota definitional equality, fail-closed mismatch
handling and reconstructed-type replacement. Its four accepted fixtures and
inherited candidate/control pair are frozen; no checker or production action ran.

`KIOTA-RECURSOR-TYPE-REPAIR-1` is COMPLETE with SUCCESS under its
[implementation plan](research/KIOTA_RECURSOR_TYPE_REPAIR_1_PLAN.md). The
source repair reconstructs complete ordinary, mutual and nested recursor types,
compares supplied signatures fail-closed and installs only reconstructed types.
Its exact candidate rejects, the unchanged control and four valid acceptance
cells accept, seven focused tests pass and the complete 160-test suite passes.
The retained malformed legacy nested fixture is byte-identical and now expected
to reject. The source patch, execution evidence and indexed PR draft remain
local; no external submission occurred.

The dependent-term pilot completed its exact fifty-case matrix with 100/100
ACCEPT observations and no profile difference. Its generator and independent
auditor are retained as a local asset. After the recursor repair closure, the
trust-assumption study subsequently completed its twelve-cell reporting matrix.
The 2026-09-27 lazy-reduction closure review selected STATEFUL public-request
validation, now COMPLETE. Its exact six comparisons through the functional
kernel API preserve every expected outcome and environment projection. The
closure review selects real-proof slicing for its distinct real-library and
dependency-provenance value; its own scientific gates remain preparation.

The pipeline-completeness continuation completed SUCCESS. Its exact baseline
was accepted by both bound checkers; omission and compatible substitution were
also accepted by both, while the sentinel rejected all six fault cells with the
preregistered distinct classifications. This establishes a reusable
checked-object receipt pattern, not a checker defect or general semantic claim.

The original [representation pilot](research/METAMORPHIC_REPRESENTATION_PILOT_PLAN.md)
remains immutable BOUNDED_UNRESOLVED. Its separately identified
[continuation](research/METAMORPHIC_REPRESENTATION_PILOT_2_PLAN.md) completed
SUCCESS without resetting that history. The exact final matrix has eight
executed ACCEPT cells and four preregistered ineligible cells: both nonidentity
reverse-ready variants preserved acceptance on both bound profiles. The
[result](../results/research/metamorphic-representation-pilot-2/result.json)
supports a scoped no-sensitivity observation, not global invariance. Its tooling,
generated pairs and closure regression remain live as a local conformance asset;
no external action is recommended now.

| Rank | Candidate | State |
| --- | --- | --- |
| 1 | `METAMORPHIC-REPRESENTATION-PILOT-2` | COMPLETE, SUCCESS |
| 2 | `PIPELINE-COMPLETENESS-PILOT-2` | COMPLETE, SUCCESS |
| 3 | `VALID-DEPENDENT-TERM-PILOT-1` | COMPLETE, SUCCESS |
| 4 | `ACCEPTANCE-IMPACT-PILOT-1` | COMPLETE, CONSTRUCTION_OR_SEMANTIC_BOUNDARY |
| 5 | `TRUST-ASSUMPTION-PIPELINE-PILOT-1` | COMPLETE, SUCCESS |
| 6 | `LAZY-REDUCTION-CONFORMANCE-PILOT-1` | COMPLETE, SUCCESS; twelve ACCEPT cells and qualified KAM demand |
| 7 | `STATEFUL-VALIDATION-PILOT-1` | COMPLETE, SUCCESS; six preserved relations |
| 8 | `REAL-PROOF-SLICES-PILOT-1` | COMPLETE, SUCCESS; nine accepted slices and three oversize |
| 9 | `BINDER-MODEL-PILOT-1` | COMPLETE, NO_OBSERVED_DIFFERENCE; 30,000 scoped outputs matched |
| 10 | `RESOURCE-ENVELOPE-PILOT-1` | COMPLETE, SUCCESS; 24 scientific checks and 12 baselines ACCEPTED; 18 Nanoda sampled peaks unknown |
| 11 | `E0-LAZYLEAN-SEMANTIC-EXTENSION-1` | COMPLETE, NO_SIGNAL; eight ACCEPT cells with delta/iota demand |
| 12 | `SNAPSHOT-REUSE-CLOSURE-RELIABILITY-1` | COMPLETE, SUCCESS; final ordered closure prebound |
| 13 | `CONFIRM-LEAN-ETA-ADMISSION-1` | COMPLETE, SUCCESS; exact-head checked-admission regression confirmed |
| 14 | `BUILD-MODE-CONFORMANCE-PILOT-1` | PLANNED; three-profile premise rejected; narrower property/fixture missing |
| 101 | `E0-COMPARATOR-CONSUMER-SCREEN-1` | COMPLETE, E0 SIGNAL; baseline passes added check, four controls fail |
| 102 | `E0-SYMBOLIC-UNIVERSE-SCREEN-1` | COMPLETE; twelve accepts, six tiny symbolic cases retained |
| 103 | `E0-SYMBOLIC-UNIVERSE-REJECTION-1` | COMPLETE; six accepts, six expected rejections |
| 104 | `E0-UNIVERSE-CORPUS-REUSE-1` | READY; source-only incremental coverage assessment; unstarted |
| 97 | `RESOURCE-SHORT-PROCESS-MEMORY-AUDIT-1` | DEFERRED; reopen only for a named measurement dependency |
| 12 | `SURVIVOR-THREAD-ONE-DETERMINISM-1` | COMPLETE, SUCCESS |
| 65 | `SURVIVOR-THREAD-ONE-CHILD-PANIC-REGRESSION-1` | COMPLETE, BOUNDED_UNRESOLVED |
| 68 | `CHILD-PANIC-CONFIRMATION-1` | COMPLETE, SUCCESS |
| 69 | `PIPELINE-COMPLETENESS-PILOT-1` | COMPLETE, BOUNDED_UNRESOLVED |
| 70 | `RECURSOR-TYPE-TRUST-BOUNDARY-1` | COMPLETE, VALIDATED_REGRESSION_TARGET_WITH_SOURCE_BOUNDARY |
| 71 | `KIOTA-RECURSOR-TYPE-DESIGN-1` | COMPLETE, SUCCESS — `VALIDATED_COMPLETE_KIOTA_DESIGN` |
| 72 | `KIOTA-RECURSOR-TYPE-REPAIR-1` | COMPLETE, SUCCESS — validated source repair and local PR draft |

Each PLANNED candidate has its own concrete promotion gate and fixed scientific
scope in the canonical queue and successor plan. Reassess actual value and
feasibility at closure. The completed continuation used exactly the inherited
two originals, two transformations and two profiles. Sixteen checker attempts
were consumed across one infrastructure-invalid run and one exact confirmation;
no scientific input changed. Legal representation, independent preservation and
observable supervision remain enforced by the retained regressions.

`KIOTA-CTOR-INDEX-COVERAGE-1` completed SUCCESS under its
[bounded plan](research/KIOTA_CTOR_INDEX_COVERAGE_PLAN.md). At retained Kiota
`9fa2c297`, 69 unique fixtures are wired across 70 tests. `orphan-ctor` reaches
the missing-owner branch and uses a generic rejection assertion; the complete
fixture projection found no declared-owner wrong, swapped or out-of-range cidx
case. The exact retained pair changes only `LALNest.node.cidx` from 0 to 1 and
source-predicts a compatible accept control plus the exact owner-list/index
rejection. No Kiota process or external write ran, so current execution and
current-tip behavior remain unclaimed. See the [coverage map](../results/research/kiota-ctor-index-coverage-1/coverage-map.json)
and [report](../results/research/kiota-ctor-index-coverage-1/report.md).

`KIOTA-CTOR-INDEX-TEST-1` completed SUCCESS under its
[implementation plan](research/KIOTA_CTOR_INDEX_TEST_PLAN.md). The exact test-only
package adds two unchanged fixtures, a paired acceptance test and an exact-message
rejection test. Focused 2/2 and all 155 current tests passed at bound
`9fa2c297`; both reservations completed cleanup. The [report](../results/research/kiota-ctor-index-test-1/report.md)
and [indexed PR draft](../results/action-recommendations/drafts/kiota-constructor-index-regression-pr.md)
preserve the no-defect, no-universal-authority and human-gated submission limits.

`SURVIVOR-THREAD-ONE-DETERMINISM-1` completed its unchanged
[original plan](research/SURVIVOR_THREAD_ONE_DETERMINISM_PLAN.md) with eight
local inspections and no launches. It selected the separately planned
`SURVIVOR-THREAD-ONE-CHILD-PANIC-REGRESSION-1` READY and unstarted: one bounded
four-cell existing-byte protocol that must bind configuration/build/cleanup
controls before execution. The theorem companion remains PLANNED without
distinct-risk evidence, original CVC-4/CVC-5 gates remain unmet, and transfer
intake still lacks its required independent external package.

`NANODA-STRING-RECONSTRUCTION-TEST-1` completed SUCCESS. Two focused and all
40 library tests pass; eight existing doc examples remain ignored. The
[report](../results/research/nanoda-string-reconstruction-test-1/report.md) and
[indexed local PR draft](../results/action-recommendations/drafts/nanoda-string-reconstruction-tests-pr.md)
record exact empty/Unicode constructor shapes, eight flag/name states and an empty
declaration map. Both counted build/test reservations completed cleanup. The
candidate remains local for source/duplicate/capacity review and exact submission
approval. No current defect or public typing/defeq/checker result is established.

`NANODA-NATIVE-CONFIG-BOUNDARY-1` completed SUCCESS. The
[assessment](../results/research/nanoda-native-config-boundary-1/report.md) distinguishes
String-only admission from both-flag constructor reconstruction and explicitly
refines prerequisite presence to cached names, with declarations absent in both
states. Proposed empty/Unicode shape assertions go beyond optional-return checks.
All eight outcomes are source predictions; no Nanoda process was launched and no
public checking/defeq/typing or current-defect claim follows. The documentation
alternative is retained but no second contribution is prepared.

`NANODA-NESTED-TEST-1` completed SUCCESS. Six focused and all 44 library tests
passed at current Nanoda `4c544ed`, with eight existing doc examples ignored.
The [report](../results/research/nanoda-nested-test-1/report.md) retains exact
prefix/traversal controls, two exact guards, unchanged PUnit positive control and
scope exclusions. The indexed test-only PR draft remains local for fresh preflight,
capacity review and exact submission approval. No current defect or universal
obligation is established.

`NANODA-NESTED-REGRESSION-1` completed SUCCESS for its source-only design.
The complete static 38-test audit distinguishes name helper and incidental
fixture coverage from targeted reserved-prefix assertions. Thirteen paired
traversal positions and two exact declaration-level guard checks are proposed,
with unchanged PUnit as a complete positive control. Candidates test early
namespace enforcement; generic downstream type panics cannot satisfy them.
The mutual-peer guard is source-audited but not isolated. No Nanoda test was run
and no universal Lean obligation or current defect is inferred. The
[assessment](../results/research/nanoda-nested-regression-1/report.md) preserves
these limits and independently reviewed construction/pointer controls.

`ARENA-LET-POLICY-FOLLOWUP-1` completed SUCCESS. One
[submitted PR #206](https://github.com/leanprover/lean-kernel-arena/pull/206)
adds a candidate-only `either` static case; current Arena build-test passed with
the unchanged 601-byte export. No extra accept control is useful given current
tutorial coverage. Exact owner approval and fresh preflight preceded submission
on 2026-09-14; readback verified OPEN with the exact two files. A separate
2026-09-19 observation verifies it merged on 2026-09-14 at `4543f486`; see the
[dated contribution ledger](EXTERNAL_CONTRIBUTIONS.md). No further action is
recommended for this package. No checker execution occurred; the [submission record](../results/research/arena-let-policy-followup-1/external-submission-record.json)
is separate from the unchanged research closure.

The [feedback successor](../results/research/arena-let-feedback-2026-09-13/decision.md)
incorporates nomeata's direct reply to #48. It supplies affirmative scoped
practical support for allowing implementation choice on this exact question;
it is neither universal semantic authority nor automatic Arena adoption.
The original Arena-let closure remains historical BOUNDED_UNRESOLVED, but its
absence-of-any-positive-support premise no longer blocks a practical proposal.

`SEMANTIC-IMPORT-CONTRACT-1` completed SUCCESS for a source-qualified four-field
clarification packet. Universal metadata obligations remain UNRESOLVED; current
source explains k recomputation and a newer cidx guard without projecting old
checker outcomes. One grouped documentation appendix remains local alongside
lean4export #48. Its next review must incorporate the maintainer reply and identify
a distinct practical documentation need before any further question or exact
external approval request.
No scientific launch, catalog change or authority promotion occurred.

`ARENA-INDUCTIVE-ISOLATION-1` completed NEGATIVE for an eligible existing-byte
package. The four fixed tutorial cases and retained exports contain competing
recursor causes; existing complete alternatives are already present and concern
other properties. The source/diagnostic distinction strengthens the value of
independent import-contract clarification. No new scientific launch occurred.

`NANODA-DEFEQ-CACHE-1` completed BOUNDED_UNRESOLVED. Its source-bound assessment
excludes direct eager native reduction of open terms and records the exact remaining
Boolean-shortcut and closed/open routes; no mode-outcome witness or global mode
equivalence is established. No Nanoda scientific launch or speculative PR occurred.

`NANODA-NAT-DISPATCH-REGRESSION-1` completed SUCCESS with a test-only patch:
both new tests and all 40 Nanoda library tests passed. The
[local PR draft](../results/action-recommendations/drafts/nanoda-nat-dispatch-regression-pr.md)
is indexed and held for capacity review, refreshed source/duplicates and exact
submission approval. Its six operations and disabled control provide preventive
internal-API coverage; no current bug or public importer claim is made.

`HSBM-PILOT-1` completed NEGATIVE for its fresh-yield criterion. Its one useful
Nat dispatcher recommendation partly reuses known `Nat.land` evidence; no two
fresh actionable commits were found and no broader yield claim follows.
The [six-commit ledger](../results/research/hsbm-pilot-1/ledger.json) preserves
covered, obsolete, unresolved and unchanged boundaries without replacing cases.

`SEMANTIC-LET-CONTRACT-1` completed with SUCCESS for a
[source-qualified clarification packet](../results/research/semantic-let-contract-1/clarification-packet.md)
and one documentation question, subsequently submitted with owner authorization
as [lean4export #48](https://github.com/leanprover/lean4export/issues/48) on
2026-09-13. The [submission record](../results/research/semantic-let-contract-1/external-submission-record.json)
preserves that later action separately from the research closure. The later
[reply assessment](../results/research/arena-let-feedback-2026-09-13/recommendation-successor.json)
supplies practical latitude for the exact question; universal authority remains
UNRESOLVED. No catalog or authority decision changed. Its seven
source requests include one failed web open. No scientific launch or new export
occurred. The pair uses its bound variable and adjusts the enclosing declaration
type; checking, conditional reduction and raw import remain distinct contracts.

The earlier executable handoff to `E0-NANODA-SEMANTIC-DIVERSITY-SCREEN-1` is
historical and was subsequently completed. Closure reliability is complete
subject to its exact ordered receipt; the memory audit remains deferred after
project-wide comparison. The resource matrix is COMPLETE with 24 scientific checks and 12
baselines ACCEPTED. The 18 Nanoda runs have zero sampled RSS points, so sampled
group peaks remain unknown. The configured 10 ms target cadence does not
establish actual cadence or the cause of missing samples; wait4 child-accounting
values are not process-group peaks. The binder-model result remains COMPLETE
with 30,000 scoped outputs matched; its model, auditor, vectors and portable
replay remain local regression assets.
The lazy-reduction pilot is complete with twelve ACCEPT cells and all six KAM
demand requirements. The stateful pilot is complete with six preserved public
kernel API relations, twelve histories and 25 requests; its R4 custody repair
adopts the unchanged original fixtures and preserves every failed attempt.
The completed recursor trust-boundary item retains the exact source policy,
regression contract and production-design boundary. The earlier representation
pilot 1 remains frozen at its tooling cap; its own pilot 2 is the successful
separate representation continuation and retains that completed reusable package.

Both Kiota constructor-index items are complete; its focused 2/2 and all 155
current tests passed and its draft remains locally held. Four Nanoda drafts and
two PRs recorded open remain subject to their dated evidence and follow-through
gates. This review did not refresh external discussions or infer capacity.

Theorem distinct-risk, independent-transfer and original CVC gates remain unmet.
Historical results, completed-record content, consumed budgets, pending counts,
external-write gates and the failing assurance state remain unchanged. The
completed recursor repair retains its exact patch, independent review, binary
and execution manifests, successful frozen matrix and local PR draft. The
completed assumption-reporting item retains twelve exact matched cells and
its negative permission comparison. The completed real-proof slice item
retains twelve fixed dispositions: nine accepted slices, three visible
oversize cases, and no observed compatibility difference or fresh-holdout
claim. The binder-model item's exact fragment, source/reuse, independent-audit
and execution gates passed before its vectors and observers were run; retain
its bounded corpus and portable replay locally. At that earlier handoff,
the resource-envelope matrix was selected READY and unstarted; it has since
completed with a reviewed finite result. That memory audit is now deferred. The current READY successor is
[closure reliability](research/WORKFLOW_CLOSURE_RELIABILITY_1_PLAN.md);
its selection does not launch it or any scientific pilot.

### Waiting

- `W-LET-VALIDATION-CONTRACT`: response observed and incorporated on 2026-09-13.
  [Nomeata's reply](https://github.com/leanprover/lean4export/issues/48#issuecomment-5654286873)
  gives practical latitude on the exact let question while disclaiming a
  completely authoritative answer. The issue was observed open; the connector
  omitted comment timestamps. The
  [recommendation successor](../results/research/arena-let-feedback-2026-09-13/recommendation-successor.json)
  triggered the now-completed Arena follow-up and its indexed local PR draft.
  Do not continue to
  wait for the first reply or treat the old lack-of-positive-support premise as
  current. Further normative qualification and any external write retain their
  separate gates; no automatic polling is enabled.

- `W-LEAN-IMAX-NORMALIZATION`: a 2026-09-19 read of the issue comments found
  no later response to the Lab's question (connector timestamps are unavailable).
  Continue to await maintainer guidance on the
  [declaration-level evidence contributed to Lean #12747](https://github.com/leanprover/lean4/issues/12747#issuecomment-5584574955).
  A reply indicating that a focused regression or kernel fix would be useful
  triggers a new bounded proposal and target-specific contribution decision;
  it does not authorize a PR by itself. Until then, retain the source-only
  master comparison and do not claim a current-master execution result.

- `W-ARENA-DISPOSITION-ACCESS`: resolved for read-only review on 2026-09-09.
  A working GitHub connector verified Arena #181 merged on 2026-09-06 and #182
  merged on 2026-09-05. The historical CLI authentication failure is preserved
  but is not a global access blocker. Exact metadata and maintainer feedback
  are in the [Arena review](../results/research/contribution-portfolio-review-2026-09-09/arena-review.json).
  Any external write still needs target-specific approval and a working
  preflight for the selected channel; the Kiota submission deferral remains.

- `W-NANODA-OMITTED-THREADS`: [PR #32](https://github.com/ammkrn/nanoda_lib/pull/32)
  was verified open and unmerged on 2026-09-09 at head `85038f436b7c`.
  It adds preventive malformed-declaration tests through omitted-field and
  explicit-zero configuration paths. This is not a current checker defect or an unclaimed
  new contribution opportunity. Do not create a duplicate. Preserve the old
  NO_GO evidence and use its [recommendation successor](../results/research/contribution-portfolio-review-2026-09-09/zero-thread-recommendation-successor.json).

- `W-ARENA-THEOREM-CONTROL`: review the exact identity-theorem accept control as
  a companion to Arena's existing `tutorial/012_nonPropThm` reject case. The
  low-priority Gate-10 recommendation is `DEFERRED`, not action-ready: current
  Arena duplicate checks and corpus-integration validation remain prerequisites,
  followed by target-specific human authorization. No implementation issue or
  private disclosure is supported by this run.

- `W-NANODA-NUMINDICES`: Nanoda #29 is closed. The retrieved maintainer
  explanation retains serialized `numIndices` in the permanent environment,
  with a possible future change deferred pending Lean #14977. This is an
  explained implementation policy, not a new normative adjudication. Do not
  propose a strict Arena outcome without qualified contract review.

- `W-KIOTA-UNIVERSES`: await adjudication of
  [Kiota #3](https://github.com/sankalpsthakur/kiota/issues/3) for undeclared
  universe ownership.
- `W-KIOTA-SELF-REFERENCE`: await adjudication of
  [Kiota #5](https://github.com/sankalpsthakur/kiota/issues/5) for declaration
  self-reference.
- `W-KIOTA-RESTORED-DECLARATIONS`: retain the three historical mismatches
  against their exact observers. The completed
  [import-contract review](../results/research/semantic-import-contract-1/report.md)
  documents Kiota `9fa2c297` recomputing `k` and enforcing the constructor-index
  owner-list guard; the old cidx ACCEPT is not a current-behavior claim.
  Retained recursor-type validation remains a separate contract question without
  current execution or a defect claim. Do not file a new defect report from the
  old matrix. The grouped documentation packet and Kiota submission deferral
  remain; the cidx coverage audit and test package are complete and grant no
  external action.
- `W-KIOTA-PROOF-PARAMETER-UNIFORMITY`: the exact pair reproduces on pinned
  Kiota `2d2a9fa` after PR #8. Review the new successor draft for one Kiota
  contract-clarification issue; no demonstrated unsoundness is claimed. The
  owner deferred that issue pending Arena feedback. The separate Arena
  characterization merged as PR #182 on 2026-09-05 with control `accept` /
  candidate `either`. This supplies the previously awaited Arena feedback,
  not authorization to file the deferred Kiota issue. The portfolio allows
  bounded local import-policy clarification; any issue still requires exact
  target-specific approval.

- `W-ARENA-REDUCIBLE-POSITIVITY`: retain the complete-recursor artifact,
  supported by prior pinned evidence, as submitted PR #181. Current
  tutorial-content comparison, recent-commit duplicate preflight, static
  integration, and owner approval are complete. Maintainer review removed the
  low-value control, moved the artifact to `corner-cases/positivity-whnf`, and
  selected outcome `either` because acceptance after WHNF may be valid. PR #181
  merged on 2026-09-06; no disposition polling is needed. The original observations remain
  preserved as profile evidence rather than normative semantic authority.

- `W-IMAX-RIGHT-SUCCESSOR`: closed as contributed. Arena PR #176 merged on
  2026-08-30 with `outcome: either`; current source contains the corner cases.
  The successor withdraws both old implementation-issue recommendations.
  Preserve observed profile differences; no new external action is warranted.

- `W-POSSIBLY-PROP-PROJECTIONS`: closed as an explained profile distinction.
  Arena PRs #167/#171 document conservative rejection and `outcome: either`.
  The successor withdraws the two old over-rejection issue recommendations.
  Raw observations and unresolved assurance counts remain unchanged.

### Future Directions

- `D-IMPLEMENTATION-SPECS`: the conditional-contract feasibility phase now
  examines a bounded subset of this idea, beginning with literature/reuse and
  fragment selection. A full four-implementation reverse-engineered export
  specification remains deferred. Preserve parser, reconstruction, validation,
  and semantic-use distinctions; behavior alone does not establish normativity.
- `D-UNDIRECTED-CAMPAIGN`: run a broader unattended mutant campaign only after
  the targeted frontier stops producing higher-value source-directed work.
  Keep generation, checker execution, minimization, and result persistence
  local and deterministic; reserve model use for source interpretation and
  semantic triage.
- `D-MUTATION-SURFACE`: extend operators to match arms and richer reduction
  behavior after the current survivor queue, retaining isolated build
  validation and semantic-policy review.
- `D-REMOTE-PAYLOADS`: define content-addressed remote storage for ignored
  coverage and materialized-corpus payloads, then keep assurance and public
  status artifacts synchronized when evidence changes.
